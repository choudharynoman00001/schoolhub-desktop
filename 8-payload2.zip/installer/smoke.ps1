# SchoolHub installer smoke test (runs on the GitHub Windows runner after NSIS build).
# Verifies: silent install -> launch -> health -> login -> password change -> write marker -> stop -> relaunch -> data preserved.
$ErrorActionPreference = 'Stop'
$base = "$env:LOCALAPPDATA\SchoolHub"
$env:SCHOOLHUB_NO_BROWSER = '1'
function Health { try { return [bool](Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/health' -TimeoutSec 3).ok } catch { return $false } }
function Login($u, $p, [ref]$s) {
  Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/login' -Method Post -ContentType 'application/json' -Body (@{username=$u;password=$p} | ConvertTo-Json) -SessionVariable sv | Out-Null
  $s.Value = $sv
}
function Dump-Log { $log = "$base\data\server.log"; if (Test-Path $log) { Write-Host '--- server.log tail ---'; Get-Content $log -Tail 60 } else { Write-Host 'server.log missing - server never wrote a log' } }
function Wait-Health($tries) { for ($i=0; $i -lt $tries; $i++) { if (Health) { return $true }; Start-Sleep -Seconds 2 }; return $false }
Write-Host '== silent install =='
Start-Process -FilePath '.\SchoolHub-Manager-Setup.exe' -ArgumentList '/S' -Wait
if (!(Test-Path "$base\runtime\node.exe")) { throw 'node.exe missing after install' }
if (!(Test-Path "$base\app\server.js")) { throw 'server.js missing after install' }
if (!(Test-Path "$base\launcher.vbs")) { throw 'launcher.vbs missing after install' }
Write-Host '== first launch =='
cscript //nologo //T:90 "$base\launcher.vbs"
Write-Host "launcher exit code: $LASTEXITCODE"
if (!(Wait-Health 5)) { Dump-Log; throw 'health failed after first launch' }
Write-Host 'health ok'
$credPath = "$base\data\bootstrap-superadmin.txt"
if (!(Test-Path $credPath)) { throw 'bootstrap credentials file missing' }
$cred = Get-Content $credPath
$u = (($cred | Select-String 'username: (.+)').Matches.Groups[1].Value).Trim()
$p = (($cred | Select-String 'password: (.+)').Matches.Groups[1].Value).Trim()
$sess = $null; Login $u $p ([ref]$sess)
Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/change-password' -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{current_password=$p;new_password='SmokePass-8420x'} | ConvertTo-Json) | Out-Null
Write-Host 'bootstrap login + password change ok'
Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{name='Smoke Test School';code='smoke-test'} | ConvertTo-Json) | Out-Null
$before = (Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -WebSession $sess).schools
if (!($before | Where-Object { $_.code -eq 'smoke-test' })) { throw 'marker school missing after create' }
Write-Host 'write marker ok'
Write-Host '== stop server =='
Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*\SchoolHub\app\server.js*' } | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName Terminate | Out-Null }
Start-Sleep -Seconds 2
if (Health) { throw 'server still up after stop' }
Write-Host '== relaunch, data must persist =='
cscript //nologo //T:90 "$base\launcher.vbs"
Write-Host "relaunch exit code: $LASTEXITCODE"
if (!(Wait-Health 5)) { Dump-Log; throw 'health failed after relaunch' }
$sess2 = $null; Login $u 'SmokePass-8420x' ([ref]$sess2)
$after = (Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -WebSession $sess2).schools
if (!($after | Where-Object { $_.code -eq 'smoke-test' })) { throw 'marker LOST after restart - data not preserved' }
Write-Host 'SMOKE PASS: install + launch + login + password change + write + stop + relaunch + data preserved'
