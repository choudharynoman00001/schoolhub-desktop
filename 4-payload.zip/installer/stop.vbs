' Stops the SchoolHub local server (only the node.exe running this app).
Option Explicit
Dim svc, procs, p
Set svc = GetObject("winmgmts:root\cimv2")
Set procs = svc.ExecQuery("SELECT ProcessId FROM Win32_Process WHERE Name='node.exe' AND CommandLine LIKE '%\SchoolHub\app\server.js%'")
For Each p In procs
  p.Terminate()
Next
