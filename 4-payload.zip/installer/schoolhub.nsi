!include "MUI2.nsh"
Name "SchoolHub Manager"
OutFile "..\SchoolHub-Manager-Setup.exe"
InstallDir "$LOCALAPPDATA\SchoolHub"
RequestExecutionLevel user
ShowInstDetails show
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_LANGUAGE "English"
Section "Install"
  SetOutPath "$INSTDIR"
  File /r "..\payload\*.*"
  CreateDirectory "$INSTDIR\data"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\SchoolHub Manager"
  CreateShortcut "$SMPROGRAMS\SchoolHub Manager\SchoolHub Manager.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"'
  CreateShortcut "$SMPROGRAMS\SchoolHub Manager\Stop SchoolHub.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\stop.vbs"'
  CreateShortcut "$SMPROGRAMS\SchoolHub Manager\Uninstall SchoolHub.lnk" "$INSTDIR\Uninstall.exe"
  CreateShortcut "$DESKTOP\SchoolHub Manager.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"'
SectionEnd
Section "Uninstall"
  ExecWait '"$SYSDIR\wscript.exe" "$INSTDIR\stop.vbs"'
  Sleep 1500
  Delete "$DESKTOP\SchoolHub Manager.lnk"
  RMDir /r "$SMPROGRAMS\SchoolHub Manager"
  RMDir /r "$INSTDIR\app"
  RMDir /r "$INSTDIR\runtime"
  Delete "$INSTDIR\launcher.vbs"
  Delete "$INSTDIR\stop.vbs"
  Delete "$INSTDIR\README-FIRST.txt"
  Delete "$INSTDIR\Uninstall.exe"
  MessageBox MB_ICONINFORMATION "SchoolHub ka data folder ($INSTDIR\data) delete nahi kiya gaya, taake school ka record mehfooz rahe. Agar sab kuch hatana hai to yeh folder khud delete kar dein."
  RMDir "$INSTDIR"
SectionEnd
