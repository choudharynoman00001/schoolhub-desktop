'use strict';
/* SchoolHub - Multi-school management SaaS (Pakistan)
 * Single-container Node 22 app, zero external dependencies.
 * Multi-tenant: every tenant row carries school_id; enforced in every query. */
const http = require('node:http');
const { DatabaseSync } = require('node:sqlite');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PORT = parseInt(process.env.PORT || '3000', 10);
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, 'backups'), { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'school.db'));
db.exec('PRAGMA journal_mode=WAL;');
db.exec('PRAGMA foreign_keys=ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS plans(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  price_pkr INTEGER NOT NULL,
  student_limit INTEGER NOT NULL,
  inclusions TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS schools(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  address TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  logo TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'trial',          -- trial|active|suspended|expired
  plan_id INTEGER REFERENCES plans(id),
  renewal_date TEXT DEFAULT '',
  student_limit INTEGER DEFAULT 150,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER REFERENCES schools(id),      -- NULL => super admin
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,                            -- super_admin|admin|accountant|teacher|staff|parent|student
  phone TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  must_change INTEGER NOT NULL DEFAULT 0,        -- 1 => bootstrap credential, must set own password on first login
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS classes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL,
  level INTEGER DEFAULT 0,
  monthly_fee INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sections(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  admission_no TEXT NOT NULL,
  name TEXT NOT NULL,
  father_name TEXT DEFAULT '',
  mother_name TEXT DEFAULT '',
  guardian_phone TEXT DEFAULT '',
  emergency_contact TEXT DEFAULT '',
  gender TEXT DEFAULT '',
  dob TEXT DEFAULT '',
  address TEXT DEFAULT '',
  class_id INTEGER REFERENCES classes(id),
  section_id INTEGER REFERENCES sections(id),
  roll_no TEXT DEFAULT '',
  admission_date TEXT DEFAULT '',
  previous_school TEXT DEFAULT '',
  monthly_fee_override INTEGER,                  -- NULL => class default
  discount INTEGER DEFAULT 0,                    -- monthly discount/scholarship in PKR
  status TEXT NOT NULL DEFAULT 'active',         -- active|withdrawn|transferred|graduated
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(school_id, admission_no)
);
CREATE TABLE IF NOT EXISTS employees(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL,
  designation TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  qualification TEXT DEFAULT '',
  joining_date TEXT DEFAULT '',
  salary INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active'
);
CREATE TABLE IF NOT EXISTS student_attendance(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  date TEXT NOT NULL,
  status TEXT NOT NULL,                          -- present|absent|late|leave
  marked_by INTEGER REFERENCES users(id),
  UNIQUE(school_id, student_id, date)
);
CREATE TABLE IF NOT EXISTS fee_structures(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  class_id INTEGER REFERENCES classes(id),       -- NULL => applies to all classes
  name TEXT NOT NULL,                            -- Tuition Fee, Admission Fee, Exam Fee...
  amount INTEGER NOT NULL,
  frequency TEXT NOT NULL DEFAULT 'monthly'      -- monthly|one_time|annual
);
CREATE TABLE IF NOT EXISTS fee_vouchers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  month TEXT NOT NULL,                           -- YYYY-MM or label like 'Admission'
  issue_date TEXT NOT NULL,
  due_date TEXT NOT NULL,
  total INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'unpaid',         -- unpaid|partial|paid
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(school_id, student_id, month)
);
CREATE TABLE IF NOT EXISTS voucher_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  voucher_id INTEGER NOT NULL REFERENCES fee_vouchers(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  amount INTEGER NOT NULL                        -- negative allowed (discount)
);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  voucher_id INTEGER NOT NULL REFERENCES fee_vouchers(id),
  amount INTEGER NOT NULL,
  date TEXT NOT NULL,
  method TEXT NOT NULL DEFAULT 'cash',           -- cash|bank|other
  reference TEXT DEFAULT '',
  payer TEXT DEFAULT '',
  received_by INTEGER REFERENCES users(id),
  note TEXT DEFAULT '',
  reversed INTEGER NOT NULL DEFAULT 0,
  reversal_reason TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS audit_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER,
  user_id INTEGER,
  action TEXT NOT NULL,
  detail TEXT DEFAULT '',
  ts TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_students_school ON students(school_id, status);
CREATE INDEX IF NOT EXISTS idx_att_school_date ON student_attendance(school_id, date);
CREATE INDEX IF NOT EXISTS idx_vouchers_school ON fee_vouchers(school_id, month, status);
CREATE INDEX IF NOT EXISTS idx_payments_school ON payments(school_id, date);
`);

// ---------- plans seed ----------
const planCount = db.prepare('SELECT COUNT(*) c FROM plans').get().c;
if (planCount === 0) {
  const ins = db.prepare('INSERT INTO plans(name,price_pkr,student_limit,inclusions) VALUES(?,?,?,?)');
  ins.run('Starter', 700000, 150, 'Admissions, student/staff records, attendance, fees, basic exams and reports');
  ins.run('Standard', 1200000, 500, 'Starter + expenses/accounts, salary, parent portal, timetable, detailed reports');
  ins.run('Premium', 2000000, 1000, 'Standard + transport, inventory, analytics, priority support');
}

// ---------- super admin seed ----------
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const h = crypto.scryptSync(pw, salt, 32).toString('hex');
  return `scrypt$${salt}$${h}`;
}
function verifyPassword(pw, stored) {
  try {
    const [, salt, h] = stored.split('$');
    const test = crypto.scryptSync(pw, salt, 32);
    return crypto.timingSafeEqual(Buffer.from(h, 'hex'), test);
  } catch { return false; }
}
const saCount = db.prepare("SELECT COUNT(*) c FROM users WHERE role='super_admin'").get().c;
if (saCount === 0) {
  const user = process.env.SUPER_ADMIN_USER || 'owner';
  let pw = process.env.SUPER_ADMIN_PASSWORD || '';
  let generated = false;
  if (!pw) { pw = crypto.randomBytes(9).toString('base64url'); generated = true; }
  db.prepare("INSERT INTO users(school_id,name,username,password_hash,role,must_change) VALUES(NULL,?,?,?,'super_admin',?)")
    .run('Platform Owner', user, hashPassword(pw), generated ? 1 : 0);
  if (generated) {
    const credFile = path.join(DATA_DIR, 'bootstrap-superadmin.txt');
    fs.writeFileSync(credFile, `Super admin bootstrap (delete after first login + password change)\nusername: ${user}\npassword: ${pw}\n`, { mode: 0o600 });
    console.log(`[schoolhub] Generated super admin credentials written to ${credFile} (mode 600). Set SUPER_ADMIN_USER/SUPER_ADMIN_PASSWORD to control this.`);
  } else console.log(`[schoolhub] Super admin '${user}' created from environment.`);
}

// ---------- demo seed (only with SEED_DEMO=1) ----------
if (process.env.SEED_DEMO === '1') {
  const demo = db.prepare("SELECT id FROM schools WHERE code='demo'").get();
  if (!demo) {
    const sid = db.prepare("INSERT INTO schools(name,code,address,phone,status,plan_id,renewal_date) VALUES('Demo Public School','demo','Main Road, Gujrat','03001234567','active',1,date('now','+30 days'))").run().lastInsertRowid;
    const mkClass = db.prepare('INSERT INTO classes(school_id,name,level,monthly_fee) VALUES(?,?,?,?)');
    const c1 = mkClass.run(sid, 'Class 1', 1, 150000).lastInsertRowid;
    const c5 = mkClass.run(sid, 'Class 5', 5, 200000).lastInsertRowid;
    const mkSec = db.prepare('INSERT INTO sections(class_id,name) VALUES(?,?)');
    const s1a = mkSec.run(c1, 'A').lastInsertRowid;
    mkSec.run(c5, 'A');
    const mkStu = db.prepare("INSERT INTO students(school_id,admission_no,name,father_name,guardian_phone,gender,class_id,section_id,roll_no,admission_date,status) VALUES(?,?,?,?,?,?,?,?,?,?,'active')");
    mkStu.run(sid, 'D-001', 'Ahmed Raza', 'Muhammad Raza', '03011112222', 'M', c1, s1a, '1', '2026-04-01');
    mkStu.run(sid, 'D-002', 'Fatima Noor', 'Noor Ahmed', '03033334444', 'F', c1, s1a, '2', '2026-04-01');
    db.prepare("INSERT INTO users(school_id,name,username,password_hash,role,must_change) VALUES(?,'Demo Principal','demo',?,'admin',1)")
      .run(sid, hashPassword(process.env.DEMO_PASSWORD || 'demo1234'));
    console.log('[schoolhub] Demo school created (code: demo, demo login from env or default password)');
  }
}

// ---------- helpers ----------
const q = {
  get: (sql, ...p) => db.prepare(sql).get(...p),
  all: (sql, ...p) => db.prepare(sql).all(...p),
  run: (sql, ...p) => db.prepare(sql).run(...p),
};
function audit(schoolId, userId, action, detail) {
  q.run('INSERT INTO audit_logs(school_id,user_id,action,detail) VALUES(?,?,?,?)', schoolId, userId, action, String(detail || '').slice(0, 500));
}
function today() { return new Date().toISOString().slice(0, 10); }
function addDays(iso, n) { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }
function monthNow() { return new Date().toISOString().slice(0, 7); }
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  // SPA uses inline event handlers; unsafe-inline scoped to script-src is required until handlers are migrated to addEventListener
  'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'",
};
function bad(res, msg, code) { res.writeHead(code || 400, Object.assign({ 'Content-Type': 'application/json' }, SEC_HEADERS)); res.end(JSON.stringify({ error: msg })); }
function ok(res, data, code) { res.writeHead(code || 200, Object.assign({ 'Content-Type': 'application/json' }, SEC_HEADERS)); res.end(JSON.stringify(data)); }
function vStr(v, max) { if (typeof v !== 'string') return ''; return v.trim().slice(0, max || 200); }
function vInt(v, dflt) { const n = parseInt(v, 10); return Number.isFinite(n) ? n : (dflt === undefined ? null : dflt); }
function vMoney(v) {  // rupees (number/string, decimals allowed) -> integer paisa; null if invalid
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0 || n > 1e10) return null;
  return Math.round(n * 100);
}
function rp(paisa) { const n = Number(paisa || 0) / 100; return n.toLocaleString('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 }); }
function vDate(v) { const s = vStr(v, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ''; }

// ---------- auth ----------
const loginBuckets = new Map();
function bumpBucket(key, limit) {
  const now = Date.now();
  const b = loginBuckets.get(key) || { count: 0, reset: now + 600000 };
  if (now > b.reset) { b.count = 0; b.reset = now + 600000; }
  b.count++; loginBuckets.set(key, b);
  return b.count <= limit;
}
function bucketOk(key, limit) {
  const b = loginBuckets.get(key);
  if (!b || Date.now() > b.reset) return true;
  return b.count < limit;
}
function clientIp(req) {
  if (process.env.TRUST_PROXY === '1') {
    const fwd = req.headers['x-forwarded-for'];
    if (fwd) return String(fwd).split(',')[0].trim();
  }
  return req.socket.remoteAddress || '?';
}
function getSession(req) {
  const m = /(?:^|;\s*)sid=([a-f0-9]{64})/.exec(req.headers.cookie || '');
  if (!m) return null;
  const s = q.get("SELECT s.token, s.expires_at, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND u.status='active'", m[1]);
  if (!s || s.expires_at < new Date().toISOString()) return null;
  return s;
}
const FEE_ROLES = ['admin', 'accountant'];
const WRITE_ROLES = ['admin', 'staff'];
const ATT_ROLES = ['admin', 'teacher', 'staff'];

// ---------- static ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
function serveStatic(req, res, urlPath) {
  let p = urlPath === '/' ? '/index.html' : urlPath;
  const file = path.join(__dirname, 'public', path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(path.join(__dirname, 'public'))) { res.writeHead(403, SEC_HEADERS); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, SEC_HEADERS); return res.end('not found'); }
    res.writeHead(200, Object.assign({ 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }, SEC_HEADERS));
    res.end(data);
  });
}

// ---------- extended schema (full blueprint, all phases) ----------
db.exec(`
CREATE TABLE IF NOT EXISTS academic_sessions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL,
  start_date TEXT DEFAULT '', end_date TEXT DEFAULT '',
  is_current INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS subjects(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  class_id INTEGER REFERENCES classes(id),
  name TEXT NOT NULL,
  teacher_id INTEGER REFERENCES employees(id)
);
CREATE TABLE IF NOT EXISTS timetable_entries(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  class_id INTEGER NOT NULL REFERENCES classes(id),
  section_id INTEGER REFERENCES sections(id),
  day TEXT NOT NULL,
  period INTEGER NOT NULL,
  subject TEXT DEFAULT '',
  teacher_id INTEGER REFERENCES employees(id),
  room TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS guardians(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  cnic TEXT DEFAULT '',
  user_id INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS student_guardians(
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  guardian_id INTEGER NOT NULL REFERENCES guardians(id) ON DELETE CASCADE,
  relation TEXT DEFAULT '',
  UNIQUE(student_id, guardian_id)
);
CREATE TABLE IF NOT EXISTS employee_attendance(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  employee_id INTEGER NOT NULL REFERENCES employees(id),
  date TEXT NOT NULL,
  status TEXT NOT NULL,
  marked_by INTEGER REFERENCES users(id),
  UNIQUE(school_id, employee_id, date)
);
CREATE TABLE IF NOT EXISTS leave_requests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  employee_id INTEGER NOT NULL REFERENCES employees(id),
  from_date TEXT NOT NULL, to_date TEXT NOT NULL,
  reason TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  decided_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS salary_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  employee_id INTEGER NOT NULL REFERENCES employees(id),
  month TEXT NOT NULL,
  amount INTEGER NOT NULL,
  allowances INTEGER DEFAULT 0,
  deductions INTEGER DEFAULT 0,
  date TEXT NOT NULL,
  note TEXT DEFAULT '',
  paid_by INTEGER REFERENCES users(id),
  UNIQUE(school_id, employee_id, month)
);
CREATE TABLE IF NOT EXISTS expense_categories(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS vendors(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL, phone TEXT DEFAULT '', note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS expenses(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  category_id INTEGER REFERENCES expense_categories(id),
  vendor_id INTEGER REFERENCES vendors(id),
  amount INTEGER NOT NULL,
  date TEXT NOT NULL,
  method TEXT NOT NULL DEFAULT 'cash',
  reference TEXT DEFAULT '',
  note TEXT DEFAULT '',
  entered_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS exams(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL,
  class_id INTEGER REFERENCES classes(id),
  start_date TEXT DEFAULT '', end_date TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS exam_subjects(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  max_marks INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE IF NOT EXISTS marks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  exam_subject_id INTEGER NOT NULL REFERENCES exam_subjects(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id),
  obtained REAL,
  absent INTEGER NOT NULL DEFAULT 0,
  entered_by INTEGER REFERENCES users(id),
  updated_at TEXT DEFAULT (datetime('now')),
  UNIQUE(exam_subject_id, student_id)
);
CREATE TABLE IF NOT EXISTS announcements(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER REFERENCES schools(id),
  title TEXT NOT NULL, body TEXT DEFAULT '',
  audience TEXT NOT NULL DEFAULT 'all',
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS homework(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  class_id INTEGER NOT NULL REFERENCES classes(id),
  section_id INTEGER REFERENCES sections(id),
  subject TEXT DEFAULT '',
  title TEXT NOT NULL,
  detail TEXT DEFAULT '',
  due_date TEXT DEFAULT '',
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS library_books(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  title TEXT NOT NULL, author TEXT DEFAULT '', isbn TEXT DEFAULT '',
  copies INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS library_issues(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  book_id INTEGER NOT NULL REFERENCES library_books(id),
  student_id INTEGER REFERENCES students(id),
  employee_id INTEGER REFERENCES employees(id),
  issue_date TEXT NOT NULL, due_date TEXT NOT NULL,
  return_date TEXT DEFAULT '',
  fine INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS transport_routes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL, driver_name TEXT DEFAULT '', driver_phone TEXT DEFAULT '',
  vehicle TEXT DEFAULT '', monthly_fee INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS transport_assignments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  route_id INTEGER NOT NULL REFERENCES transport_routes(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id),
  stop TEXT DEFAULT '',
  UNIQUE(route_id, student_id)
);
CREATE TABLE IF NOT EXISTS inventory_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL, category TEXT DEFAULT '',
  quantity INTEGER NOT NULL DEFAULT 0,
  unit TEXT DEFAULT '', note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  plan_id INTEGER REFERENCES plans(id),
  start_date TEXT NOT NULL, renewal_date TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS subscription_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subscription_id INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL, date TEXT NOT NULL,
  method TEXT DEFAULT 'bank', reference TEXT DEFAULT '',
  confirmed_by INTEGER REFERENCES users(id),
  note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS file_metadata(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  filename TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL,
  uploaded_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_files_owner ON file_metadata(school_id, owner_type, owner_id);
CREATE TABLE IF NOT EXISTS student_documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL,
  title TEXT NOT NULL, body TEXT DEFAULT '',
  issued_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS meetings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  title TEXT NOT NULL, with_whom TEXT DEFAULT '',
  date TEXT NOT NULL, notes TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'scheduled',
  created_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS holidays(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL, date TEXT NOT NULL,
  UNIQUE(school_id, date)
);
CREATE TABLE IF NOT EXISTS complaints(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  from_user_id INTEGER REFERENCES users(id),
  from_name TEXT NOT NULL, category TEXT DEFAULT 'general',
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  response TEXT DEFAULT '', responded_by INTEGER REFERENCES users(id),
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS bank_accounts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  name TEXT NOT NULL, iban TEXT DEFAULT '',
  opening_balance INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS budgets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  category_id INTEGER NOT NULL REFERENCES expense_categories(id),
  month TEXT NOT NULL, amount INTEGER NOT NULL,
  UNIQUE(school_id, category_id, month)
);
CREATE TABLE IF NOT EXISTS student_class_history(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  from_class_id INTEGER, to_class_id INTEGER,
  action TEXT NOT NULL, note TEXT DEFAULT '',
  at TEXT DEFAULT (datetime('now')), by_user INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS subscription_invoices(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subscription_id INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  period_month TEXT NOT NULL,
  amount INTEGER NOT NULL, due_date TEXT NOT NULL,
  paid_amount INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'unpaid',
  created_at TEXT DEFAULT (datetime('now')),
  UNIQUE(subscription_id, period_month)
);
`);
try { db.exec('ALTER TABLE subscription_invoices ADD COLUMN paid_amount INTEGER NOT NULL DEFAULT 0'); } catch {}
// pre-launch schema migrations (idempotent)
try { db.exec("ALTER TABLE exam_subjects ADD COLUMN marks_status TEXT NOT NULL DEFAULT 'draft'"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN student_id INTEGER REFERENCES students(id)"); } catch {}
try { db.exec('ALTER TABLE students ADD COLUMN photo_file_id INTEGER REFERENCES file_metadata(id)'); } catch {}
try { db.exec("ALTER TABLE exams ADD COLUMN term TEXT DEFAULT ''"); } catch {}
try { db.exec('ALTER TABLE subscriptions ADD COLUMN grace_days INTEGER NOT NULL DEFAULT 7'); } catch {}
try { db.exec('ALTER TABLE subscriptions ADD COLUMN restrict_after_grace INTEGER NOT NULL DEFAULT 0'); } catch {}
try { db.exec("ALTER TABLE schools ADD COLUMN late_fee_type TEXT NOT NULL DEFAULT 'flat'"); } catch {}
try { db.exec('ALTER TABLE schools ADD COLUMN late_fee_value INTEGER NOT NULL DEFAULT 0'); } catch {}
try { db.exec('ALTER TABLE schools ADD COLUMN absent_notice INTEGER NOT NULL DEFAULT 0'); } catch {}
try { db.exec('ALTER TABLE announcements ADD COLUMN parent_user_id INTEGER REFERENCES users(id)'); } catch {}
db.exec(`
CREATE TABLE IF NOT EXISTS support_tickets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  school_id INTEGER NOT NULL REFERENCES schools(id),
  subject TEXT NOT NULL, body TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',          -- open|in_progress|resolved|closed
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS support_ticket_replies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  author_user_id INTEGER REFERENCES users(id),
  author_role TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);`);
try { db.exec("CREATE TABLE IF NOT EXISTS session_rollovers(school_id INTEGER NOT NULL, session_name TEXT NOT NULL, at TEXT DEFAULT (datetime('now')), UNIQUE(school_id,session_name))"); } catch {}

// ---------- router ----------
const routes = [];
function route(method, pattern, handler) {
  const keys = [];
  const rx = new RegExp('^' + pattern.replace(/:([a-zA-Z_]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, rx, keys, handler });
}
route('GET', '/api/health', async (req, res) => ok(res, { ok: true, ts: Date.now() }));
function readBody(req) {
  return new Promise((resolve) => {
    let data = '', tooBig = false;
    if (Number(req.headers['content-length']) > 8e6) tooBig = true;
    req.on('data', (c) => {
      if (tooBig) { if (Number(req.headers['content-length']) > 32e6 || c.length > 32e6) req.destroy(); return; } // drain, then 413
      data += c;
      if (data.length > 8e6) { tooBig = true; data = ''; }
      if (data.length > 32e6) { req.destroy(); }
    });
    req.on('end', () => {
      if (tooBig) return resolve({ __tooBig: true });
      req.rawBody = data;
      try { resolve(data ? JSON.parse(data) : {}); } catch { resolve(null); }
    });
    req.on('error', () => resolve(null));
  });
}

// ---------- auth routes ----------
route('POST', '/api/login', async (req, res) => {
  const b = req.body;
  const uname = vStr(b.username, 60);
  const ip = clientIp(req);
  if (!bucketOk('ip:' + ip, 30) || !bucketOk('user:' + uname, 10)) return bad(res, 'Too many attempts, try later', 429);
  const u = q.get('SELECT * FROM users WHERE username=?', uname);
  if (!u || !verifyPassword(String(b.password || ''), u.password_hash)) {
    bumpBucket('ip:' + ip, 30); bumpBucket('user:' + uname, 10);
    return bad(res, 'Wrong username or password', 401);
  }
  if (u.status !== 'active') return bad(res, 'Account disabled', 403);
  if (u.school_id) {
    const sch = q.get('SELECT status FROM schools WHERE id=?', u.school_id);
    if (sch && sch.status === 'suspended') return bad(res, 'School account suspended. Contact support.', 403);
  }
  q.run("DELETE FROM sessions WHERE expires_at < datetime('now')");
  const token = crypto.randomBytes(32).toString('hex');
  q.run("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,datetime('now','+30 days'))", token, u.id);
  audit(u.school_id, u.id, 'login', u.username);
  const secure = (req.headers['x-forwarded-proto'] === 'https') ? '; Secure' : '';
  res.writeHead(200, { 'Content-Type': 'application/json', 'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secure}` });
  res.end(JSON.stringify({ user: pubUser(u) }));
});
route('POST', '/api/logout', async (req, res) => {
  const s = getSession(req);
  if (s) q.run('DELETE FROM sessions WHERE token=?', s.token);
  res.writeHead(200, { 'Content-Type': 'application/json', 'Set-Cookie': 'sid=; HttpOnly; Path=/; Max-Age=0' });
  res.end('{"ok":true}');
});
route('GET', '/api/me', async (req, res) => {
  const s = getSession(req);
  if (!s) return bad(res, 'Not logged in', 401);
  ok(res, { user: pubUser(s) });
});
function pubUser(u) {
  const sch = u.school_id ? q.get('SELECT id,name,code,status FROM schools WHERE id=?', u.school_id) : null;
  return { id: u.id, name: u.name, username: u.username, role: u.role, school_id: u.school_id, student_id: u.student_id || null, school_name: sch ? sch.name : null, school_status: sch ? sch.status : null, must_change: !!u.must_change };
}

route('POST', '/api/change-password', async (req, res) => {
  const u = needAuth(req, res); if (!u) return;
  const b = req.body;
  const cur = String(b.current_password || '');
  const nw = String(b.new_password || '');
  if (!verifyPassword(cur, u.password_hash)) return bad(res, 'Current password wrong', 403);
  if (nw.length < 8) return bad(res, 'New password 8+ chars');
  if (nw === u.username) return bad(res, 'Password must differ from username');
  q.run('UPDATE users SET password_hash=?, must_change=0 WHERE id=?', hashPassword(nw), u.id);
  q.run('DELETE FROM sessions WHERE user_id=? AND token != ?', u.id, u.token || (getSession(req) || {}).token);
  if (u.role === 'super_admin') { try { fs.unlinkSync(path.join(DATA_DIR, 'bootstrap-superadmin.txt')); } catch {} }
  audit(u.school_id, u.id, 'password_change', u.username);
  ok(res, { ok: true });
});

// ---------- R8: late fees, grace config, support tickets, payslips, progress, xlsx ----------
route('POST', '/api/fees/vouchers/:id/late-fee', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant']); if (!u) return;
  const v = q.get('SELECT * FROM fee_vouchers WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!v) return bad(res, 'Not found', 404);
  const sch = q.get('SELECT late_fee_type, late_fee_value FROM schools WHERE id=?', u.school_id);
  if (!sch || !sch.late_fee_value) return bad(res, 'Late fee rule not configured (Settings)', 400);
  const paid = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
  const outstanding = v.total - paid;
  if (outstanding <= 0) return bad(res, 'Voucher fully paid', 400);
  if (v.due_date >= today()) return bad(res, 'Voucher not overdue yet', 400);
  const dup = q.get("SELECT id FROM voucher_items WHERE voucher_id=? AND name LIKE 'Late fee%'", v.id);
  if (dup) return bad(res, 'Late fee already applied to this voucher', 400);
  const amount = sch.late_fee_type === 'percent' ? Math.round(outstanding * sch.late_fee_value / 100) : sch.late_fee_value;
  if (amount <= 0) return bad(res, 'Computed late fee is zero', 400);
  q.run('INSERT INTO voucher_items(voucher_id,name,amount) VALUES(?,?,?)', v.id, `Late fee (overdue since ${v.due_date})`, amount);
  q.run('UPDATE fee_vouchers SET total=total+? WHERE id=?', amount, v.id);
  audit(u.school_id, u.id, 'late_fee', `voucher #${v.id}: +${amount / 100} PKR (${sch.late_fee_type} ${sch.late_fee_value})`);
  ok(res, { ok: true, amount, new_total: v.total + amount });
});

route('PATCH', '/api/super/subscriptions/:id', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const sub = q.get('SELECT * FROM subscriptions WHERE id=?', m.id);
  if (!sub) return bad(res, 'Not found', 404);
  const b = req.body;
  const grace = b.grace_days !== undefined ? Math.min(90, Math.max(0, vInt(b.grace_days) ?? sub.grace_days)) : sub.grace_days;
  const restrict = b.restrict_after_grace !== undefined ? (b.restrict_after_grace ? 1 : 0) : sub.restrict_after_grace;
  const renewal = b.renewal_date !== undefined ? (vDate(b.renewal_date) || sub.renewal_date) : sub.renewal_date;
  const status = b.status !== undefined && ['active', 'suspended', 'expired'].includes(b.status) ? b.status : sub.status;
  const planId = b.plan_id !== undefined ? vInt(b.plan_id) : sub.plan_id;
  if (planId !== sub.plan_id && planId !== null && !q.get('SELECT id FROM plans WHERE id=?', planId)) return bad(res, 'Plan not found', 400);
  q.run('UPDATE subscriptions SET grace_days=?, restrict_after_grace=?, renewal_date=?, status=?, plan_id=? WHERE id=?',
    grace, restrict, renewal, status, planId, sub.id);
  audit(sub.school_id, u.id, 'subscription_update',
    `#${sub.id}: grace ${sub.grace_days}->${grace}, restrict ${sub.restrict_after_grace}->${restrict}, renewal ${sub.renewal_date}->${renewal}, status ${sub.status}->${status}, plan ${sub.plan_id}->${planId}`);
  ok(res, { ok: true });
});

// support tickets: school side
route('POST', '/api/tickets', async (req, res) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'teacher', 'staff']); if (!u) return;
  const b = req.body;
  const subject = vStr(b.subject, 120); if (!subject) return bad(res, 'Subject required');
  const id = q.run('INSERT INTO support_tickets(school_id,subject,body,created_by) VALUES(?,?,?,?)',
    u.school_id, subject, vStr(b.body, 2000) || '', u.id).lastInsertRowid;
  audit(u.school_id, u.id, 'ticket_create', `#${id}: ${subject}`);
  ok(res, { id }, 201);
});
route('GET', '/api/tickets', async (req, res) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'teacher', 'staff']); if (!u) return;
  const tickets = q.all('SELECT * FROM support_tickets WHERE school_id=? ORDER BY id DESC LIMIT 200', u.school_id)
    .map((t) => Object.assign({}, t, { replies: q.all('SELECT author_role, body, created_at FROM support_ticket_replies WHERE ticket_id=? ORDER BY id', t.id) }));
  ok(res, { tickets });
});
route('POST', '/api/tickets/:id/replies', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'teacher', 'staff']); if (!u) return;
  const t = q.get('SELECT * FROM support_tickets WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!t) return bad(res, 'Not found', 404);
  const body = vStr(req.body.body, 2000); if (!body) return bad(res, 'Reply text required');
  q.run('INSERT INTO support_ticket_replies(ticket_id,author_user_id,author_role,body) VALUES(?,?,?,?)', t.id, u.id, 'school', body);
  q.run("UPDATE support_tickets SET updated_at=datetime('now'), status=CASE WHEN status='resolved' THEN 'in_progress' ELSE status END WHERE id=?", t.id);
  ok(res, { ok: true }, 201);
});
route('PATCH', '/api/tickets/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'teacher', 'staff']); if (!u) return;
  const t = q.get('SELECT * FROM support_tickets WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!t) return bad(res, 'Not found', 404);
  if (req.body.status !== 'closed') return bad(res, 'School can only close its ticket', 400);
  q.run("UPDATE support_tickets SET status='closed', updated_at=datetime('now') WHERE id=?", t.id);
  audit(u.school_id, u.id, 'ticket_close', `#${t.id}`);
  ok(res, { ok: true });
});
// support tickets: super side
route('GET', '/api/super/tickets', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  const tickets = q.all(`SELECT t.*, s.name school_name FROM support_tickets t JOIN schools s ON s.id=t.school_id ORDER BY
    CASE t.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 ELSE 2 END, t.id DESC LIMIT 500`)
    .map((t) => Object.assign({}, t, { replies: q.all('SELECT author_role, body, created_at FROM support_ticket_replies WHERE ticket_id=? ORDER BY id', t.id) }));
  ok(res, { tickets });
});
route('PATCH', '/api/super/tickets/:id', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const t = q.get('SELECT * FROM support_tickets WHERE id=?', m.id);
  if (!t) return bad(res, 'Not found', 404);
  const st = req.body.status;
  if (!['open', 'in_progress', 'resolved', 'closed'].includes(st)) return bad(res, 'Invalid status', 400);
  q.run("UPDATE support_tickets SET status=?, updated_at=datetime('now') WHERE id=?", st, t.id);
  audit(t.school_id, u.id, 'ticket_status', `#${t.id}: ${t.status} -> ${st}`);
  ok(res, { ok: true });
});
route('POST', '/api/super/tickets/:id/replies', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const t = q.get('SELECT * FROM support_tickets WHERE id=?', m.id);
  if (!t) return bad(res, 'Not found', 404);
  const body = vStr(req.body.body, 2000); if (!body) return bad(res, 'Reply text required');
  q.run('INSERT INTO support_ticket_replies(ticket_id,author_user_id,author_role,body) VALUES(?,?,?,?)', t.id, u.id, 'platform', body);
  q.run("UPDATE support_tickets SET updated_at=datetime('now'), status=CASE WHEN status='open' THEN 'in_progress' ELSE status END WHERE id=?", t.id);
  ok(res, { ok: true }, 201);
});

// printable payslip
route('GET', '/api/salaries/:id/payslip.pdf', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant']); if (!u) return;
  const p = q.get(`SELECT sp.*, e.name employee_name, e.designation, e.employee_no, s.name school_name, s.address school_address
    FROM salary_payments sp JOIN employees e ON e.id=sp.employee_id JOIN schools s ON s.id=sp.school_id
    WHERE sp.id=? AND sp.school_id=?`, m.id, u.school_id);
  if (!p) return bad(res, 'Not found', 404);
  const net = p.amount + (p.allowances || 0) - (p.deductions || 0);
  const lines = [
    { text: p.school_name, size: 18 }, { text: p.school_address || '', size: 9 },
    { text: `Salary Slip - ${p.month}`, size: 14 }, { text: '', size: 6 },
    { text: `Employee: ${p.employee_name} (${p.employee_no || '-'})`, size: 11 },
    { text: `Designation: ${p.designation || '-'}`, size: 11 }, { text: '', size: 6 },
    { text: `Base salary: Rs ${rp(p.amount)}`, size: 11 },
    { text: `Allowances: Rs ${rp(p.allowances || 0)}`, size: 11 },
    { text: `Deductions: Rs ${rp(p.deductions || 0)}`, size: 11 },
    { text: `Net paid: Rs ${rp(net)}`, size: 13 },
    { text: `Payment date: ${p.date}${p.note ? '   Note: ' + p.note : ''}`, size: 10 }, { text: '', size: 10 },
    { text: 'Developed by Chaudhry Noman - Powered by Alpha Blue Digital', size: 8 },
  ];
  const pdf = makePdf(lines);
  res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="payslip-${p.employee_no || p.employee_id}-${p.month}.pdf"` });
  res.end(pdf);
});

// term-to-term progress comparison
function studentProgress(sid, studentId) {
  const rows = q.all(`SELECT e.name exam, e.term, e.start_date, es.subject, es.max_marks, m.obtained, m.absent
    FROM marks m JOIN exam_subjects es ON es.id=m.exam_subject_id JOIN exams e ON e.id=es.exam_id
    WHERE m.school_id=? AND m.student_id=? AND m.obtained IS NOT NULL ORDER BY e.start_date, e.id`, sid, studentId);
  const subjects = {}, terms = {};
  for (const r of rows) {
    const pct = r.max_marks ? Math.round((r.obtained / r.max_marks) * 1000) / 10 : 0;
    (subjects[r.subject] = subjects[r.subject] || []).push({ exam: r.exam, term: r.term || '', date: r.start_date, pct });
    const tk = r.term || 'General';
    terms[tk] = terms[tk] || { total: 0, n: 0 };
    terms[tk].total += pct; terms[tk].n++;
  }
  const termAvg = Object.entries(terms).map(([term, t]) => ({ term, average_pct: Math.round((t.total / t.n) * 10) / 10 }));
  return { subjects, terms: termAvg };
}
route('GET', '/api/students/:id/progress', async (req, res, m) => {
  const u = needSchool(req, res); if (!u) return;
  const stu = q.get('SELECT id FROM students WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!stu) return bad(res, 'Not found', 404);
  ok(res, studentProgress(u.school_id, stu.id));
});

// native .xlsx export (zero-dependency writer)
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
function crc32(buf) { let c = 0xFFFFFFFF; for (const b of buf) c = CRC_T[(c ^ b) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zipStore(entries) {
  const chunks = [], central = []; let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name), data = e.data, crc = crc32(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0, 6); lh.writeUInt16LE(0, 8);
    lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(data.length, 18);
    lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    chunks.push(lh, name, data);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0, 8);
    ch.writeUInt16LE(0, 10); ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(data.length, 20);
    ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt16LE(0, 30); ch.writeUInt16LE(0, 32);
    ch.writeUInt16LE(0, 34); ch.writeUInt16LE(0, 36); ch.writeUInt32LE(0, 38); ch.writeUInt32LE(offset, 42);
    central.push(Buffer.concat([ch, name])); offset += 30 + name.length + data.length;
  }
  const cd = Buffer.concat(central);
  const eocd = Buffer.alloc(22); eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cd.length, 12); eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...chunks, cd, eocd]);
}
function xlsxEscape(v) { return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function colName(i) { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
function xlsxBuffer(rows) {
  const sheet = rows.map((r, ri) => '<row r="' + (ri + 1) + '">' + r.map((c, ci) =>
    typeof c === 'number'
      ? `<c r="${colName(ci)}${ri + 1}"><v>${c}</v></c>`
      : `<c r="${colName(ci)}${ri + 1}" t="inlineStr"><is><t>${xlsxEscape(c)}</t></is></c>`).join('') + '</row>').join('');
  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheet}</sheetData></worksheet>`;
  const wb = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Export" sheetId="1" r:id="rId1"/></sheets></workbook>`;
  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
  const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
  return zipStore([
    { name: '[Content_Types].xml', data: Buffer.from(ct) },
    { name: '_rels/.rels', data: Buffer.from(rootRels) },
    { name: 'xl/workbook.xml', data: Buffer.from(wb) },
    { name: 'xl/_rels/workbook.xml.rels', data: Buffer.from(rels) },
    { name: 'xl/worksheets/sheet1.xml', data: Buffer.from(sheetXml) },
  ]);
}
function sendXlsx(res, filename, rows) {
  const buf = xlsxBuffer(rows);
  res.writeHead(200, { 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': `attachment; filename="${filename}"` });
  res.end(buf);
}
route('GET', '/api/students.xlsx', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const rows = q.all(`SELECT s.*, c.name class_name, sec.name section_name FROM students s
    LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id WHERE s.school_id=? ORDER BY s.id`, u.school_id);
  sendXlsx(res, 'students.xlsx', [['admission_no', 'name', 'father_name', 'mother_name', 'guardian_phone', 'gender', 'dob', 'class', 'section', 'roll_no', 'admission_date', 'discount_pkr', 'status'],
    ...rows.map((s) => [s.admission_no, s.name, s.father_name, s.mother_name, s.guardian_phone, s.gender, s.dob, s.class_name, s.section_name, s.roll_no, s.admission_date, (s.discount || 0) / 100, s.status])]);
});
route('GET', '/api/fees/collection.xlsx', async (req, res, m, b, url) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const month = vStr(url.searchParams.get('month'), 7) || monthNow();
  const daily = q.all(`SELECT date, method, SUM(amount) total, COUNT(*) count FROM payments
    WHERE school_id=? AND reversed=0 AND strftime('%Y-%m',date)=? GROUP BY date, method ORDER BY date`, u.school_id, month);
  sendXlsx(res, `collection-${month}.xlsx`, [['date', 'method', 'total_pkr', 'receipts'], ...daily.map((d) => [d.date, d.method, d.total / 100, d.count]),
    ['TOTAL', '', daily.reduce((t, r) => t + r.total, 0) / 100, daily.reduce((t, r) => t + r.count, 0)]]);
});

// ---------- access guards ----------
const MUST_CHANGE_ALLOWED = ['/api/me', '/api/change-password', '/api/logout'];
function needAuth(req, res) {
  const u = getSession(req);
  if (!u) { bad(res, 'Not logged in', 401); return null; }
  if (u.must_change && !MUST_CHANGE_ALLOWED.includes((req.url || '').split('?')[0])) { bad(res, 'Password change required before using the system', 403); return null; }
  return u;
}
function needSuper(req, res) {
  const u = needAuth(req, res);
  if (!u) return null;
  if (u.role !== 'super_admin') { bad(res, 'Super admin only', 403); return null; }
  return u;
}
function needSchool(req, res, roles) {
  const u = needAuth(req, res);
  if (!u) return null;
  if (u.role === 'super_admin') { bad(res, 'Use super admin panel', 403); return null; }
  if (!u.school_id) { bad(res, 'No school', 403); return null; }
  const sch = q.get('SELECT status FROM schools WHERE id=?', u.school_id);
  if (sch && sch.status === 'suspended') { bad(res, 'School account suspended', 403); return null; }
  if (sch && req.method !== 'GET') {
    const path = (req.url || '').split('?')[0];
    const exempt = ['/api/export', '/api/change-password', '/api/logout'];
    if (!exempt.includes(path)) {
      const sub = q.get('SELECT renewal_date, grace_days, restrict_after_grace, status FROM subscriptions WHERE school_id=? ORDER BY id DESC LIMIT 1', u.school_id);
      if (sub && sub.restrict_after_grace && sub.status !== 'suspended' && sub.renewal_date) {
        const expiry = addDays(sub.renewal_date, sub.grace_days || 0);
        if (today() > expiry) { bad(res, `Subscription grace period expired (${expiry}). Records preserved; export available; contact platform to renew.`, 402); return null; }
      }
    }
  }
  const allow = roles || READ_ROLES;   // default-deny: parent/student must be explicitly listed
  if (!allow.includes(u.role)) { bad(res, 'Not permitted for your role', 403); return null; }
  return u;
}
const READ_ROLES = ['admin', 'accountant', 'teacher', 'staff'];
const ALL_SCHOOL_ROLES = ['admin', 'accountant', 'teacher', 'staff', 'parent', 'student'];
function sectionCheck(schoolId, sectionId, classId) {
  if (sectionId === undefined || sectionId === null) return null;
  const sec = q.get('SELECT x.id, x.class_id FROM sections x JOIN classes c ON c.id=x.class_id WHERE x.id=? AND c.school_id=?', vInt(sectionId), schoolId);
  if (!sec) return 'Section not in your school';
  if (classId !== undefined && classId !== null && Number(vInt(classId)) !== sec.class_id) return 'Section does not belong to the selected class';
  return null;
}

// ---------- super admin routes ----------
route('GET', '/api/super/overview', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  const sch = q.all("SELECT status, COUNT(*) c FROM schools GROUP BY status");
  const counts = {}; sch.forEach((r) => { counts[r.status] = r.c; });
  const mrr = q.get("SELECT COALESCE(SUM(p.price_pkr),0) m FROM schools s JOIN plans p ON p.id=s.plan_id WHERE s.status='active'").m;
  const students = q.get('SELECT COUNT(*) c FROM students').c;
  const renewals = q.all("SELECT s.id,s.name,s.renewal_date,p.name plan FROM schools s LEFT JOIN plans p ON p.id=s.plan_id WHERE s.status IN ('active','trial') AND s.renewal_date <= date('now','+14 days') ORDER BY s.renewal_date LIMIT 20");
  ok(res, { schools: counts, mrr, students_total: students, renewals_due: renewals });
});
route('GET', '/api/super/schools', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  const rows = q.all(`SELECT s.*, p.name plan_name,
    (SELECT COUNT(*) FROM students st WHERE st.school_id=s.id AND st.status='active') students,
    (SELECT COUNT(*) FROM users us WHERE us.school_id=s.id) users
    FROM schools s LEFT JOIN plans p ON p.id=s.plan_id ORDER BY s.id DESC`);
  ok(res, { schools: rows });
});
route('POST', '/api/super/schools', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 120); if (!name) return bad(res, 'School name required');
  let code = vStr(b.code, 40).toLowerCase().replace(/[^a-z0-9-]/g, '');
  if (!code) code = 'school-' + Date.now().toString(36);
  if (q.get('SELECT id FROM schools WHERE code=?', code)) return bad(res, 'Code already used, choose another');
  const plan = q.get('SELECT * FROM plans WHERE id=?', vInt(b.plan_id)) || q.get('SELECT * FROM plans ORDER BY id LIMIT 1');
  const r = q.run('INSERT INTO schools(name,code,address,phone,status,plan_id,renewal_date,student_limit) VALUES(?,?,?,?,?,?,?,?)',
    name, code, vStr(b.address, 200), vStr(b.phone, 40), vStr(b.status, 12) || 'trial', plan ? plan.id : null,
    vDate(b.renewal_date) || q.get("SELECT date('now','+30 days') d").d, plan ? plan.student_limit : 150);
  const sid = r.lastInsertRowid;
  if (plan) q.run('INSERT INTO subscriptions(school_id,plan_id,start_date,renewal_date,amount,status) VALUES(?,?,?,?,?,?)',
    sid, plan.id, today(), vDate(b.renewal_date) || q.get("SELECT date('now','+30 days') d").d, plan.price_pkr, 'active');
  audit(null, u.id, 'school_create', `${name} (${code})`);
  ok(res, { id: sid, code }, 201);
});
route('PATCH', '/api/super/schools/:id', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const s = q.get('SELECT * FROM schools WHERE id=?', m.id); if (!s) return bad(res, 'Not found', 404);
  const b = req.body;
  const status = ['trial', 'active', 'suspended', 'expired'].includes(b.status) ? b.status : s.status;
  q.run('UPDATE schools SET name=?,address=?,phone=?,status=?,plan_id=?,renewal_date=?,student_limit=? WHERE id=?',
    vStr(b.name, 120) || s.name, b.address !== undefined ? vStr(b.address, 200) : s.address,
    b.phone !== undefined ? vStr(b.phone, 40) : s.phone, status,
    b.plan_id !== undefined ? vInt(b.plan_id) : s.plan_id,
    b.renewal_date !== undefined ? vDate(b.renewal_date) : s.renewal_date,
    b.student_limit !== undefined ? vInt(b.student_limit, s.student_limit) : s.student_limit, s.id);
  if (b.renewal_date !== undefined && vDate(b.renewal_date))
    q.run('UPDATE subscriptions SET renewal_date=? WHERE school_id=?', vDate(b.renewal_date), s.id);
  if (status !== s.status) audit(s.id, u.id, 'school_status', `${s.status} -> ${status}`);
  ok(res, { ok: true });
});
route('POST', '/api/super/schools/:id/admin', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const s = q.get('SELECT * FROM schools WHERE id=?', m.id); if (!s) return bad(res, 'Not found', 404);
  const b = req.body;
  const name = vStr(b.name, 100), uname = vStr(b.username, 60);
  const pw = String(b.password || '');
  if (!name || !uname || pw.length < 8) return bad(res, 'name, username and password (8+ chars) required');
  if (q.get('SELECT id FROM users WHERE username=?', uname)) return bad(res, 'Username already taken');
  const r = q.run("INSERT INTO users(school_id,name,username,password_hash,role,phone,must_change) VALUES(?,?,?,?,'admin',?,1)",
    s.id, name, uname, hashPassword(pw), vStr(b.phone, 40));
  audit(s.id, u.id, 'school_admin_create', uname);
  ok(res, { id: r.lastInsertRowid }, 201);
});
route('GET', '/api/super/plans', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  ok(res, { plans: q.all('SELECT * FROM plans ORDER BY price_pkr'), pricing_note: 'Illustrative proposed rates - editable. Not approved customer terms; no school is charged or suspended automatically from these.' });
});
route('POST', '/api/super/plans', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 60), price = vMoney(b.price_pkr), limit = vInt(b.student_limit, 150);
  if (!name || !price) return bad(res, 'name and price_pkr required');
  try { q.run('INSERT INTO plans(name,price_pkr,student_limit,inclusions) VALUES(?,?,?,?)', name, price, limit, vStr(b.inclusions, 300)); }
  catch { return bad(res, 'Plan name exists'); }
  ok(res, { ok: true }, 201);
});
route('PATCH', '/api/super/plans/:id', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const p = q.get('SELECT * FROM plans WHERE id=?', m.id); if (!p) return bad(res, 'Not found', 404);
  const b = req.body;
  q.run('UPDATE plans SET price_pkr=?,student_limit=?,inclusions=? WHERE id=?',
    b.price_pkr !== undefined ? (vMoney(b.price_pkr) ?? p.price_pkr) : p.price_pkr,
    b.student_limit !== undefined ? vInt(b.student_limit, p.student_limit) : p.student_limit,
    b.inclusions !== undefined ? vStr(b.inclusions, 300) : p.inclusions, p.id);
  ok(res, { ok: true });
});
route('POST', '/api/super/subscriptions/:id/payment', async (req, res, m) => {
  const u = needSuper(req, res); if (!u) return;
  const sub = q.get('SELECT * FROM subscriptions WHERE id=?', m.id); if (!sub) return bad(res, 'Not found', 404);
  const b = req.body;
  const amt = b.amount !== undefined ? vMoney(b.amount) : sub.amount;
  if (!amt || amt <= 0) return bad(res, 'amount required');
  if (b.extend_renewal) {
    const nd = vDate(b.extend_renewal);
    if (!nd || nd < today()) return bad(res, 'extend_renewal must be a valid future date (YYYY-MM-DD)');
  }
  ensureRenewalInvoices();
  const open = q.all("SELECT * FROM subscription_invoices WHERE subscription_id=? AND status != 'paid' ORDER BY period_month", sub.id);
  const outstanding = open.reduce((t, inv) => t + (inv.amount - inv.paid_amount), 0);
  if (outstanding <= 0) return bad(res, 'No outstanding invoice for this subscription - nothing to pay');
  if (amt > outstanding) return bad(res, `Amount exceeds outstanding balance of Rs ${rp(outstanding)} - partial overpayment is not accepted`);
  db.exec('BEGIN IMMEDIATE');
  try {
    q.run('INSERT INTO subscription_payments(subscription_id,amount,date,method,reference,confirmed_by,note) VALUES(?,?,?,?,?,?,?)',
      sub.id, amt, vDate(b.date) || today(), vStr(b.method, 20) || 'bank', vStr(b.reference, 80), u.id, vStr(b.note, 200));
    if (b.extend_renewal) q.run("UPDATE subscriptions SET renewal_date=?, status='active' WHERE id=?", vDate(b.extend_renewal), sub.id);
    // allocate payment against oldest unpaid/partial invoices; only fully covered invoices close
    let left = amt;
    for (const inv of open) {
      if (left <= 0) break;
      const applied = Math.min(left, inv.amount - inv.paid_amount);
      const np = inv.paid_amount + applied;
      q.run("UPDATE subscription_invoices SET paid_amount=?, status=? WHERE id=?", np, np >= inv.amount ? 'paid' : 'partial', inv.id);
      left -= applied;
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); return bad(res, 'Payment failed: ' + e.message, 500); }
  audit(sub.school_id, u.id, 'subscription_payment', `Rs ${rp(amt)} for school #${sub.school_id}`);
  ok(res, { ok: true }, 201);
});
function ensureRenewalInvoices() {
  const soon = q.all(`SELECT sub.*, p.name plan_name FROM subscriptions sub LEFT JOIN plans p ON p.id=sub.plan_id
    WHERE sub.status='active' AND length(sub.renewal_date)=10 AND sub.renewal_date <= date('now','+30 days')`);
  const ins = db.prepare(`INSERT INTO subscription_invoices(subscription_id,school_id,period_month,amount,due_date)
    VALUES(?,?,?,?,?) ON CONFLICT(subscription_id,period_month) DO NOTHING`);
  let created = 0;
  for (const sub of soon) {
    const period = String(sub.renewal_date).slice(0, 7);
    const r = ins.run(sub.id, sub.school_id, period, sub.amount, sub.renewal_date);
    if (r.changes) created++;
  }
  return created;
}
route('GET', '/api/super/renewals', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  ensureRenewalInvoices();
  const rows = q.all(`SELECT si.*, s.name school_name, s.phone school_phone, sub.renewal_date, p.name plan_name
    FROM subscription_invoices si JOIN schools s ON s.id=si.school_id
    JOIN subscriptions sub ON sub.id=si.subscription_id LEFT JOIN plans p ON p.id=sub.plan_id
    WHERE si.status IN ('unpaid','partial') ORDER BY si.due_date`);
  const withLinks = rows.map((r) => Object.assign({}, r, {
    reminder_url: r.school_phone ? 'https://wa.me/' + String(r.school_phone).replace(/\D/g, '').replace(/^0/, '92') +
      '?text=' + encodeURIComponent(`SchoolHub subscription reminder: ${r.school_name} - Rs ${rp(r.amount)} for ${r.period_month}, due ${r.due_date}.`) : null }));
  ok(res, { renewals: withLinks });
});
route('GET', '/api/super/subscriptions', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  ensureRenewalInvoices();
  const subs = q.all(`SELECT sub.*, s.name school_name, p.name plan_name FROM subscriptions sub
    JOIN schools s ON s.id=sub.school_id LEFT JOIN plans p ON p.id=sub.plan_id ORDER BY sub.renewal_date`);
  const pays = q.all(`SELECT sp.*, s.name school_name FROM subscription_payments sp
    JOIN subscriptions sub ON sub.id=sp.subscription_id JOIN schools s ON s.id=sub.school_id ORDER BY sp.date DESC LIMIT 100`);
  const invoices = q.all('SELECT si.*, s.name school_name FROM subscription_invoices si JOIN schools s ON s.id=si.school_id ORDER BY si.due_date DESC LIMIT 200');
  ok(res, { subscriptions: subs, payments: pays, invoices });
});
route('GET', '/api/super/audit', async (req, res) => {
  const u = needSuper(req, res); if (!u) return;
  ok(res, { logs: q.all('SELECT a.*, u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200') });
});

// ---------- school: profile & dashboard ----------
route('GET', '/api/school', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  const s = q.get('SELECT id,name,code,address,phone,logo,status FROM schools WHERE id=?', u.school_id);
  const sub = q.get(`SELECT sub.*, p.name plan_name, p.student_limit FROM subscriptions sub LEFT JOIN plans p ON p.id=sub.plan_id WHERE sub.school_id=? ORDER BY sub.id DESC LIMIT 1`, u.school_id);
  ok(res, { school: s, subscription: sub });
});
route('PATCH', '/api/school', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const s = q.get('SELECT * FROM schools WHERE id=?', u.school_id);
  const b = req.body;
  const lft = b.late_fee_type !== undefined && ['flat', 'percent'].includes(b.late_fee_type) ? b.late_fee_type : s.late_fee_type;
  const lfv = b.late_fee_value !== undefined
    ? (lft === 'percent' ? Math.min(100, Math.max(0, vInt(b.late_fee_value) ?? 0)) : (vMoney(b.late_fee_value) ?? 0))
    : s.late_fee_value;
  const abn = b.absent_notice !== undefined ? (b.absent_notice ? 1 : 0) : s.absent_notice;
  q.run('UPDATE schools SET name=?,address=?,phone=?,logo=?,late_fee_type=?,late_fee_value=?,absent_notice=? WHERE id=?',
    vStr(b.name, 120) || s.name, b.address !== undefined ? vStr(b.address, 200) : s.address,
    b.phone !== undefined ? vStr(b.phone, 40) : s.phone, b.logo !== undefined ? vStr(b.logo, 300) : s.logo,
    lft, lfv, abn, u.school_id);
  if (lft !== s.late_fee_type || lfv !== s.late_fee_value || abn !== s.absent_notice)
    audit(u.school_id, u.id, 'school_settings', `late_fee ${s.late_fee_type}/${s.late_fee_value} -> ${lft}/${lfv}; absent_notice ${s.absent_notice} -> ${abn}`);
  ok(res, { ok: true });
});
route('GET', '/api/dashboard', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  const sid = u.school_id;
  const students = q.get("SELECT COUNT(*) c FROM students WHERE school_id=? AND status='active'", sid).c;
  const teachers = q.get("SELECT COUNT(*) c FROM employees WHERE school_id=? AND status='active' AND (LOWER(designation) LIKE '%teacher%' OR designation='')", sid).c;
  const staffAll = q.get("SELECT COUNT(*) c FROM employees WHERE school_id=? AND status='active'", sid).c;
  const att = q.all(`SELECT status, COUNT(*) c FROM student_attendance WHERE school_id=? AND date=? GROUP BY status`, sid, today());
  const attMap = {}; att.forEach((r) => { attMap[r.status] = r.c; });
  const collected = q.get("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE school_id=? AND reversed=0 AND strftime('%Y-%m',date)=?", sid, monthNow()).s;
  const pending = q.get(`SELECT COALESCE(SUM(v.total - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.voucher_id=v.id AND p.reversed=0),0)),0) s
    FROM fee_vouchers v WHERE v.school_id=? AND v.status!='paid'`, sid).s;
  const expenses = q.get("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE school_id=? AND strftime('%Y-%m',date)=?", sid, monthNow()).s;
  const salaries = q.get("SELECT COALESCE(SUM(salary),0) s FROM employees WHERE school_id=? AND status='active'", sid).s;
  const exams = q.all("SELECT id,name,start_date FROM exams WHERE school_id=? AND start_date>=? ORDER BY start_date LIMIT 5", sid, today());
  const seeMoney = FEE_ROLES.includes(u.role);
  // low-attendance alerts: active students below 75% presence over the last 30 days (min 5 marked days)
  const lowAtt = q.all(`SELECT st.id, st.name, c.name class_name,
      SUM(CASE WHEN sa.status='present' THEN 1 ELSE 0 END) p, SUM(CASE WHEN sa.status='absent' THEN 1 ELSE 0 END) a
    FROM student_attendance sa JOIN students st ON st.id=sa.student_id LEFT JOIN classes c ON c.id=st.class_id
    WHERE sa.school_id=? AND sa.date>=date('now','-30 days') AND st.status='active'
    GROUP BY st.id HAVING (p+a) >= 5 AND (p*1.0/(p+a)) < 0.75
    ORDER BY (p*1.0/(p+a)) LIMIT 20`, sid)
    .map((r) => ({ id: r.id, name: r.name, class_name: r.class_name, present: r.p, absent: r.a, pct: Math.round((r.p * 1000) / (r.p + r.a)) / 10 }));
  ok(res, { students, teachers, staff: staffAll, attendance_today: attMap, fees_collected_month: seeMoney ? collected : null, fees_pending: seeMoney ? pending : null, expenses_month: seeMoney ? expenses : null, salary_monthly: seeMoney ? salaries : null, upcoming_exams: exams, low_attendance: lowAtt });
});

// ---------- school: users (admin manages logins) ----------
route('GET', '/api/users', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  ok(res, { users: q.all('SELECT id,name,username,role,phone,status FROM users WHERE school_id=? ORDER BY id', u.school_id) });
});
route('POST', '/api/users', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 100), uname = vStr(b.username, 60), pw = String(b.password || '');
  const role = ['accountant', 'teacher', 'staff', 'parent', 'student', 'admin'].includes(b.role) ? b.role : null;
  if (!name || !uname || !role || pw.length < 8) return bad(res, 'name, username, role, password (8+) required');
  if (q.get('SELECT id FROM users WHERE username=?', uname)) return bad(res, 'Username already taken');
  let studentId = null;
  if (role === 'student' && b.student_id) {
    const st = q.get('SELECT id FROM students WHERE id=? AND school_id=?', vInt(b.student_id), u.school_id);
    if (!st) return bad(res, 'Student not in your school');
    studentId = st.id;
  }
  if (role === 'student' && !studentId) return bad(res, 'student_id required for student role');
  const r = q.run('INSERT INTO users(school_id,name,username,password_hash,role,phone,student_id,must_change) VALUES(?,?,?,?,?,?,?,?)',
    u.school_id, name, uname, hashPassword(pw), role, vStr(b.phone, 40), studentId, b.must_change ? 1 : 0);
  if ((role === 'parent' || role === 'student') && vStr(b.phone, 40))
    q.run("UPDATE guardians SET user_id=? WHERE school_id=? AND phone=? AND user_id IS NULL", r.lastInsertRowid, u.school_id, vStr(b.phone, 40));
  audit(u.school_id, u.id, 'user_create', `${uname} (${role})`);
  ok(res, { id: r.lastInsertRowid }, 201);
});
route('PATCH', '/api/users/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const t = q.get('SELECT * FROM users WHERE id=? AND school_id=?', m.id, u.school_id); if (!t) return bad(res, 'Not found', 404);
  const b = req.body;
  if (b.password) { if (String(b.password).length < 8) return bad(res, 'Password 8+ chars'); q.run('UPDATE users SET password_hash=? WHERE id=?', hashPassword(String(b.password)), t.id); q.run('DELETE FROM sessions WHERE user_id=?', t.id); }
  if (b.status && ['active', 'disabled'].includes(b.status)) {
    if (b.status === 'disabled') {
      if (t.id === u.id) return bad(res, 'You cannot disable your own account');
      if (t.role === 'admin' && !q.get("SELECT id FROM users WHERE school_id=? AND role='admin' AND status='active' AND id != ?", u.school_id, t.id))
        return bad(res, 'Cannot disable the last active admin');
    }
    q.run('UPDATE users SET status=? WHERE id=?', b.status, t.id);
    if (b.status === 'disabled') q.run('DELETE FROM sessions WHERE user_id=?', t.id);
  }
  if (b.name) q.run('UPDATE users SET name=? WHERE id=?', vStr(b.name, 100), t.id);
  audit(u.school_id, u.id, 'user_update', t.username);
  ok(res, { ok: true });
});

// ---------- classes & sections & sessions & subjects ----------
route('GET', '/api/classes', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  const cls = q.all('SELECT * FROM classes WHERE school_id=? ORDER BY level, name', u.school_id);
  const secs = q.all('SELECT s.* FROM sections s JOIN classes c ON c.id=s.class_id WHERE c.school_id=?', u.school_id);
  cls.forEach((c) => { c.sections = secs.filter((s) => s.class_id === c.id); });
  ok(res, { classes: cls });
});
route('POST', '/api/classes', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 60); if (!name) return bad(res, 'Class name required');
  const lvl = vInt(b.level, 0);
  if (q.get('SELECT id FROM classes WHERE school_id=? AND level=?', u.school_id, lvl)) return bad(res, `Another class already has level ${lvl} - levels must be unique for safe rollover`);
  const r = q.run('INSERT INTO classes(school_id,name,level,monthly_fee) VALUES(?,?,?,?)', u.school_id, name, lvl, (vMoney(b.monthly_fee) ?? 0));
  const cid = r.lastInsertRowid;
  const secList = Array.isArray(b.sections) && b.sections.length ? b.sections : ['A'];
  secList.forEach((s) => { const sn = vStr(String(s), 20); if (sn) q.run('INSERT INTO sections(class_id,name) VALUES(?,?)', cid, sn); });
  ok(res, { id: cid }, 201);
});
route('PATCH', '/api/classes/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const c = q.get('SELECT * FROM classes WHERE id=? AND school_id=?', m.id, u.school_id); if (!c) return bad(res, 'Not found', 404);
  const b = req.body;
  const newLevel = b.level !== undefined ? vInt(b.level, c.level) : c.level;
  if (newLevel !== c.level && q.get('SELECT id FROM classes WHERE school_id=? AND level=? AND id != ?', u.school_id, newLevel, c.id))
    return bad(res, `Another class already has level ${newLevel} - levels must be unique for safe rollover`);
  q.run('UPDATE classes SET name=?,level=?,monthly_fee=? WHERE id=?',
    vStr(b.name, 60) || c.name, newLevel,
    b.monthly_fee !== undefined ? (vMoney(b.monthly_fee) ?? c.monthly_fee) : c.monthly_fee, c.id);
  if (Array.isArray(b.add_sections)) [...new Set(b.add_sections)].forEach((x) => { const sn = vStr(String(x), 20); if (sn && !q.get('SELECT id FROM sections WHERE class_id=? AND name=?', c.id, sn)) q.run('INSERT INTO sections(class_id,name) VALUES(?,?)', c.id, sn); });
  ok(res, { ok: true });
});
route('GET', '/api/sessions', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  ok(res, { sessions: q.all('SELECT * FROM academic_sessions WHERE school_id=? ORDER BY id DESC', u.school_id) });
});
route('POST', '/api/sessions', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 40); if (!name) return bad(res, 'Session name required (e.g. 2026-27)');
  if (b.is_current) q.run('UPDATE academic_sessions SET is_current=0 WHERE school_id=?', u.school_id);
  q.run('INSERT INTO academic_sessions(school_id,name,start_date,end_date,is_current) VALUES(?,?,?,?,?)',
    u.school_id, name, vDate(b.start_date), vDate(b.end_date), b.is_current ? 1 : 0);
  ok(res, { ok: true }, 201);
});
route('GET', '/api/subjects', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  ok(res, { subjects: q.all('SELECT s.*, c.name class_name, e.name teacher_name FROM subjects s LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN employees e ON e.id=s.teacher_id WHERE s.school_id=? ORDER BY c.level, s.name', u.school_id) });
});
route('POST', '/api/subjects', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 80); if (!name) return bad(res, 'Subject name required');
  if (b.class_id && !q.get('SELECT id FROM classes WHERE id=? AND school_id=?', b.class_id, u.school_id)) return bad(res, 'Class not in your school');
  q.run('INSERT INTO subjects(school_id,class_id,name,teacher_id) VALUES(?,?,?,?)', u.school_id, vInt(b.class_id), name, vInt(b.teacher_id));
  ok(res, { ok: true }, 201);
});

// ---------- students & guardians ----------
function studentView(s) {
  const cls = s.class_id ? q.get('SELECT name FROM classes WHERE id=?', s.class_id) : null;
  const sec = s.section_id ? q.get('SELECT name FROM sections WHERE id=?', s.section_id) : null;
  const dues = q.get(`SELECT COALESCE(SUM(v.total - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.voucher_id=v.id AND p.reversed=0),0)),0) s
    FROM fee_vouchers v WHERE v.student_id=? AND v.status!='paid'`, s.id).s;
  return Object.assign({}, s, { class_name: cls ? cls.name : '', section_name: sec ? sec.name : '', dues });
}
route('GET', '/api/students', async (req, res, m, b, url) => {
  const u = needSchool(req, res); if (!u) return;
  const sid = u.school_id;
  let sql = "SELECT * FROM students WHERE school_id=?";
  const args = [sid];
  const cls = url.searchParams.get('class_id');
  const sec = url.searchParams.get('section_id');
  const status = url.searchParams.get('status') || 'active';
  const qq = url.searchParams.get('q');
  if (status !== 'all') { sql += ' AND status=?'; args.push(status); }
  if (cls) { sql += ' AND class_id=?'; args.push(cls); }
  if (sec) { sql += ' AND section_id=?'; args.push(sec); }
  if (qq) { sql += ' AND (name LIKE ? OR admission_no LIKE ? OR father_name LIKE ?)'; const like = `%${qq.slice(0, 50)}%`; args.push(like, like, like); }
  sql += ' ORDER BY class_id, roll_no, name LIMIT 1000';
  ok(res, { students: q.all(sql, ...args).map(studentView) });
});
// ---------- CSV import/export (bulk admissions) ----------
function csvCell(v) {
  let s = String(v == null ? '' : v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralize spreadsheet formula injection on export
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function parseCSV(text) {
  const rows = []; let row = [], cell = '', inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else inQ = false; } else cell += c; }
    else if (c === '"') inQ = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((x) => String(x).trim() !== ''));
}
route('GET', '/api/students.csv', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const rows = q.all(`SELECT s.*, c.name class_name, sec.name section_name FROM students s
    LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id WHERE s.school_id=? ORDER BY s.id`, u.school_id);
  const head = 'admission_no,name,father_name,mother_name,guardian_phone,gender,dob,class,section,roll_no,admission_date,discount,status';
  const body = rows.map((s) => [s.admission_no, s.name, s.father_name, s.mother_name, s.guardian_phone, s.gender, s.dob, s.class_name, s.section_name, s.roll_no, s.admission_date, (s.discount || 0) / 100, s.status].map(csvCell).join(','));
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="students.csv"' });
  res.end('\ufeff' + head + '\n' + body.join('\n') + '\n');
});
route('POST', '/api/students/import', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const sid = u.school_id;
  const rows = parseCSV(String(req.body.csv || '').replace(/^\ufeff/, ''));
  if (rows.length < 2) return bad(res, 'CSV with header + at least one row required');
  const head = rows[0].map((h) => h.trim().toLowerCase());
  const col = (r, name) => { const i = head.indexOf(name); return i < 0 ? '' : String(r[i] || '').trim(); };
  if (!head.includes('name')) return bad(res, 'CSV must include a name column');
  const sch = q.get('SELECT student_limit FROM schools WHERE id=?', sid);
  let created = 0, skipped = 0; const errors = [];
  const classes = q.all('SELECT id,name FROM classes WHERE school_id=?', sid);
  const sections = q.all('SELECT s.id, s.name, s.class_id FROM sections s JOIN classes c ON c.id=s.class_id WHERE c.school_id=?', sid);
  const ins = db.prepare(`INSERT INTO students(school_id,admission_no,name,father_name,mother_name,guardian_phone,emergency_contact,gender,dob,address,class_id,section_id,roll_no,admission_date,previous_school,monthly_fee_override,discount,status)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active')`);
  rows.slice(1, 2001).forEach((r, idx) => {
    const line = idx + 2;
    const name = col(r, 'name');
    if (!name) { errors.push(`line ${line}: name missing`); skipped++; return; }
    const father = col(r, 'father_name');
    const cnt = q.get("SELECT COUNT(*) c FROM students WHERE school_id=? AND status='active'", sid).c;
    if (sch && cnt >= sch.student_limit) { errors.push(`line ${line}: plan student limit reached`); skipped++; return; }
    if (q.get("SELECT id FROM students WHERE school_id=? AND name=? AND father_name=? AND status='active'", sid, name, father)) { errors.push(`line ${line}: duplicate (${name})`); skipped++; return; }
    let classId = null, sectionId = null;
    const cn = col(r, 'class').toLowerCase();
    if (cn) { const c = classes.find((x) => x.name.toLowerCase() === cn); if (!c) { errors.push(`line ${line}: class '${col(r, 'class')}' not found`); skipped++; return; } classId = c.id;
      const sn = col(r, 'section').toLowerCase();
      if (sn) { const s = sections.find((x) => x.class_id === classId && x.name.toLowerCase() === sn); if (!s) { errors.push(`line ${line}: section '${col(r, 'section')}' not found`); skipped++; return; } sectionId = s.id; } }
    let nAdm = q.get('SELECT COUNT(*) c FROM students WHERE school_id=?', sid).c + 1;
    let adm = 'A-' + String(nAdm).padStart(4, '0');
    while (q.get('SELECT id FROM students WHERE school_id=? AND admission_no=?', sid, adm)) { nAdm++; adm = 'A-' + String(nAdm).padStart(4, '0'); }
    const disc = col(r, 'discount') ? vMoney(col(r, 'discount')) : 0;
    if (col(r, 'discount') && disc === null) { errors.push(`line ${line}: invalid discount`); skipped++; return; }
    const dob = /^\d{4}-\d{2}-\d{2}$/.test(col(r, 'dob')) ? col(r, 'dob') : '';
    try {
      ins.run(sid, adm, name, father, col(r, 'mother_name'), col(r, 'guardian_phone'), '', col(r, 'gender').slice(0, 8), dob, '', classId, sectionId, col(r, 'roll_no').slice(0, 15), today(), '', null, disc || 0);
      created++;
    } catch (e) { errors.push(`line ${line}: ${String(e.message).slice(0, 80)}`); skipped++; }
  });
  audit(sid, u.id, 'students_import', `${created} created, ${skipped} skipped`);
  ok(res, { created, skipped, errors: errors.slice(0, 50) });
});

route('POST', '/api/classes/:id/sections', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const c = q.get('SELECT id FROM classes WHERE id=? AND school_id=?', m.id, u.school_id); if (!c) return bad(res, 'Not found', 404);
  const nm = vStr(req.body.name, 30); if (!nm) return bad(res, 'Section name required');
  const dup = q.get('SELECT id FROM sections WHERE class_id=? AND name=?', c.id, nm);
  if (dup) return ok(res, { id: dup.id, existing: true });
  const r = q.run('INSERT INTO sections(class_id,name) VALUES(?,?)', c.id, nm);
  audit(u.school_id, u.id, 'section_add', `class #${c.id}: ${nm}`);
  ok(res, { id: r.lastInsertRowid }, 201);
});
route('POST', '/api/students', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const sid = u.school_id;
  const b = req.body;
  const name = vStr(b.name, 120); if (!name) return bad(res, 'Student name required');
  const sch = q.get('SELECT student_limit FROM schools WHERE id=?', sid);
  const cnt = q.get("SELECT COUNT(*) c FROM students WHERE school_id=? AND status='active'", sid).c;
  if (sch && cnt >= sch.student_limit) return bad(res, `Student limit of plan reached (${sch.student_limit}). Contact platform to upgrade.`, 402);
  let adm = vStr(b.admission_no, 30);
  if (!adm) {
    let n = q.get('SELECT COUNT(*) c FROM students WHERE school_id=?', sid).c + 1;
    adm = 'A-' + String(n).padStart(4, '0');
    while (q.get('SELECT id FROM students WHERE school_id=? AND admission_no=?', sid, adm)) { n++; adm = 'A-' + String(n).padStart(4, '0'); }
  }
  if (q.get('SELECT id FROM students WHERE school_id=? AND admission_no=?', sid, adm)) return bad(res, 'Admission number already used');
  const dup = q.get("SELECT id,name,father_name FROM students WHERE school_id=? AND name=? AND father_name=? AND status='active'", sid, name, vStr(b.father_name, 120));
  if (b.class_id && !q.get('SELECT id FROM classes WHERE id=? AND school_id=?', b.class_id, sid)) return bad(res, 'Class not in your school');
  const secErrPost = sectionCheck(sid, b.section_id, b.class_id); if (secErrPost) return bad(res, secErrPost);
  const r = q.run(`INSERT INTO students(school_id,admission_no,name,father_name,mother_name,guardian_phone,emergency_contact,gender,dob,address,class_id,section_id,roll_no,admission_date,previous_school,monthly_fee_override,discount,status)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active')`,
    sid, adm, name, vStr(b.father_name, 120), vStr(b.mother_name, 120), vStr(b.guardian_phone, 40), vStr(b.emergency_contact, 40),
    vStr(b.gender, 8), vDate(b.dob), vStr(b.address, 250), vInt(b.class_id), vInt(b.section_id), vStr(b.roll_no, 15),
    vDate(b.admission_date) || today(), vStr(b.previous_school, 150), b.monthly_fee_override != null ? vMoney(b.monthly_fee_override) : null, (vMoney(b.discount) ?? 0));
  audit(sid, u.id, 'admission', `${name} (${adm})`);
  ok(res, { id: r.lastInsertRowid, admission_no: adm, duplicate_warning: dup ? `Similar student exists: ${dup.name} s/o ${dup.father_name}` : null }, 201);
});
route('GET', '/api/students/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'teacher', 'staff', 'student']); if (!u) return;
  if (u.role === 'student' && Number(u.student_id) !== Number(m.id)) return bad(res, 'Students can only view their own record', 403);
  const s = q.get('SELECT * FROM students WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!s) return bad(res, 'Not found', 404);
  const vouchers = q.all('SELECT * FROM fee_vouchers WHERE student_id=? ORDER BY month DESC LIMIT 24', s.id);
  const payments = q.all(`SELECT p.*, v.month FROM payments p JOIN fee_vouchers v ON v.id=p.voucher_id WHERE p.school_id=? AND v.student_id=? ORDER BY p.date DESC LIMIT 50`, u.school_id, s.id);
  const att = q.all("SELECT status, COUNT(*) c FROM student_attendance WHERE student_id=? GROUP BY status", s.id);
  const guardians = q.all(`SELECT g.*, sg.relation FROM student_guardians sg JOIN guardians g ON g.id=sg.guardian_id WHERE sg.student_id=?`, s.id);
  const docs = q.all('SELECT id,doc_type,title,created_at FROM student_documents WHERE student_id=? ORDER BY id DESC', s.id);
  const history = q.all('SELECT h.*, cf.name from_class, ct.name to_class FROM student_class_history h LEFT JOIN classes cf ON cf.id=h.from_class_id LEFT JOIN classes ct ON ct.id=h.to_class_id WHERE h.student_id=? ORDER BY h.id DESC LIMIT 50', s.id);
  ok(res, { student: studentView(s), vouchers, payments, attendance_summary: att, guardians, documents: docs, history });
});
route('PATCH', '/api/students/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'staff', 'accountant']); if (!u) return;
  const s = q.get('SELECT * FROM students WHERE id=? AND school_id=?', m.id, u.school_id); if (!s) return bad(res, 'Not found', 404);
  const b = req.body;
  const finTouched = b.monthly_fee_override !== undefined || b.discount !== undefined;
  if (finTouched && !['admin', 'accountant'].includes(u.role)) return bad(res, 'Fee override and discount changes require admin or accountant', 403);
  if (u.role === 'accountant' && !finTouched) return bad(res, 'Accountants may only edit fee override and discount', 403);
  if (b.monthly_fee_override !== undefined && b.monthly_fee_override !== null && b.monthly_fee_override !== '' && vMoney(b.monthly_fee_override) === null) return bad(res, 'Invalid monthly_fee_override (negative or too large)');
  if (b.discount !== undefined && b.discount !== '' && vMoney(b.discount) === null) return bad(res, 'Invalid discount (negative or too large)');
  const status = ['active', 'withdrawn', 'transferred', 'graduated'].includes(b.status) ? b.status : s.status;
  if (b.class_id !== undefined && b.class_id !== null && !q.get('SELECT id FROM classes WHERE id=? AND school_id=?', vInt(b.class_id), u.school_id)) return bad(res, 'Class not in your school');
  const effClass = b.class_id !== undefined ? vInt(b.class_id) : s.class_id;
  const secErrPatch = sectionCheck(u.school_id, b.section_id, effClass); if (secErrPatch) return bad(res, secErrPatch);
  if (status === 'active' && s.status !== 'active') {
    const sch = q.get('SELECT student_limit FROM schools WHERE id=?', u.school_id);
    const cnt = q.get("SELECT COUNT(*) c FROM students WHERE school_id=? AND status='active'", u.school_id).c;
    if (sch && cnt >= sch.student_limit) return bad(res, `Student limit of plan reached (${sch.student_limit}). Contact platform to upgrade.`, 402);
  }
  q.run(`UPDATE students SET name=?,father_name=?,mother_name=?,guardian_phone=?,emergency_contact=?,gender=?,dob=?,address=?,class_id=?,section_id=?,roll_no=?,monthly_fee_override=?,discount=?,status=? WHERE id=?`,
    vStr(b.name, 120) || s.name,
    b.father_name !== undefined ? vStr(b.father_name, 120) : s.father_name,
    b.mother_name !== undefined ? vStr(b.mother_name, 120) : s.mother_name,
    b.guardian_phone !== undefined ? vStr(b.guardian_phone, 40) : s.guardian_phone,
    b.emergency_contact !== undefined ? vStr(b.emergency_contact, 40) : s.emergency_contact,
    b.gender !== undefined ? vStr(b.gender, 8) : s.gender,
    b.dob !== undefined ? vDate(b.dob) : s.dob,
    b.address !== undefined ? vStr(b.address, 250) : s.address,
    b.class_id !== undefined ? vInt(b.class_id) : s.class_id,
    b.section_id !== undefined ? vInt(b.section_id) : (b.class_id !== undefined && vInt(b.class_id) !== s.class_id ? null : s.section_id),
    b.roll_no !== undefined ? vStr(b.roll_no, 15) : s.roll_no,
    b.monthly_fee_override !== undefined ? (b.monthly_fee_override === null ? null : vMoney(b.monthly_fee_override)) : s.monthly_fee_override,
    b.discount !== undefined ? (vMoney(b.discount) ?? 0) : s.discount,
    status, s.id);
  if (status !== s.status) audit(u.school_id, u.id, 'student_status', `${s.admission_no}: ${s.status} -> ${status}`);
  const after = q.get('SELECT monthly_fee_override, discount FROM students WHERE id=?', s.id);
  if (finTouched && (after.monthly_fee_override !== s.monthly_fee_override || after.discount !== s.discount))
    audit(u.school_id, u.id, 'student_finance_edit', `${s.admission_no}: fee_override ${s.monthly_fee_override} -> ${after.monthly_fee_override}, discount ${s.discount} -> ${after.discount}`);
  ok(res, { ok: true });
});
route('POST', '/api/students/:id/guardians', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const s = q.get('SELECT * FROM students WHERE id=? AND school_id=?', m.id, u.school_id); if (!s) return bad(res, 'Not found', 404);
  const b = req.body;
  const gname = vStr(b.name, 100), gphone = vStr(b.phone, 40);
  if (!gname || !gphone) return bad(res, 'Guardian name and phone required');
  let g = q.get('SELECT * FROM guardians WHERE school_id=? AND phone=?', u.school_id, gphone);
  if (!g) { const r = q.run('INSERT INTO guardians(school_id,name,phone,cnic) VALUES(?,?,?,?)', u.school_id, gname, gphone, vStr(b.cnic, 20)); g = { id: r.lastInsertRowid }; }
  if (!g.user_id) {
    let uid = vInt(b.user_id);
    if (uid) { const pu = q.get("SELECT id FROM users WHERE id=? AND school_id=? AND role IN ('parent','student')", uid, u.school_id); if (!pu) uid = null; }
    if (!uid) { const pu = q.get("SELECT id FROM users WHERE school_id=? AND phone=? AND role IN ('parent','student')", u.school_id, gphone); if (pu) uid = pu.id; }
    if (uid) q.run('UPDATE guardians SET user_id=? WHERE id=?', uid, g.id);
  }
  try { q.run('INSERT INTO student_guardians(student_id,guardian_id,relation) VALUES(?,?,?)', s.id, g.id, vStr(b.relation, 30) || 'guardian'); } catch { return bad(res, 'Already linked'); }
  ok(res, { id: g.id }, 201);
});

// ---------- employees / HR ----------
route('GET', '/api/employees', async (req, res) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'staff']); if (!u) return;
  ok(res, { employees: q.all('SELECT * FROM employees WHERE school_id=? ORDER BY name', u.school_id) });
});
route('POST', '/api/employees', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 100); if (!name) return bad(res, 'Employee name required');
  const r = q.run('INSERT INTO employees(school_id,name,designation,phone,qualification,joining_date,salary) VALUES(?,?,?,?,?,?,?)',
    u.school_id, name, vStr(b.designation, 60), vStr(b.phone, 40), vStr(b.qualification, 100), vDate(b.joining_date) || today(), vMoney(b.salary) ?? 0);
  ok(res, { id: r.lastInsertRowid }, 201);
});
route('PATCH', '/api/employees/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const e = q.get('SELECT * FROM employees WHERE id=? AND school_id=?', m.id, u.school_id); if (!e) return bad(res, 'Not found', 404);
  const b = req.body;
  q.run('UPDATE employees SET name=?,designation=?,phone=?,qualification=?,salary=?,status=? WHERE id=?',
    vStr(b.name, 100) || e.name,
    b.designation !== undefined ? vStr(b.designation, 60) : e.designation,
    b.phone !== undefined ? vStr(b.phone, 40) : e.phone,
    b.qualification !== undefined ? vStr(b.qualification, 100) : e.qualification,
    b.salary !== undefined ? (vMoney(b.salary) ?? e.salary) : e.salary,
    ['active', 'resigned', 'terminated'].includes(b.status) ? b.status : e.status, e.id);
  ok(res, { ok: true });
});
route('GET', '/api/employees/:id/record', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant']); if (!u) return;
  const e = q.get('SELECT * FROM employees WHERE id=? AND school_id=?', m.id, u.school_id); if (!e) return bad(res, 'Not found', 404);
  const att = q.all('SELECT status, COUNT(*) c FROM employee_attendance WHERE employee_id=? GROUP BY status', e.id);
  const salaries = q.all('SELECT * FROM salary_payments WHERE employee_id=? ORDER BY month DESC LIMIT 24', e.id);
  const leaves = q.all('SELECT * FROM leave_requests WHERE employee_id=? ORDER BY id DESC LIMIT 20', e.id);
  ok(res, { employee: e, attendance_summary: att, salary_payments: salaries, leave_requests: leaves });
});
route('POST', '/api/employees/:id/leave', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const e = q.get('SELECT * FROM employees WHERE id=? AND school_id=?', m.id, u.school_id); if (!e) return bad(res, 'Not found', 404);
  const b = req.body;
  const f = vDate(b.from_date), t = vDate(b.to_date);
  if (!f || !t) return bad(res, 'from_date and to_date required');
  q.run('INSERT INTO leave_requests(school_id,employee_id,from_date,to_date,reason) VALUES(?,?,?,?,?)', u.school_id, e.id, f, t, vStr(b.reason, 200));
  ok(res, { ok: true }, 201);
});
route('GET', '/api/leaves', async (req, res) => {
  const u = needSchool(req, res, ['admin', 'staff']); if (!u) return;
  ok(res, { leaves: q.all(`SELECT l.*, e.name employee_name FROM leave_requests l JOIN employees e ON e.id=l.employee_id WHERE l.school_id=? ORDER BY CASE l.status WHEN 'pending' THEN 0 ELSE 1 END, l.id DESC LIMIT 200`, u.school_id) });
});
route('PATCH', '/api/leaves/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const l = q.get('SELECT * FROM leave_requests WHERE id=? AND school_id=?', m.id, u.school_id); if (!l) return bad(res, 'Not found', 404);
  const st = ['approved', 'rejected'].includes(req.body.status) ? req.body.status : null;
  if (!st) return bad(res, 'status approved|rejected required');
  q.run('UPDATE leave_requests SET status=?, decided_by=? WHERE id=?', st, u.id, l.id);
  ok(res, { ok: true });
});
route('POST', '/api/employees/:id/salary', async (req, res, m) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const e = q.get('SELECT * FROM employees WHERE id=? AND school_id=?', m.id, u.school_id); if (!e) return bad(res, 'Not found', 404);
  const b = req.body;
  const month = vStr(b.month, 7) || monthNow();
  const amt = b.amount !== undefined ? vMoney(b.amount) : e.salary;
  if (!amt) return bad(res, 'amount required');
  try {
    q.run('INSERT INTO salary_payments(school_id,employee_id,month,amount,allowances,deductions,date,note,paid_by) VALUES(?,?,?,?,?,?,?,?,?)',
      u.school_id, e.id, month, amt, (vMoney(b.allowances) ?? 0), (vMoney(b.deductions) ?? 0), vDate(b.date) || today(), vStr(b.note, 200), u.id);
  } catch { return bad(res, 'Salary for this month already recorded'); }
  audit(u.school_id, u.id, 'salary_pay', `${e.name} ${month} Rs ${rp(amt)}`);
  ok(res, { ok: true }, 201);
});
route('GET', '/api/salaries', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const month = (new URL(req.url, 'http://x')).searchParams.get('month') || monthNow();
  const emps = q.all("SELECT * FROM employees WHERE school_id=? AND status='active' ORDER BY name", u.school_id);
  const paid = q.all('SELECT * FROM salary_payments WHERE school_id=? AND month=?', u.school_id, month);
  emps.forEach((e) => { e.payment = paid.find((p) => p.employee_id === e.id) || null; });
  ok(res, { month, employees: emps });
});

// ---------- attendance (students + employees) ----------
const ATT_STATUSES = ['present', 'absent', 'late', 'leave'];
route('POST', '/api/attendance/mark', async (req, res) => {
  const u = needSchool(req, res, ATT_ROLES); if (!u) return;
  const b = req.body;
  const date = vDate(b.date) || today();
  if (!Array.isArray(b.records) || !b.records.length) return bad(res, 'records array required');
  const ups = db.prepare(`INSERT INTO student_attendance(school_id,student_id,date,status,marked_by) VALUES(?,?,?,?,?)
    ON CONFLICT(school_id,student_id,date) DO UPDATE SET status=excluded.status, marked_by=excluded.marked_by`);
  let n = 0;
  for (const r of b.records.slice(0, 2000)) {
    const stu = q.get('SELECT id FROM students WHERE id=? AND school_id=?', r.student_id, u.school_id);
    if (!stu || !ATT_STATUSES.includes(r.status)) continue;
    ups.run(u.school_id, stu.id, date, r.status, u.id); n++;
  }
  let notices = 0;
  const schRow = q.get('SELECT absent_notice FROM schools WHERE id=?', u.school_id);
  if (schRow && schRow.absent_notice) {
    for (const r of b.records.slice(0, 2000)) {
      if (r.status !== 'absent') continue;
      const stu = q.get('SELECT id,name FROM students WHERE id=? AND school_id=?', r.student_id, u.school_id);
      if (!stu) continue;
      const gards = q.all(`SELECT g.user_id FROM guardians g JOIN student_guardians sg ON sg.guardian_id=g.id
        WHERE sg.student_id=? AND g.user_id IS NOT NULL`, stu.id);
      for (const g of gards) {
        q.run("INSERT INTO announcements(school_id,title,body,audience,created_by,parent_user_id) VALUES(?,?,?,'parents',?,?)",
          u.school_id, `Absence: ${stu.name}`, `${stu.name} was marked absent on ${date}.`, u.id, g.user_id); notices++;
      }
    }
  }
  audit(u.school_id, u.id, 'attendance_mark', `${date}: ${n} students${notices ? `, ${notices} guardian notices` : ''}`);
  ok(res, { marked: n, date, guardian_notices: notices });
});
route('GET', '/api/attendance/register', async (req, res, m, b, url) => {
  const u = needSchool(req, res); if (!u) return;
  const cls = url.searchParams.get('class_id'), sec = url.searchParams.get('section_id');
  const date = vDate(url.searchParams.get('date')) || today();
  if (!cls) return bad(res, 'class_id required');
  let sql = "SELECT id,name,roll_no,admission_no FROM students WHERE school_id=? AND class_id=? AND status='active'";
  const args = [u.school_id, cls];
  if (sec) { sql += ' AND section_id=?'; args.push(sec); }
  sql += ' ORDER BY roll_no, name';
  const students = q.all(sql, ...args);
  const marks = q.all('SELECT student_id,status FROM student_attendance WHERE school_id=? AND date=?', u.school_id, date);
  const map = {}; marks.forEach((x) => { map[x.student_id] = x.status; });
  students.forEach((s) => { s.status = map[s.id] || null; });
  ok(res, { date, students });
});
route('GET', '/api/attendance/report', async (req, res, m, b, url) => {
  const u = needSchool(req, res); if (!u) return;
  const month = vStr(url.searchParams.get('month'), 7) || monthNow();
  const cls = url.searchParams.get('class_id');
  let sql = `SELECT s.id, s.name, s.roll_no, c.name class_name,
    SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) present,
    SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) absent,
    SUM(CASE WHEN a.status='late' THEN 1 ELSE 0 END) late,
    SUM(CASE WHEN a.status='leave' THEN 1 ELSE 0 END) leave,
    COUNT(a.id) total
    FROM students s LEFT JOIN classes c ON c.id=s.class_id
    LEFT JOIN student_attendance a ON a.student_id=s.id AND strftime('%Y-%m',a.date)=?
    WHERE s.school_id=? AND s.status='active'`;
  const args = [month, u.school_id];
  if (cls) { sql += ' AND s.class_id=?'; args.push(cls); }
  sql += ' GROUP BY s.id ORDER BY c.level, s.roll_no, s.name';
  const rows = q.all(sql, ...args);
  rows.forEach((r) => { r.percentage = r.total ? Math.round((r.present + r.late) * 1000 / r.total) / 10 : null; });
  ok(res, { month, report: rows });
});
route('POST', '/api/attendance/employees', async (req, res) => {
  const u = needSchool(req, res, ATT_ROLES); if (!u) return;
  const b = req.body;
  const date = vDate(b.date) || today();
  if (!Array.isArray(b.records) || !b.records.length) return bad(res, 'records array required');
  const ups = db.prepare(`INSERT INTO employee_attendance(school_id,employee_id,date,status,marked_by) VALUES(?,?,?,?,?)
    ON CONFLICT(school_id,employee_id,date) DO UPDATE SET status=excluded.status, marked_by=excluded.marked_by`);
  let n = 0;
  for (const r of b.records.slice(0, 500)) {
    const e = q.get('SELECT id FROM employees WHERE id=? AND school_id=?', r.employee_id, u.school_id);
    if (!e || !ATT_STATUSES.includes(r.status)) continue;
    ups.run(u.school_id, e.id, date, r.status, u.id); n++;
  }
  ok(res, { marked: n, date });
});
route('GET', '/api/attendance/employees', async (req, res, m, b, url) => {
  const u = needSchool(req, res); if (!u) return;
  const date = vDate(url.searchParams.get('date')) || today();
  const emps = q.all("SELECT id,name,designation FROM employees WHERE school_id=? AND status='active' ORDER BY name", u.school_id);
  const marks = q.all('SELECT employee_id,status FROM employee_attendance WHERE school_id=? AND date=?', u.school_id, date);
  const map = {}; marks.forEach((x) => { map[x.employee_id] = x.status; });
  emps.forEach((e) => { e.status = map[e.id] || null; });
  ok(res, { date, employees: emps });
});

// ---------- fees ----------
route('GET', '/api/fees/structures', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  ok(res, { structures: q.all('SELECT f.*, c.name class_name FROM fee_structures f LEFT JOIN classes c ON c.id=f.class_id WHERE f.school_id=? ORDER BY f.class_id, f.id', u.school_id) });
});
route('POST', '/api/fees/structures', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 80), amount = vMoney(b.amount);
  const freq = ['monthly', 'one_time', 'annual'].includes(b.frequency) ? b.frequency : 'monthly';
  if (!name || !amount || amount <= 0) return bad(res, 'name and positive amount required');
  if (b.class_id && !q.get('SELECT id FROM classes WHERE id=? AND school_id=?', b.class_id, u.school_id)) return bad(res, 'Class not in your school');
  q.run('INSERT INTO fee_structures(school_id,class_id,name,amount,frequency) VALUES(?,?,?,?,?)', u.school_id, vInt(b.class_id), name, amount, freq);
  ok(res, { ok: true }, 201);
});
route('DELETE', '/api/fees/structures/:id', async (req, res, m) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  q.run('DELETE FROM fee_structures WHERE id=? AND school_id=?', m.id, u.school_id);
  ok(res, { ok: true });
});
route('POST', '/api/fees/generate', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const sid = u.school_id;
  const b = req.body;
  const month = vStr(b.month, 7); if (!/^\d{4}-\d{2}$/.test(month)) return bad(res, 'month as YYYY-MM required');
  const due = vDate(b.due_date) || month + '-10';
  let sql = "SELECT * FROM students WHERE school_id=? AND status='active'";
  const args = [sid];
  if (b.class_id) { sql += ' AND class_id=?'; args.push(vInt(b.class_id)); }
  const students = q.all(sql, ...args);
  const structures = q.all("SELECT * FROM fee_structures WHERE school_id=? AND frequency='monthly'", sid);
  const insV = db.prepare('INSERT INTO fee_vouchers(school_id,student_id,month,issue_date,due_date,total) VALUES(?,?,?,?,?,?)');
  const insI = db.prepare('INSERT INTO voucher_items(voucher_id,name,amount) VALUES(?,?,?)');
  let created = 0, skipped = 0;
  for (const s of students) {
    if (q.get('SELECT id FROM fee_vouchers WHERE school_id=? AND student_id=? AND month=?', sid, s.id, month)) { skipped++; continue; }
    const items = [];
    const cls = s.class_id ? q.get('SELECT * FROM classes WHERE id=? AND school_id=?', s.class_id, sid) : null;
    const tuition = s.monthly_fee_override != null ? s.monthly_fee_override : (cls ? cls.monthly_fee : 0);
    if (tuition > 0) items.push({ name: 'Tuition Fee', amount: tuition });
    for (const f of structures) {
      if (f.class_id && f.class_id !== s.class_id) continue;
      items.push({ name: f.name, amount: f.amount });
    }
    if (s.discount > 0) items.push({ name: 'Discount / Scholarship', amount: -Math.abs(s.discount) });
    const total = items.reduce((t, i) => t + i.amount, 0);
    if (total <= 0) { skipped++; continue; }
    const vid = insV.run(sid, s.id, month, today(), due, total).lastInsertRowid;
    items.forEach((i) => insI.run(vid, i.name, i.amount));
    created++;
  }
  audit(sid, u.id, 'vouchers_generate', `${month}: ${created} created, ${skipped} skipped`);
  ok(res, { created, skipped, month });
});
function voucherView(v) {
  const items = q.all('SELECT name,amount FROM voucher_items WHERE voucher_id=?', v.id);
  const paid = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
  const stu = q.get('SELECT s.name, s.admission_no, s.roll_no, c.name class_name, sec.name section_name FROM students s LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id WHERE s.id=?', v.student_id);
  const outstanding = v.total - paid;
  const status = paid <= 0 ? 'unpaid' : (outstanding <= 0 ? 'paid' : 'partial');
  return Object.assign({}, v, { items, paid, outstanding, status, student: stu });
}
route('GET', '/api/fees/vouchers', async (req, res, m, b, url) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  let sql = 'SELECT * FROM fee_vouchers WHERE school_id=?';
  const args = [u.school_id];
  const month = url.searchParams.get('month'), st = url.searchParams.get('status'), stu = url.searchParams.get('student_id');
  if (month) { sql += ' AND month=?'; args.push(month); }
  if (stu) { sql += ' AND student_id=?'; args.push(stu); }
  sql += ' ORDER BY id DESC LIMIT 500';
  let rows = q.all(sql, ...args).map(voucherView);
  if (st) rows = rows.filter((r) => r.status === st);
  ok(res, { vouchers: rows });
});
route('GET', '/api/fees/vouchers/:id', async (req, res, m) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const v = q.get('SELECT * FROM fee_vouchers WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!v) return bad(res, 'Not found', 404);
  const payments = q.all('SELECT p.*, us.name received_by_name FROM payments p LEFT JOIN users us ON us.id=p.received_by WHERE p.voucher_id=? ORDER BY p.id', v.id);
  ok(res, { voucher: voucherView(v), payments });
});
route('POST', '/api/fees/payments', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const b = req.body;
  const v = q.get('SELECT * FROM fee_vouchers WHERE id=? AND school_id=?', vInt(b.voucher_id), u.school_id);
  if (!v) return bad(res, 'Voucher not found', 404);
  const amt = vMoney(b.amount);
  if (!amt || amt <= 0) return bad(res, 'Positive amount required');
  const method = ['cash', 'bank', 'other'].includes(b.method) ? b.method : 'cash';
  db.exec('BEGIN IMMEDIATE');
  let r;
  try {
    const paid = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
    const outstanding = v.total - paid;
    if (amt > outstanding) { db.exec('ROLLBACK'); return bad(res, `Amount exceeds outstanding (Rs ${rp(outstanding)})`); }
    r = q.run('INSERT INTO payments(school_id,voucher_id,amount,date,method,reference,payer,received_by,note) VALUES(?,?,?,?,?,?,?,?,?)',
      u.school_id, v.id, amt, vDate(b.date) || today(), method, vStr(b.reference, 80), vStr(b.payer, 100), u.id, vStr(b.note, 200));
    const newPaid = paid + amt;
    q.run('UPDATE fee_vouchers SET status=? WHERE id=?', newPaid >= v.total ? 'paid' : 'partial', v.id);
    db.exec('COMMIT');
  } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
  audit(u.school_id, u.id, 'fee_payment', `voucher #${v.id} Rs ${rp(amt)} (${method})`);
  ok(res, { payment_id: r.lastInsertRowid, receipt_url: `/api/receipts/${r.lastInsertRowid}.pdf` }, 201);
});
route('POST', '/api/fees/payments/:id/reverse', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const p = q.get('SELECT * FROM payments WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!p || p.reversed) return bad(res, 'Payment not found or already reversed', 404);
  const reason = vStr(req.body.reason, 200); if (!reason) return bad(res, 'Reversal reason required');
  db.exec('BEGIN IMMEDIATE');
  try {
    q.run('UPDATE payments SET reversed=1, reversal_reason=? WHERE id=?', reason, p.id);
    const v = q.get('SELECT * FROM fee_vouchers WHERE id=?', p.voucher_id);
    const paid = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
    q.run('UPDATE fee_vouchers SET status=? WHERE id=?', paid <= 0 ? 'unpaid' : (paid >= v.total ? 'paid' : 'partial'), v.id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); return bad(res, 'Reversal failed: ' + e.message, 500); }
  audit(u.school_id, u.id, 'payment_reverse', `payment #${p.id} Rs ${rp(p.amount)}: ${reason}`);
  ok(res, { ok: true });
});
route('GET', '/api/fees/dues', async (req, res, m, b, url) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const rows = q.all(`SELECT v.*, s.name student_name, s.admission_no, s.guardian_phone, c.name class_name, sec.name section_name
    FROM fee_vouchers v JOIN students s ON s.id=v.student_id
    LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id
    WHERE v.school_id=? AND v.status!='paid' ORDER BY c.level, s.name LIMIT 1000`, u.school_id);
  const out = rows.map((v) => {
    const paid = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
    return { voucher_id: v.id, student: v.student_name, admission_no: v.admission_no, class_name: v.class_name, section_name: v.section_name, month: v.month, total: v.total, paid, outstanding: v.total - paid, due_date: v.due_date, guardian_phone: v.guardian_phone, overdue: v.due_date < today() };
  }).filter((r) => r.outstanding > 0);
  ok(res, { dues: out, total_outstanding: out.reduce((t, r) => t + r.outstanding, 0) });
});
route('GET', '/api/fees/collection', async (req, res, m, b, url) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const month = vStr(url.searchParams.get('month'), 7) || monthNow();
  const daily = q.all(`SELECT date, method, SUM(amount) total, COUNT(*) count FROM payments
    WHERE school_id=? AND reversed=0 AND strftime('%Y-%m',date)=? GROUP BY date, method ORDER BY date`, u.school_id, month);
  const byClass = q.all(`SELECT c.name class_name, SUM(p.amount) total FROM payments p
    JOIN fee_vouchers v ON v.id=p.voucher_id JOIN students s ON s.id=v.student_id LEFT JOIN classes c ON c.id=s.class_id
    WHERE p.school_id=? AND p.reversed=0 AND strftime('%Y-%m',p.date)=? GROUP BY c.name ORDER BY c.level`, u.school_id, month);
  ok(res, { month, daily, by_class: byClass, total: daily.reduce((t, r) => t + r.total, 0) });
});

// ---------- expenses & accounts ----------
route('GET', '/api/expenses', async (req, res, m, b, url) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const month = vStr(url.searchParams.get('month'), 7);
  let sql = `SELECT e.*, c.name category_name, v.name vendor_name FROM expenses e
    LEFT JOIN expense_categories c ON c.id=e.category_id LEFT JOIN vendors v ON v.id=e.vendor_id WHERE e.school_id=?`;
  const args = [u.school_id];
  if (month) { sql += " AND strftime('%Y-%m',e.date)=?"; args.push(month); }
  sql += ' ORDER BY e.date DESC, e.id DESC LIMIT 500';
  ok(res, { expenses: q.all(sql, ...args), categories: q.all('SELECT * FROM expense_categories WHERE school_id=? ORDER BY name', u.school_id), vendors: q.all('SELECT * FROM vendors WHERE school_id=? ORDER BY name', u.school_id) });
});
route('POST', '/api/expenses', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const b = req.body;
  const amt = vMoney(b.amount);
  if (!amt || amt <= 0) return bad(res, 'Positive amount required');
  let catId = vInt(b.category_id);
  const newCat = vStr(b.new_category, 60);
  if (!catId && newCat) catId = q.run('INSERT INTO expense_categories(school_id,name) VALUES(?,?)', u.school_id, newCat).lastInsertRowid;
  if (catId && !q.get('SELECT id FROM expense_categories WHERE id=? AND school_id=?', catId, u.school_id)) return bad(res, 'Category not in your school');
  q.run('INSERT INTO expenses(school_id,category_id,vendor_id,amount,date,method,reference,note,entered_by) VALUES(?,?,?,?,?,?,?,?,?)',
    u.school_id, catId, vInt(b.vendor_id), amt, vDate(b.date) || today(), ['cash', 'bank', 'other'].includes(b.method) ? b.method : 'cash', vStr(b.reference, 80), vStr(b.note, 250), u.id);
  audit(u.school_id, u.id, 'expense', `Rs ${rp(amt)}`);
  ok(res, { ok: true }, 201);
});
route('DELETE', '/api/expenses/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const e = q.get('SELECT * FROM expenses WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!e) return bad(res, 'Not found', 404);
  audit(u.school_id, u.id, 'expense_delete', `Rs ${rp(e.amount)} dated ${e.date}: ${e.note}`);
  q.run('DELETE FROM expenses WHERE id=?', e.id);
  // detach attached bill files (bytes removed when unreferenced)
  q.all("SELECT * FROM file_metadata WHERE school_id=? AND owner_type='expense' AND owner_id=?", u.school_id, e.id).forEach((f) => {
    q.run('DELETE FROM file_metadata WHERE id=?', f.id);
    if (!q.get('SELECT id FROM file_metadata WHERE sha256=?', f.sha256)) { try { fs.unlinkSync(path.join(UPLOAD_DIR, f.sha256)); } catch {} }
  });
  ok(res, { ok: true });
});
route('POST', '/api/vendors', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const name = vStr(req.body.name, 100); if (!name) return bad(res, 'Vendor name required');
  q.run('INSERT INTO vendors(school_id,name,phone,note) VALUES(?,?,?,?)', u.school_id, name, vStr(req.body.phone, 40), vStr(req.body.note, 200));
  ok(res, { ok: true }, 201);
});
route('GET', '/api/reports/finance', async (req, res, m, b, url) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const month = vStr(url.searchParams.get('month'), 7) || monthNow();
  const sid = u.school_id;
  const income = q.get("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE school_id=? AND reversed=0 AND strftime('%Y-%m',date)=?", sid, month).s;
  const expense = q.get("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE school_id=? AND strftime('%Y-%m',date)=?", sid, month).s;
  const byCat = q.all(`SELECT c.name category, SUM(e.amount) total FROM expenses e LEFT JOIN expense_categories c ON c.id=e.category_id
    WHERE e.school_id=? AND strftime('%Y-%m',e.date)=? GROUP BY c.name ORDER BY total DESC`, sid, month);
  const salaryPaid = q.get("SELECT COALESCE(SUM(amount+allowances-deductions),0) s FROM salary_payments WHERE school_id=? AND month=?", sid, month).s;
  ok(res, { month, fee_income: income, expenses: expense, salaries_paid: salaryPaid, surplus: income - expense - salaryPaid, expense_by_category: byCat });
});

// ---------- exams, marks, report cards ----------
function gradeFor(pct) {
  if (pct >= 90) return 'A+'; if (pct >= 80) return 'A'; if (pct >= 70) return 'B';
  if (pct >= 60) return 'C'; if (pct >= 50) return 'D'; if (pct >= 40) return 'E'; return 'F';
}
route('GET', '/api/exams', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  const exams = q.all('SELECT e.*, c.name class_name FROM exams e LEFT JOIN classes c ON c.id=e.class_id WHERE e.school_id=? ORDER BY e.id DESC', u.school_id);
  exams.forEach((e) => { e.subjects = q.all('SELECT * FROM exam_subjects WHERE exam_id=?', e.id); });
  ok(res, { exams });
});
route('POST', '/api/exams', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 80); if (!name) return bad(res, 'Exam name required');
  if (b.class_id && !q.get('SELECT id FROM classes WHERE id=? AND school_id=?', b.class_id, u.school_id)) return bad(res, 'Class not in your school');
  const eid = q.run('INSERT INTO exams(school_id,name,class_id,start_date,end_date,term) VALUES(?,?,?,?,?,?)',
    u.school_id, name, vInt(b.class_id), vDate(b.start_date), vDate(b.end_date), vStr(b.term, 60) || '').lastInsertRowid;
  if (Array.isArray(b.subjects)) b.subjects.slice(0, 30).forEach((s) => {
    const sn = vStr(String(s.subject || s.name || ''), 80); const mm = vInt(s.max_marks, 100);
    if (sn) q.run('INSERT INTO exam_subjects(exam_id,subject,max_marks) VALUES(?,?,?)', eid, sn, mm);
  });
  ok(res, { id: eid }, 201);
});
route('POST', '/api/exams/subjects/:id/marks', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'teacher', 'staff']); if (!u) return;
  const es = q.get('SELECT es.*, e.school_id FROM exam_subjects es JOIN exams e ON e.id=es.exam_id WHERE es.id=?', m.id);
  if (!es || es.school_id !== u.school_id) return bad(res, 'Not found', 404);
  if (es.marks_status === 'approved') return bad(res, 'Marks approved and locked - reopen to edit', 409);
  const b = req.body;
  if (!Array.isArray(b.records)) return bad(res, 'records array required');
  if (es.marks_status === 'draft') q.run("UPDATE exam_subjects SET marks_status='submitted' WHERE id=?", es.id);
  const ups = db.prepare(`INSERT INTO marks(school_id,exam_subject_id,student_id,obtained,absent,entered_by,updated_at) VALUES(?,?,?,?,?,?,datetime('now'))
    ON CONFLICT(exam_subject_id,student_id) DO UPDATE SET obtained=excluded.obtained, absent=excluded.absent, entered_by=excluded.entered_by, updated_at=datetime('now')`);
  let n = 0;
  for (const r of b.records.slice(0, 2000)) {
    const stu = q.get('SELECT id FROM students WHERE id=? AND school_id=?', r.student_id, u.school_id);
    if (!stu) continue;
    const absent = r.absent ? 1 : 0;
    let obt = absent ? null : (r.obtained === null || r.obtained === undefined ? null : Number(r.obtained));
    if (obt != null && (!Number.isFinite(obt) || obt < 0 || obt > es.max_marks)) continue;
    ups.run(u.school_id, es.id, stu.id, obt, absent, u.id); n++;
  }
  audit(u.school_id, u.id, 'marks_entry', `exam_subject #${es.id}: ${n} records`);
  ok(res, { saved: n });
});
route('POST', '/api/exams/subjects/:id/approve-marks', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const es = q.get('SELECT es.*, e.school_id FROM exam_subjects es JOIN exams e ON e.id=es.exam_id WHERE es.id=?', m.id);
  if (!es || es.school_id !== u.school_id) return bad(res, 'Not found', 404);
  q.run("UPDATE exam_subjects SET marks_status='approved' WHERE id=?", es.id);
  audit(u.school_id, u.id, 'marks_approve', `exam_subject #${es.id} (${es.subject})`);
  ok(res, { ok: true, status: 'approved' });
});
route('POST', '/api/exams/subjects/:id/reopen-marks', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const es = q.get('SELECT es.*, e.school_id FROM exam_subjects es JOIN exams e ON e.id=es.exam_id WHERE es.id=?', m.id);
  if (!es || es.school_id !== u.school_id) return bad(res, 'Not found', 404);
  q.run("UPDATE exam_subjects SET marks_status='draft' WHERE id=?", es.id);
  audit(u.school_id, u.id, 'marks_reopen', `exam_subject #${es.id} (${es.subject})`);
  ok(res, { ok: true, status: 'draft' });
});
route('GET', '/api/exams/:id/results', async (req, res, m) => {
  const u = needSchool(req, res); if (!u) return;
  const exam = q.get('SELECT * FROM exams WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!exam) return bad(res, 'Not found', 404);
  const subjects = q.all('SELECT * FROM exam_subjects WHERE exam_id=?', exam.id);
  let stuSql = "SELECT * FROM students WHERE school_id=? AND status='active'";
  const args = [u.school_id];
  if (exam.class_id) { stuSql += ' AND class_id=?'; args.push(exam.class_id); }
  stuSql += ' ORDER BY roll_no, name';
  const students = q.all(stuSql, ...args);
  const results = students.map((s) => {
    const per = subjects.map((sub) => {
      const mk = q.get('SELECT * FROM marks WHERE exam_subject_id=? AND student_id=?', sub.id, s.id);
      return { subject: sub.subject, max_marks: sub.max_marks, obtained: mk ? mk.obtained : null, absent: mk ? mk.absent : 0, marks_status: sub.marks_status };
    });
    const scored = per.filter((p) => p.obtained != null && !p.absent);
    const totalMax = subjects.reduce((t, p) => t + p.max_marks, 0);
    const totalObt = per.reduce((t, p) => t + (p.absent ? 0 : (p.obtained || 0)), 0);
    const pct = totalMax && scored.length ? Math.round(totalObt * 1000 / totalMax) / 10 : null;
    return { student_id: s.id, name: s.name, roll_no: s.roll_no, admission_no: s.admission_no, subjects: per, total_max: totalMax, total_obtained: totalObt, percentage: pct, grade: pct == null ? '' : gradeFor(pct) };
  });
  const ranked = results.filter((r) => r.percentage != null).sort((a, b) => b.percentage - a.percentage);
  ranked.forEach((r, i) => { r.position = i + 1; });
  ok(res, { exam, results });
});
route('GET', '/api/exams/:id/report-card/:studentId', async (req, res, m) => {
  const u = needSchool(req, res); if (!u) return;
  const exam = q.get('SELECT * FROM exams WHERE id=? AND school_id=?', m.id, u.school_id);
  const stu = q.get('SELECT * FROM students WHERE id=? AND school_id=?', m.studentId, u.school_id);
  if (!exam || !stu) return bad(res, 'Not found', 404);
  const subjects = q.all('SELECT * FROM exam_subjects WHERE exam_id=?', exam.id).map((sub) => {
    const mk = q.get('SELECT * FROM marks WHERE exam_subject_id=? AND student_id=?', sub.id, stu.id);
    return { subject: sub.subject, max_marks: sub.max_marks, obtained: mk ? mk.obtained : null, absent: mk ? mk.absent : 0, marks_status: sub.marks_status };
  });
  const totalMax = subjects.reduce((t, p) => t + p.max_marks, 0);
  const totalObt = subjects.reduce((t, p) => t + (p.absent ? 0 : (p.obtained || 0)), 0);
  const pct = totalMax ? Math.round(totalObt * 1000 / totalMax) / 10 : null;
  const school = q.get('SELECT name,address,phone FROM schools WHERE id=?', u.school_id);
  const cls = stu.class_id ? q.get('SELECT name FROM classes WHERE id=?', stu.class_id) : null;
  ok(res, { school, exam: { id: exam.id, name: exam.name }, student: { name: stu.name, admission_no: stu.admission_no, roll_no: stu.roll_no, class_name: cls ? cls.name : '' }, subjects, total_max: totalMax, total_obtained: totalObt, percentage: pct, grade: pct == null ? '' : gradeFor(pct) });
});

// ---------- timetable ----------
route('GET', '/api/timetable', async (req, res, m, b, url) => {
  const u = needSchool(req, res, ALL_SCHOOL_ROLES); if (!u) return;
  const cls = url.searchParams.get('class_id');
  let sql = `SELECT t.*, c.name class_name, s.name section_name, e.name teacher_name FROM timetable_entries t
    JOIN classes c ON c.id=t.class_id LEFT JOIN sections s ON s.id=t.section_id LEFT JOIN employees e ON e.id=t.teacher_id
    WHERE t.school_id=?`;
  const args = [u.school_id];
  if (cls) { sql += ' AND t.class_id=?'; args.push(cls); }
  sql += ' ORDER BY t.day, t.period';
  ok(res, { entries: q.all(sql, ...args) });
});
route('POST', '/api/timetable', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const day = vStr(b.day, 9), period = vInt(b.period);
  if (!['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].includes(day) || !period) return bad(res, 'day (Mon..Sun) and period required');
  if (!q.get('SELECT id FROM classes WHERE id=? AND school_id=?', b.class_id, u.school_id)) return bad(res, 'Class not in your school');
  const ttSecErr = sectionCheck(u.school_id, b.section_id, b.class_id); if (ttSecErr) return bad(res, ttSecErr);
  q.run('INSERT INTO timetable_entries(school_id,class_id,section_id,day,period,subject,teacher_id,room) VALUES(?,?,?,?,?,?,?,?)',
    u.school_id, vInt(b.class_id), vInt(b.section_id), day, period, vStr(b.subject, 80), vInt(b.teacher_id), vStr(b.room, 40));
  ok(res, { ok: true }, 201);
});
route('DELETE', '/api/timetable/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  q.run('DELETE FROM timetable_entries WHERE id=? AND school_id=?', m.id, u.school_id);
  ok(res, { ok: true });
});

// ---------- announcements, homework, meetings ----------
route('GET', '/api/announcements', async (req, res) => {
  const u = needAuth(req, res); if (!u) return;
  const audMap = { parent: "('all','parents')", student: "('all')", teacher: "('all','teachers')", accountant: "('all')", staff: "('all','parents','teachers')", admin: "('all','parents','teachers')" };
  const aud = u.role === 'super_admin' ? null : (audMap[u.role] || "('all')");
  const rows = u.school_id
    ? q.all(`SELECT a.*, us.name author FROM announcements a LEFT JOIN users us ON us.id=a.created_by WHERE (a.school_id=? OR a.school_id IS NULL) AND a.audience IN ${aud} ORDER BY a.id DESC LIMIT 100`, u.school_id)
    : q.all('SELECT a.*, us.name author FROM announcements a LEFT JOIN users us ON us.id=a.created_by ORDER BY a.id DESC LIMIT 100');
  ok(res, { announcements: rows });
});
route('POST', '/api/announcements', async (req, res) => {
  const u = needAuth(req, res); if (!u) return;
  if (!['admin', 'staff', 'super_admin'].includes(u.role)) return bad(res, 'Not permitted', 403);
  const b = req.body;
  const title = vStr(b.title, 150); if (!title) return bad(res, 'Title required');
  const audience = ['all', 'parents', 'teachers'].includes(b.audience) ? b.audience : 'all';
  const sid = u.role === 'super_admin' ? (b.school_id ? vInt(b.school_id) : null) : u.school_id;
  q.run('INSERT INTO announcements(school_id,title,body,audience,created_by) VALUES(?,?,?,?,?)', sid, title, vStr(b.body, 2000), audience, u.id);
  ok(res, { ok: true }, 201);
});
route('GET', '/api/homework', async (req, res, m, b, url) => {
  const u = needSchool(req, res, ALL_SCHOOL_ROLES); if (!u) return;
  let sql = `SELECT h.*, c.name class_name, s.name section_name, us.name teacher_name FROM homework h
    JOIN classes c ON c.id=h.class_id LEFT JOIN sections s ON s.id=h.section_id LEFT JOIN users us ON us.id=h.created_by
    WHERE h.school_id=?`;
  const args = [u.school_id];
  if (url.searchParams.get('class_id')) { sql += ' AND h.class_id=?'; args.push(url.searchParams.get('class_id')); }
  sql += ' ORDER BY h.id DESC LIMIT 200';
  ok(res, { homework: q.all(sql, ...args) });
});
route('POST', '/api/homework', async (req, res) => {
  const u = needSchool(req, res, ['admin', 'teacher', 'staff']); if (!u) return;
  const b = req.body;
  const title = vStr(b.title, 150); if (!title) return bad(res, 'Title required');
  if (!q.get('SELECT id FROM classes WHERE id=? AND school_id=?', b.class_id, u.school_id)) return bad(res, 'Class not in your school');
  const hwSecErr = sectionCheck(u.school_id, b.section_id, b.class_id); if (hwSecErr) return bad(res, hwSecErr);
  q.run('INSERT INTO homework(school_id,class_id,section_id,subject,title,detail,due_date,created_by) VALUES(?,?,?,?,?,?,?,?)',
    u.school_id, vInt(b.class_id), vInt(b.section_id), vStr(b.subject, 80), title, vStr(b.detail, 1500), vDate(b.due_date), u.id);
  ok(res, { ok: true }, 201);
});
route('GET', '/api/meetings', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  ok(res, { meetings: q.all('SELECT * FROM meetings WHERE school_id=? ORDER BY date DESC LIMIT 100', u.school_id) });
});
route('POST', '/api/meetings', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const title = vStr(b.title, 150), date = vDate(b.date);
  if (!title || !date) return bad(res, 'Title and date required');
  q.run('INSERT INTO meetings(school_id,title,with_whom,date,notes,created_by) VALUES(?,?,?,?,?,?)',
    u.school_id, title, vStr(b.with_whom, 120), date, vStr(b.notes, 1000), u.id);
  ok(res, { ok: true }, 201);
});

// ---------- library ----------
route('GET', '/api/library/books', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  const books = q.all('SELECT * FROM library_books WHERE school_id=? ORDER BY title', u.school_id);
  const issues = q.all(`SELECT li.*, lb.title book_title, s.name student_name, e.name employee_name FROM library_issues li
    JOIN library_books lb ON lb.id=li.book_id LEFT JOIN students s ON s.id=li.student_id LEFT JOIN employees e ON e.id=li.employee_id
    WHERE li.school_id=? AND li.return_date='' ORDER BY li.due_date`, u.school_id);
  ok(res, { books, issued: issues });
});
route('POST', '/api/library/books', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const title = vStr(b.title, 150); if (!title) return bad(res, 'Book title required');
  q.run('INSERT INTO library_books(school_id,title,author,isbn,copies) VALUES(?,?,?,?,?)', u.school_id, title, vStr(b.author, 100), vStr(b.isbn, 30), vInt(b.copies, 1));
  ok(res, { ok: true }, 201);
});
route('POST', '/api/library/issue', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const book = q.get('SELECT * FROM library_books WHERE id=? AND school_id=?', vInt(b.book_id), u.school_id);
  if (!book) return bad(res, 'Book not found', 404);
  const stuId = vInt(b.student_id), empId = vInt(b.employee_id);
  if (!stuId && !empId) return bad(res, 'student_id or employee_id required');
  if (stuId && !q.get('SELECT id FROM students WHERE id=? AND school_id=?', stuId, u.school_id)) return bad(res, 'Student not in your school', 403);
  if (empId && !q.get('SELECT id FROM employees WHERE id=? AND school_id=?', empId, u.school_id)) return bad(res, 'Employee not in your school', 403);
  const outCount = q.get("SELECT COUNT(*) c FROM library_issues WHERE book_id=? AND return_date=''", book.id).c;
  if (outCount >= book.copies) return bad(res, 'No copies available');
  const due = vDate(b.due_date) || new Date(Date.now() + 14 * 864e5).toISOString().slice(0, 10);
  q.run('INSERT INTO library_issues(school_id,book_id,student_id,employee_id,issue_date,due_date) VALUES(?,?,?,?,?,?)',
    u.school_id, book.id, stuId, empId, today(), due);
  ok(res, { ok: true }, 201);
});
route('POST', '/api/library/return/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const li = q.get('SELECT * FROM library_issues WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!li || li.return_date) return bad(res, 'Issue record not found', 404);
  q.run('UPDATE library_issues SET return_date=?, fine=? WHERE id=?', today(), vInt(req.body.fine, 0), li.id);
  ok(res, { ok: true });
});

// ---------- transport ----------
route('GET', '/api/transport', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  const routesList = q.all('SELECT * FROM transport_routes WHERE school_id=? ORDER BY name', u.school_id);
  const assigns = q.all(`SELECT ta.*, s.name student_name, s.admission_no FROM transport_assignments ta JOIN students s ON s.id=ta.student_id WHERE ta.school_id=?`, u.school_id);
  routesList.forEach((r) => { r.students = assigns.filter((a) => a.route_id === r.id); });
  ok(res, { routes: routesList });
});
route('POST', '/api/transport/routes', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 100); if (!name) return bad(res, 'Route name required');
  q.run('INSERT INTO transport_routes(school_id,name,driver_name,driver_phone,vehicle,monthly_fee) VALUES(?,?,?,?,?,?)',
    u.school_id, name, vStr(b.driver_name, 80), vStr(b.driver_phone, 40), vStr(b.vehicle, 60), (vMoney(b.monthly_fee) ?? 0));
  ok(res, { ok: true }, 201);
});
route('POST', '/api/transport/assign', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const rid = vInt(b.route_id), sid2 = vInt(b.student_id);
  if (!rid || !sid2) return bad(res, 'route_id and student_id required');
  if (!q.get('SELECT id FROM transport_routes WHERE id=? AND school_id=?', rid, u.school_id)) return bad(res, 'Route not in your school');
  if (!q.get('SELECT id FROM students WHERE id=? AND school_id=?', sid2, u.school_id)) return bad(res, 'Student not in your school');
  try { q.run('INSERT INTO transport_assignments(school_id,route_id,student_id,stop) VALUES(?,?,?,?)', u.school_id, rid, sid2, vStr(b.stop, 80)); }
  catch { return bad(res, 'Already assigned to this route'); }
  ok(res, { ok: true }, 201);
});
route('DELETE', '/api/transport/assign/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const r = q.run('DELETE FROM transport_assignments WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!r.changes) return bad(res, 'Not found', 404);
  ok(res, { ok: true });
});

// ---------- inventory ----------
route('GET', '/api/inventory', async (req, res) => {
  const u = needSchool(req, res); if (!u) return;
  ok(res, { items: q.all('SELECT * FROM inventory_items WHERE school_id=? ORDER BY category, name', u.school_id) });
});
route('POST', '/api/inventory', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const name = vStr(b.name, 120); if (!name) return bad(res, 'Item name required');
  q.run('INSERT INTO inventory_items(school_id,name,category,quantity,unit,note) VALUES(?,?,?,?,?,?)',
    u.school_id, name, vStr(b.category, 60), vInt(b.quantity, 0), vStr(b.unit, 20), vStr(b.note, 200));
  ok(res, { ok: true }, 201);
});
route('PATCH', '/api/inventory/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const it = q.get('SELECT * FROM inventory_items WHERE id=? AND school_id=?', m.id, u.school_id); if (!it) return bad(res, 'Not found', 404);
  const b = req.body;
  q.run('UPDATE inventory_items SET name=?,category=?,quantity=?,unit=?,note=? WHERE id=?',
    vStr(b.name, 120) || it.name, b.category !== undefined ? vStr(b.category, 60) : it.category,
    b.quantity !== undefined ? vInt(b.quantity, it.quantity) : it.quantity,
    b.unit !== undefined ? vStr(b.unit, 20) : it.unit, b.note !== undefined ? vStr(b.note, 200) : it.note, it.id);
  ok(res, { ok: true });
});

// ---------- documents (certificates) ----------
route('GET', '/api/documents', async (req, res, m, b, url) => {
  const u = needSchool(req, res); if (!u) return;
  const stu = url.searchParams.get('student_id');
  let sql = `SELECT d.*, s.name student_name FROM student_documents d JOIN students s ON s.id=d.student_id WHERE d.school_id=?`;
  const args = [u.school_id];
  if (stu) { sql += ' AND d.student_id=?'; args.push(stu); }
  sql += ' ORDER BY d.id DESC LIMIT 100';
  ok(res, { documents: q.all(sql, ...args) });
});
route('POST', '/api/documents', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const b = req.body;
  const stu = q.get('SELECT * FROM students WHERE id=? AND school_id=?', vInt(b.student_id), u.school_id);
  if (!stu) return bad(res, 'Student not found', 404);
  const type = ['admission_form', 'leaving_certificate', 'character_certificate', 'bonafide', 'other'].includes(b.doc_type) ? b.doc_type : 'other';
  const school = q.get('SELECT * FROM schools WHERE id=?', u.school_id);
  const titles = { admission_form: 'Admission Form', leaving_certificate: 'School Leaving Certificate', character_certificate: 'Character Certificate', bonafide: 'Bonafide Certificate', other: vStr(b.title, 120) || 'Document' };
  const body = vStr(b.body, 2000) || `${school.name}\n${school.address}\n\nThis is to certify that ${stu.name}, son/daughter of ${stu.father_name || '-'}, admission no ${stu.admission_no}, is a bonafide student of this school.\n\nDate: ${today()}\n\nPrincipal's signature: ____________`;
  const r = q.run('INSERT INTO student_documents(school_id,student_id,doc_type,title,body,issued_by) VALUES(?,?,?,?,?,?)',
    u.school_id, stu.id, type, titles[type], body, u.id);
  audit(u.school_id, u.id, 'document_issue', `${titles[type]} for ${stu.admission_no}`);
  ok(res, { id: r.lastInsertRowid }, 201);
});
route('GET', '/api/documents/:id', async (req, res, m) => {
  const u = needSchool(req, res); if (!u) return;
  const d = q.get('SELECT d.*, s.name student_name, s.admission_no FROM student_documents d JOIN students s ON s.id=d.student_id WHERE d.id=? AND d.school_id=?', m.id, u.school_id);
  if (!d) return bad(res, 'Not found', 404);
  ok(res, { document: d });
});

// ---------- private file storage (photos, admission docs, expense bills) ----------
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const FILE_MAX = 5 * 1024 * 1024; // 5MB decoded
function sniffMime(buf) {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length >= 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf.length >= 12 && buf.slice(0, 4).toString('latin1') === 'RIFF' && buf.slice(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.length >= 5 && buf.slice(0, 5).toString('latin1') === '%PDF-') return 'application/pdf';
  return null;
}
function fileOwnerCheck(u, ownerType, ownerId) {
  if (ownerType === 'student') return !!q.get('SELECT id FROM students WHERE id=? AND school_id=?', ownerId, u.school_id);
  if (ownerType === 'expense') return !!q.get('SELECT id FROM expenses WHERE id=? AND school_id=?', ownerId, u.school_id);
  return false;
}
const SCHOOL_STORAGE_CAP = 200 * 1024 * 1024; // 200MB per school
const SCHOOL_FILE_CAP = 2000;
const uploadHits = new Map(); // school_id -> timestamps[]
route('POST', '/api/files', async (req, res) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'staff']); if (!u) return;
  const b = req.body;
  const ownerType = vStr(b.owner_type, 20), ownerId = vInt(b.owner_id);
  if (!['student', 'expense'].includes(ownerType) || !ownerId) return bad(res, 'owner_type (student|expense) and owner_id required');
  if (ownerType === 'expense' && !['admin', 'accountant'].includes(u.role)) return bad(res, 'Only admin/accountant can attach expense bills', 403);
  if (ownerType === 'student' && !['admin', 'staff'].includes(u.role)) return bad(res, 'Only admin/staff can attach student files', 403);
  if (!fileOwnerCheck(u, ownerType, ownerId)) return bad(res, 'Owner record not in your school', 404);
  const nowT = Date.now();
  const hits = (uploadHits.get(u.school_id) || []).filter((t) => nowT - t < 10 * 60 * 1000);
  if (hits.length >= 30) return bad(res, 'Upload rate limit reached (30 per 10 minutes) - try later', 429);
  hits.push(nowT); uploadHits.set(u.school_id, hits);
  const agg = q.get('SELECT COALESCE(SUM(size),0) s, COUNT(*) c FROM file_metadata WHERE school_id=?', u.school_id);
  if (agg.c >= SCHOOL_FILE_CAP) return bad(res, `School file limit reached (${SCHOOL_FILE_CAP}) - delete old files first`, 413);
  const fname = vStr(b.filename, 120); if (!fname) return bad(res, 'filename required');
  const b64 = String(b.data_base64 || '');
  if (!b64 || b64.length > FILE_MAX * 1.4) return bad(res, 'data_base64 required (max 5MB file)', 413);
  let buf; try { buf = Buffer.from(b64, 'base64'); } catch { return bad(res, 'invalid base64'); }
  if (!buf.length || buf.length > FILE_MAX) return bad(res, 'file must be 1 byte - 5MB', 413);
  if (agg.s + buf.length > SCHOOL_STORAGE_CAP) return bad(res, `School storage limit reached (${Math.round(SCHOOL_STORAGE_CAP / 1048576)}MB) - delete old files first`, 413);
  const mime = sniffMime(buf);
  if (!mime) return bad(res, 'Only JPG, PNG, WEBP or PDF files are accepted (checked by content, not extension)');
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  const fpath = path.join(UPLOAD_DIR, sha);
  if (!fs.existsSync(fpath)) { fs.writeFileSync(fpath, buf, { mode: 0o600 }); }
  const r = q.run('INSERT INTO file_metadata(school_id,owner_type,owner_id,filename,mime,size,sha256,uploaded_by) VALUES(?,?,?,?,?,?,?,?)',
    u.school_id, ownerType, ownerId, fname.replace(/[^\w. ()-]/g, '_'), mime, buf.length, sha, u.id);
  audit(u.school_id, u.id, 'file_upload', `${ownerType}#${ownerId}: ${fname} (${buf.length}b)`);
  ok(res, { id: r.lastInsertRowid, sha256: sha, size: buf.length, mime }, 201);
});
function sendFile(req, res, u, row) {
  const fpath = path.join(UPLOAD_DIR, row.sha256);
  if (!fs.existsSync(fpath)) return bad(res, 'File bytes missing', 404);
  const buf = fs.readFileSync(fpath);
  if (crypto.createHash('sha256').update(buf).digest('hex') !== row.sha256) return bad(res, 'File integrity check failed', 500);
  res.writeHead(200, Object.assign({ 'Content-Type': row.mime, 'Content-Length': buf.length,
    'Content-Disposition': `${row.mime === 'application/pdf' ? 'attachment' : 'inline'}; filename="${String(row.filename).replace(/[^\w. ()-]/g, '_')}"` }, SEC_HEADERS));
  res.end(buf);
}
route('GET', '/api/files/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'staff']); if (!u) return;
  const row = q.get('SELECT * FROM file_metadata WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!row) return bad(res, 'Not found', 404);
  sendFile(req, res, u, row);
});
route('GET', '/api/files', async (req, res, m, b, url) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'staff']); if (!u) return;
  const ot = url.searchParams.get('owner_type'), oid = vInt(url.searchParams.get('owner_id'));
  let sql = 'SELECT id,owner_type,owner_id,filename,mime,size,sha256,created_at FROM file_metadata WHERE school_id=?';
  const args = [u.school_id];
  if (ot && oid) { sql += ' AND owner_type=? AND owner_id=?'; args.push(vStr(ot, 20), oid); }
  sql += ' ORDER BY id DESC LIMIT 200';
  ok(res, { files: q.all(sql, ...args) });
});
route('DELETE', '/api/files/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const row = q.get('SELECT * FROM file_metadata WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!row) return bad(res, 'Not found', 404);
  q.run('UPDATE students SET photo_file_id=NULL WHERE school_id=? AND photo_file_id=?', u.school_id, row.id);
  q.run('DELETE FROM file_metadata WHERE id=?', row.id);
  if (!q.get('SELECT id FROM file_metadata WHERE sha256=?', row.sha256)) { try { fs.unlinkSync(path.join(UPLOAD_DIR, row.sha256)); } catch {} }
  audit(u.school_id, u.id, 'file_delete', `${row.filename}`);
  ok(res, { ok: true });
});
route('POST', '/api/students/:id/photo', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const stu = q.get('SELECT id FROM students WHERE id=? AND school_id=?', m.id, u.school_id); if (!stu) return bad(res, 'Not found', 404);
  const fid = vInt(req.body.file_id);
  const f = q.get("SELECT * FROM file_metadata WHERE id=? AND school_id=? AND owner_type='student' AND owner_id=?", fid, u.school_id, stu.id);
  if (!f) return bad(res, 'Upload the photo first (POST /api/files with owner_type=student)', 400);
  if (!f.mime.startsWith('image/')) return bad(res, 'Photo must be an image');
  q.run('UPDATE students SET photo_file_id=? WHERE id=?', f.id, stu.id);
  ok(res, { ok: true });
});
route('GET', '/api/students/:id/photo', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'accountant', 'staff', 'teacher', 'student']); if (!u) return;
  const stu = q.get('SELECT id, photo_file_id FROM students WHERE id=? AND school_id=?', m.id, u.school_id); if (!stu) return bad(res, 'Not found', 404);
  if (u.role === 'student' && u.student_id !== stu.id) return bad(res, 'Forbidden', 403);
  if (!stu.photo_file_id) return bad(res, 'No photo', 404);
  const row = q.get('SELECT * FROM file_metadata WHERE id=? AND school_id=?', stu.photo_file_id, u.school_id);
  if (!row) return bad(res, 'Not found', 404);
  sendFile(req, res, u, row);
});
route('GET', '/api/parent/files/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['parent']); if (!u) return;
  const row = q.get('SELECT * FROM file_metadata WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!row) return bad(res, 'Not found', 404);
  if (row.owner_type !== 'student') return bad(res, 'Forbidden', 403);
  const kids = parentChildren(u).map((k) => k.id);
  if (!kids.includes(row.owner_id)) return bad(res, 'Forbidden', 403);
  sendFile(req, res, u, row);
});

// ---------- parent portal (read-only, linked children only) ----------
function parentChildren(u) {
  if (u.role === 'student') {
    if (!u.student_id) return [];
    return q.all('SELECT * FROM students WHERE id=? AND school_id=?', u.student_id, u.school_id);
  }
  return q.all(`SELECT s.* FROM student_guardians sg
    JOIN guardians g ON g.id=sg.guardian_id JOIN students s ON s.id=sg.student_id
    WHERE g.user_id=? AND s.school_id=?`, u.id, u.school_id);
}
route('GET', '/api/parent/children', async (req, res) => {
  const u = needSchool(req, res, ['parent', 'student']); if (!u) return;
  ok(res, { children: parentChildren(u).map(studentView) });
});
route('GET', '/api/parent/children/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['parent', 'student']); if (!u) return;
  const child = parentChildren(u).find((c) => String(c.id) === String(m.id));
  if (!child) return bad(res, 'Not your linked child', 403);
  const vouchers = q.all('SELECT * FROM fee_vouchers WHERE student_id=? ORDER BY month DESC LIMIT 12', child.id).map((v) => {
    const paid = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
    return { id: v.id, month: v.month, total: v.total, paid, outstanding: v.total - paid, due_date: v.due_date, status: paid <= 0 ? 'unpaid' : (v.total - paid <= 0 ? 'paid' : 'partial') };
  });
  const att = q.all('SELECT date,status FROM student_attendance WHERE student_id=? ORDER BY date DESC LIMIT 62', child.id);
  const hw = q.all('SELECT h.subject,h.title,h.detail,h.due_date FROM homework h WHERE h.school_id=? AND h.class_id=? ORDER BY h.id DESC LIMIT 20', u.school_id, child.class_id);
  const anns = q.all("SELECT title,body,created_at FROM announcements WHERE (school_id=? OR school_id IS NULL) AND (audience IN ('all','parents') AND parent_user_id IS NULL OR parent_user_id=?) ORDER BY id DESC LIMIT 20", u.school_id, u.id);
  const files = q.all("SELECT id,filename,mime,size,created_at FROM file_metadata WHERE school_id=? AND owner_type='student' AND owner_id=? ORDER BY id DESC LIMIT 50", u.school_id, child.id);
  const view = studentView(child); delete view.photo_file_id;
  const progress = studentProgress(u.school_id, child.id);
  ok(res, { child: view, photo_url: child.photo_file_id ? `/api/parent/files/${child.photo_file_id}` : null, files, vouchers, attendance: att, homework: hw, announcements: anns, progress });
});
route('GET', '/api/parent/children/:id/results', async (req, res, m) => {
  const u = needSchool(req, res, ['parent', 'student']); if (!u) return;
  const child = parentChildren(u).find((c) => String(c.id) === String(m.id));
  if (!child) return bad(res, 'Not your linked child', 403);
  const exams = q.all("SELECT DISTINCT e.id, e.name FROM exams e JOIN exam_subjects es ON es.exam_id=e.id JOIN marks mk ON mk.exam_subject_id=es.id WHERE e.school_id=? AND mk.student_id=? AND es.marks_status='approved'", u.school_id, child.id);
  const results = exams.map((ex) => {
    const subjects = q.all(`SELECT es.subject, es.max_marks, mk.obtained, mk.absent FROM exam_subjects es JOIN marks mk ON mk.exam_subject_id=es.id WHERE es.exam_id=? AND mk.student_id=? AND es.marks_status='approved'`, ex.id, child.id);
    const tMax = subjects.reduce((t, s) => t + s.max_marks, 0);
    const tObt = subjects.reduce((t, s) => t + (s.absent ? 0 : (s.obtained || 0)), 0);
    const pct = tMax ? Math.round(tObt * 1000 / tMax) / 10 : null;
    return { exam: ex.name, subjects, total_max: tMax, total_obtained: tObt, percentage: pct, grade: pct == null ? '' : gradeFor(pct) };
  });
  ok(res, { results });
});

// ---------- holidays ----------
route('GET', '/api/holidays', async (req, res) => {
  const u = needSchool(req, res, ALL_SCHOOL_ROLES); if (!u) return;
  ok(res, { holidays: q.all('SELECT * FROM holidays WHERE school_id=? ORDER BY date', u.school_id) });
});
route('POST', '/api/holidays', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const name = vStr(req.body.name, 100), date = vDate(req.body.date);
  if (!name || !date) return bad(res, 'name and date (YYYY-MM-DD) required');
  try { q.run('INSERT INTO holidays(school_id,name,date) VALUES(?,?,?)', u.school_id, name, date); }
  catch { return bad(res, 'Holiday already exists on that date'); }
  ok(res, { ok: true }, 201);
});
route('DELETE', '/api/holidays/:id', async (req, res, m) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  q.run('DELETE FROM holidays WHERE id=? AND school_id=?', m.id, u.school_id);
  ok(res, { ok: true });
});

// ---------- complaints ----------
route('GET', '/api/complaints', async (req, res) => {
  const u = needSchool(req, res, ALL_SCHOOL_ROLES); if (!u) return;
  const staffSide = ['admin', 'staff', 'teacher'].includes(u.role);
  const rows = staffSide ? q.all('SELECT * FROM complaints WHERE school_id=? ORDER BY id DESC LIMIT 200', u.school_id)
    : q.all('SELECT * FROM complaints WHERE school_id=? AND from_user_id=? ORDER BY id DESC LIMIT 200', u.school_id, u.id);
  ok(res, { complaints: rows });
});
route('POST', '/api/complaints', async (req, res) => {
  const u = needSchool(req, res, ALL_SCHOOL_ROLES); if (!u) return;
  const body = vStr(req.body.body, 1000); if (!body) return bad(res, 'Complaint text required');
  q.run('INSERT INTO complaints(school_id,from_user_id,from_name,category,body) VALUES(?,?,?,?,?)',
    u.school_id, u.id, u.name, vStr(req.body.category, 40) || 'general', body);
  audit(u.school_id, u.id, 'complaint_new', vStr(req.body.category, 40) || 'general');
  ok(res, { ok: true }, 201);
});
route('PATCH', '/api/complaints/:id', async (req, res, m) => {
  const u = needSchool(req, res, ['admin', 'staff']); if (!u) return;
  const c = q.get('SELECT * FROM complaints WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!c) return bad(res, 'Not found', 404);
  const st = ['open', 'in_progress', 'resolved', 'closed'].includes(req.body.status) ? req.body.status : c.status;
  q.run('UPDATE complaints SET status=?, response=?, responded_by=? WHERE id=?',
    st, req.body.response !== undefined ? vStr(req.body.response, 1000) : c.response, u.id, c.id);
  audit(u.school_id, u.id, 'complaint_update', `#${c.id} -> ${st}`);
  ok(res, { ok: true });
});

// ---------- bank accounts & budgets ----------
route('GET', '/api/bank-accounts', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const rows = q.all('SELECT * FROM bank_accounts WHERE school_id=?', u.school_id).map((a) => {
    const inflow = q.get("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE school_id=? AND method='bank' AND reversed=0", u.school_id).s;
    const outflow = q.get("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE school_id=? AND method='bank'", u.school_id).s;
    return Object.assign({}, a, { balance: a.opening_balance + inflow - outflow });
  });
  ok(res, { accounts: rows });
});
route('POST', '/api/bank-accounts', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const name = vStr(req.body.name, 80); if (!name) return bad(res, 'Account name required');
  q.run('INSERT INTO bank_accounts(school_id,name,iban,opening_balance) VALUES(?,?,?,?)',
    u.school_id, name, vStr(req.body.iban, 40), vMoney(req.body.opening_balance) ?? 0);
  ok(res, { ok: true }, 201);
});
route('GET', '/api/budgets', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  ok(res, { budgets: q.all('SELECT b.*, c.name category FROM budgets b JOIN expense_categories c ON c.id=b.category_id WHERE b.school_id=? ORDER BY b.month DESC', u.school_id) });
});
route('POST', '/api/budgets', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const catId = vInt(req.body.category_id), month = vStr(req.body.month, 7), amt = vMoney(req.body.amount);
  if (!catId || !/^\d{4}-\d{2}$/.test(month) || !amt || amt <= 0) return bad(res, 'category_id, month (YYYY-MM) and positive amount required');
  if (!q.get('SELECT id FROM expense_categories WHERE id=? AND school_id=?', catId, u.school_id)) return bad(res, 'Category not in your school');
  q.run(`INSERT INTO budgets(school_id,category_id,month,amount) VALUES(?,?,?,?)
    ON CONFLICT(school_id,category_id,month) DO UPDATE SET amount=excluded.amount`, u.school_id, catId, month, amt);
  ok(res, { ok: true }, 201);
});
route('GET', '/api/reports/budget', async (req, res) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const month = vStr((new URL(req.url, 'http://x')).searchParams.get('month'), 7) || monthNow();
  const rows = q.all(`SELECT b.*, c.name category,
    (SELECT COALESCE(SUM(e.amount),0) FROM expenses e WHERE e.school_id=b.school_id AND e.category_id=b.category_id AND substr(e.date,1,7)=b.month) actual
    FROM budgets b JOIN expense_categories c ON c.id=b.category_id WHERE b.school_id=? AND b.month=?`, u.school_id, month)
    .map((r) => Object.assign({}, r, { variance: r.amount - r.actual }));
  ok(res, { month, rows });
});

// ---------- promotion & session rollover ----------
route('POST', '/api/students/promote', async (req, res) => {
  const u = needSchool(req, res, WRITE_ROLES); if (!u) return;
  const toClass = q.get('SELECT id FROM classes WHERE id=? AND school_id=?', vInt(req.body.to_class_id), u.school_id);
  if (!toClass) return bad(res, 'Target class not in your school');
  const ids = [...new Set(Array.isArray(req.body.student_ids) ? req.body.student_ids.map((x) => vInt(x)).filter(Boolean) : [])].slice(0, 1000);
  if (!ids.length) return bad(res, 'student_ids required');
  const session = q.get('SELECT name FROM academic_sessions WHERE school_id=? AND is_current=1', u.school_id);
  const sNote = session ? 'session: ' + session.name : '';
  let moved = 0, skipped = 0;
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const id of ids) {
      const s = q.get("SELECT * FROM students WHERE id=? AND school_id=? AND status='active'", vInt(id), u.school_id);
      if (!s) { skipped++; continue; }
      q.run('UPDATE students SET class_id=?, section_id=NULL WHERE id=?', toClass.id, s.id);
      q.run('INSERT INTO student_class_history(school_id,student_id,from_class_id,to_class_id,action,note,by_user) VALUES(?,?,?,?,?,?,?)',
        u.school_id, s.id, s.class_id, toClass.id, 'promoted', sNote, u.id);
      moved++;
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); return bad(res, 'Promotion failed: ' + e.message, 500); }
  audit(u.school_id, u.id, 'promote', `${moved} students -> class #${toClass.id}`);
  ok(res, { moved, skipped });
});
route('POST', '/api/sessions/rollover', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const classes = q.all('SELECT * FROM classes WHERE school_id=? ORDER BY level', u.school_id);
  const levels = classes.map((c) => c.level || 0);
  if (new Set(levels).size !== levels.length) return bad(res, 'Duplicate class levels - fix class levels before rollover');
  const nextOf = {}; classes.forEach((c) => { const nx = classes.find((x) => x.level === (c.level || 0) + 1); nextOf[c.id] = nx ? nx.id : null; });
  const maxLevel = levels.length ? Math.max(...levels) : 0;
  // snapshot active students with their ORIGINAL class before any update
  const snap = q.all("SELECT id, class_id FROM students WHERE school_id=? AND status='active' AND class_id IS NOT NULL", u.school_id);
  const moves = snap.map((s) => ({ id: s.id, from: s.class_id, to: nextOf[s.class_id] || null }))
    .filter((mv) => mv.from !== undefined && classes.some((c) => c.id === mv.from));
  const toPromote = moves.filter((mv) => mv.to !== null);
  const toGraduate = moves.filter((mv) => mv.to === null && (levels.find((l, i) => classes[i].id === mv.from) || 0) >= maxLevel);
  const curSession = q.get('SELECT name FROM academic_sessions WHERE school_id=? AND is_current=1', u.school_id);
  const sessKey = curSession ? curSession.name : '(no-session)';
  const already = q.get('SELECT at FROM session_rollovers WHERE school_id=? AND session_name=?', u.school_id, sessKey);
  if (!req.body.confirm) {
    return ok(res, { preview: true, already_executed: !!already, would_promote: already ? 0 : toPromote.length, would_graduate: already ? 0 : toGraduate.length,
      note: already ? `Rollover already executed for ${sessKey} at ${already.at} - create a new current session first.` : 'Re-POST with {"confirm": true} to execute. Top-level students graduate.' });
  }
  if (already) return bad(res, `Rollover already executed for session ${sessKey} at ${already.at}. Create a new current academic session before the next rollover.`, 409);
  const session = curSession;
  const sNote = session ? 'session: ' + session.name : '';
  let promoted = 0, graduated = 0;
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const mv of toPromote) {
      const r = q.run("UPDATE students SET class_id=?, section_id=NULL WHERE id=? AND class_id=? AND status='active'", mv.to, mv.id, mv.from);
      if (r.changes) { q.run('INSERT INTO student_class_history(school_id,student_id,from_class_id,to_class_id,action,note,by_user) VALUES(?,?,?,?,?,?,?)', u.school_id, mv.id, mv.from, mv.to, 'rollover', sNote, u.id); promoted++; }
    }
    for (const mv of toGraduate) {
      const r = q.run("UPDATE students SET status='graduated' WHERE id=? AND class_id=? AND status='active'", mv.id, mv.from);
      if (r.changes) { q.run('INSERT INTO student_class_history(school_id,student_id,from_class_id,to_class_id,action,note,by_user) VALUES(?,?,?,?,?,?,?)', u.school_id, mv.id, mv.from, null, 'graduated', sNote, u.id); graduated++; }
    }
    q.run('INSERT INTO session_rollovers(school_id,session_name) VALUES(?,?)', u.school_id, sessKey);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); return bad(res, 'Rollover failed: ' + e.message, 500); }
  audit(u.school_id, u.id, 'session_rollover', `${promoted} promoted, ${graduated} graduated`);
  ok(res, { promoted, graduated });
});

// ---------- data export / backup ----------
route('GET', '/api/export', async (req, res) => {
  const u = needSchool(req, res, ['admin']); if (!u) return;
  const sid = u.school_id;
  const dump = {
    exported_at: new Date().toISOString(), school: q.get('SELECT * FROM schools WHERE id=?', sid),
    classes: q.all('SELECT * FROM classes WHERE school_id=?', sid),
    sections: q.all('SELECT s.* FROM sections s JOIN classes c ON c.id=s.class_id WHERE c.school_id=?', sid),
    students: q.all('SELECT * FROM students WHERE school_id=?', sid),
    employees: q.all('SELECT * FROM employees WHERE school_id=?', sid),
    student_attendance: q.all('SELECT * FROM student_attendance WHERE school_id=?', sid),
    employee_attendance: q.all('SELECT * FROM employee_attendance WHERE school_id=?', sid),
    fee_structures: q.all('SELECT * FROM fee_structures WHERE school_id=?', sid),
    fee_vouchers: q.all('SELECT * FROM fee_vouchers WHERE school_id=?', sid),
    payments: q.all('SELECT * FROM payments WHERE school_id=?', sid),
    expenses: q.all('SELECT * FROM expenses WHERE school_id=?', sid),
    salary_payments: q.all('SELECT * FROM salary_payments WHERE school_id=?', sid),
    exams: q.all('SELECT * FROM exams WHERE school_id=?', sid),
    marks: q.all('SELECT * FROM marks WHERE school_id=?', sid),
  };
  audit(sid, u.id, 'data_export', 'full JSON export');
  res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Disposition': `attachment; filename="school-export-${today()}.json"` });
  res.end(JSON.stringify(dump, null, 1));
});

// ---------- minimal PDF generator (Helvetica, A4) ----------
function pdfEscape(s) { return String(s).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)').replace(/[^\x20-\x7E]/g, '?'); }
function makePdf(lines) {
  // lines: [{text, size, bold, gap}] rendered top-down
  let y = 800;
  let content = '';
  for (const ln of lines) {
    const size = ln.size || 11;
    const font = ln.bold ? 'F2' : 'F1';
    y -= ln.gap != null ? ln.gap : (size + 6);
    content += `BT /${font} ${size} Tf 50 ${y} Td (${pdfEscape(ln.text)}) Tj ET\n`;
    if (ln.rule) { content += `50 ${y - 4} m 545 ${y - 4} l S\n`; }
  }
  const objects = [];
  objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
  objects[2] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
  objects[3] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>';
  objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
  objects[5] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';
  objects[6] = `<< /Length ${content.length} >>\nstream\n${content}endstream`;
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  for (let i = 1; i <= 6; i++) { offsets[i] = pdf.length; pdf += `${i} 0 obj\n${objects[i]}\nendobj\n`; }
  const xref = pdf.length;
  pdf += `xref\n0 7\n0000000000 65535 f \n`;
  for (let i = 1; i <= 6; i++) pdf += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  pdf += `trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(pdf, 'latin1');
}
route('GET', '/api/receipts/:id.pdf', async (req, res, m) => {
  const u = needSchool(req, res, FEE_ROLES); if (!u) return;
  const p = q.get('SELECT * FROM payments WHERE id=? AND school_id=?', m.id, u.school_id);
  if (!p) return bad(res, 'Not found', 404);
  const v = q.get('SELECT * FROM fee_vouchers WHERE id=?', p.voucher_id);
  const stu = q.get('SELECT s.*, c.name class_name, sec.name section_name FROM students s LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id WHERE s.id=?', v.student_id);
  const school = q.get('SELECT * FROM schools WHERE id=?', u.school_id);
  const items = q.all('SELECT name,amount FROM voucher_items WHERE voucher_id=?', v.id);
  const recv = p.received_by ? q.get('SELECT name FROM users WHERE id=?', p.received_by) : null;
  const lines = [
    { text: school.name, size: 18, bold: true, gap: 0 },
    { text: school.address || '', size: 10, gap: 16 },
    { text: school.phone || '', size: 10, gap: 14 },
    { text: 'FEE RECEIPT', size: 14, bold: true, gap: 30, rule: true },
    { text: `Receipt No: R-${p.id}        Date: ${p.date}        Method: ${p.method.toUpperCase()}`, size: 11, gap: 26 },
    { text: `Student: ${stu.name}    Adm No: ${stu.admission_no}    Class: ${stu.class_name || '-'} ${stu.section_name || ''}    Roll: ${stu.roll_no || '-'}`, size: 11, gap: 18 },
    { text: `Fee Month: ${v.month}    Voucher #${v.id}    Due date: ${v.due_date}`, size: 11, gap: 18 },
    { text: '--------------------------------------------------------------', gap: 20 },
    { text: 'Voucher items:', bold: true, gap: 16 },
  ];
  items.forEach((i) => lines.push({ text: `   ${i.name}  ................  Rs ${rp(i.amount)}`, size: 10, gap: 14 }));
  const paidTotal = q.get('SELECT COALESCE(SUM(amount),0) s FROM payments WHERE voucher_id=? AND reversed=0', v.id).s;
  lines.push({ text: '--------------------------------------------------------------', gap: 18 });
  lines.push({ text: `Voucher total: Rs ${rp(v.total)}    Paid to date: Rs ${rp(paidTotal)}    Balance: Rs ${rp(v.total - paidTotal)}`, size: 11, gap: 18 });
  lines.push({ text: `THIS PAYMENT: Rs ${rp(p.amount)}${p.reference ? '    Ref: ' + p.reference : ''}${p.payer ? '    Payer: ' + p.payer : ''}`, size: 12, bold: true, gap: 22 });
  if (p.reversed) lines.push({ text: `** REVERSED: ${p.reversal_reason} **`, size: 11, bold: true, gap: 18 });
  lines.push({ text: `Received by: ${recv ? recv.name : '-'}${p.note ? '    Note: ' + p.note : ''}`, size: 10, gap: 22 });
  lines.push({ text: 'Signature: ____________________', size: 11, gap: 40 });
  lines.push({ text: 'Generated by SchoolHub - Powered by Alpha Blue Digital - alphablue.digital', size: 8, gap: 30 });
  const pdfBuf = makePdf(lines);
  res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="receipt-${p.id}.pdf"` });
  res.end(pdfBuf);
});
route('GET', '/api/report-cards/:examId/:studentId.pdf', async (req, res, m) => {
  const u = needSchool(req, res); if (!u) return;
  const exam = q.get('SELECT * FROM exams WHERE id=? AND school_id=?', m.examId, u.school_id);
  const stu = q.get('SELECT s.*, c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=? AND s.school_id=?', m.studentId, u.school_id);
  if (!exam || !stu) return bad(res, 'Not found', 404);
  const school = q.get('SELECT * FROM schools WHERE id=?', u.school_id);
  const subjects = q.all('SELECT * FROM exam_subjects WHERE exam_id=?', exam.id).map((sub) => {
    const mk = q.get('SELECT * FROM marks WHERE exam_subject_id=? AND student_id=?', sub.id, stu.id);
    return { subject: sub.subject, max_marks: sub.max_marks, obtained: mk ? mk.obtained : null, absent: mk ? mk.absent : 0, marks_status: sub.marks_status };
  });
  const tMax = subjects.reduce((t, s) => t + s.max_marks, 0);
  const tObt = subjects.reduce((t, s) => t + (s.absent ? 0 : (s.obtained || 0)), 0);
  const pct = tMax ? Math.round(tObt * 1000 / tMax) / 10 : null;
  const lines = [
    { text: school.name, size: 18, bold: true, gap: 0 },
    { text: `${exam.name} - Report Card`, size: 14, bold: true, gap: 28, rule: true },
    { text: `Student: ${stu.name}    Adm No: ${stu.admission_no}    Class: ${stu.class_name || '-'}    Roll: ${stu.roll_no || '-'}`, size: 11, gap: 24 },
    { text: '--------------------------------------------------------------', gap: 20 },
    { text: 'Subject                          Max     Obtained     Remarks', bold: true, gap: 16 },
  ];
  subjects.forEach((s) => {
    const rem = s.absent ? 'Absent' : (s.obtained == null ? '-' : (s.obtained >= s.max_marks * 0.4 ? 'Pass' : 'Fail'));
    lines.push({ text: `${s.subject.padEnd(30).slice(0, 30)}  ${String(s.max_marks).padStart(4)}     ${s.absent ? 'A' : (s.obtained == null ? '-' : s.obtained)}         ${rem}`, size: 10, gap: 15 });
  });
  lines.push({ text: '--------------------------------------------------------------', gap: 18 });
  lines.push({ text: `Total: ${tObt} / ${tMax}    Percentage: ${pct == null ? '-' : pct + '%'}    Grade: ${pct == null ? '-' : gradeFor(pct)}`, size: 12, bold: true, gap: 20 });
  lines.push({ text: `Date: ${today()}`, size: 10, gap: 24 });
  lines.push({ text: "Principal's signature: ____________________", size: 11, gap: 40 });
  lines.push({ text: 'Generated by SchoolHub - Powered by Alpha Blue Digital - alphablue.digital', size: 8, gap: 30 });
  const pdfBuf = makePdf(lines);
  res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="report-card-${stu.admission_no}.pdf"` });
  res.end(pdfBuf);
});

// ---------- daily file backup ----------
async function fileBackup() {
  try {
    const src = path.join(DATA_DIR, 'school.db');
    if (!fs.existsSync(src)) return;
    const dst = path.join(DATA_DIR, 'backups', `school-${new Date().toISOString().slice(0, 10)}.db`);
    const tmp = dst + '.tmp-' + process.pid + '-' + Date.now();
    db.exec("VACUUM INTO '" + tmp.replace(/'/g, "''") + "'");   // consistent copy inside one sqlite transaction (no torn WAL copy)
    fs.chmodSync(tmp, 0o600);
    const check = new DatabaseSync(tmp, { readonly: true });
    const ic = check.prepare('PRAGMA integrity_check').get();
    check.close();
    if (!ic || ic.integrity_check !== 'ok') { fs.unlinkSync(tmp); throw new Error('backup integrity_check failed'); }
    fs.renameSync(tmp, dst);   // atomic replace - works when same-day backup already exists
    fs.chmodSync(dst, 0o600);
    // mirror uploaded bytes so a database restore never leaves file_metadata pointing at missing blobs
    const mirror = path.join(DATA_DIR, 'backups', 'uploads-mirror');
    fs.mkdirSync(mirror, { recursive: true });
    try {
      for (const f of fs.readdirSync(UPLOAD_DIR)) {
        const to = path.join(mirror, f);
        if (!fs.existsSync(to)) { fs.copyFileSync(path.join(UPLOAD_DIR, f), to); fs.chmodSync(to, 0o600); }
      }
      // retention: a mirror byte is pruned only when no live row AND no retained daily backup references it.
      // if ANY backup cannot be opened/queried, nothing is pruned this run (unknown state => keep).
      const referenced = new Set(q.all('SELECT sha256 h FROM file_metadata').map((r) => r.h));
      let unknown = false;
      const retainedDbs = fs.readdirSync(path.join(DATA_DIR, 'backups')).filter((x) => /^school-\d{4}-\d{2}-\d{2}\.db$/.test(x));
      for (const f of retainedDbs) {
        try {
          const bk = new DatabaseSync(path.join(DATA_DIR, 'backups', f), { readonly: true });
          const has = bk.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='file_metadata'").get();
          if (has) bk.prepare('SELECT sha256 FROM file_metadata').all().forEach((r) => referenced.add(r.sha256));
          bk.close();
        } catch { unknown = true; }
      }
      if (!unknown) {
        for (const f of fs.readdirSync(mirror)) {
          if (!referenced.has(f)) { fs.unlinkSync(path.join(mirror, f)); }
        }
      }
    } catch (e) { console.error('[schoolhub] uploads mirror failed:', e.message); }
    const files = fs.readdirSync(path.join(DATA_DIR, 'backups')).filter((f) => /^school-\d{4}-\d{2}-\d{2}\.db$/.test(f)).sort();
    while (files.length > 30) { fs.unlinkSync(path.join(DATA_DIR, 'backups', files.shift())); }
    console.log('[schoolhub] backup written:', dst);
  } catch (e) { console.error('[schoolhub] backup failed:', e.message); }
}
try { fs.readdirSync(path.join(DATA_DIR, 'backups')).filter((f) => f.includes('.tmp-')).forEach((f) => fs.unlinkSync(path.join(DATA_DIR, 'backups', f))); } catch {}
setInterval(fileBackup, 24 * 3600 * 1000).unref();
setTimeout(fileBackup, 5000).unref();

// ---------- dispatcher ----------

// ---------- SCC connector (Subscription Control Center contract v1.1 freeze candidate, updated spec 16:53) ----------
// Isolated synthetic integration. Enabled only when SCC_KEY_ID + SCC_SECRET are set in env (secret via vault flow, never chat/forms/DB/logs).
const SCC_KEY_ID = process.env.SCC_KEY_ID || '';
const SCC_SECRET = process.env.SCC_SECRET || '';
const SCC_SKEW_SEC = 300, SCC_NONCE_TTL_SEC = 900;
try { db.exec('CREATE TABLE IF NOT EXISTS scc_nonces(key_id TEXT NOT NULL, nonce TEXT NOT NULL, expires_at INTEGER NOT NULL, PRIMARY KEY(key_id,nonce))'); } catch {}
try { db.exec("CREATE TABLE IF NOT EXISTS scc_requests(request_id TEXT PRIMARY KEY, payload_hash TEXT NOT NULL, status INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')))"); } catch {}
try { db.exec('CREATE TABLE IF NOT EXISTS scc_meta(k TEXT PRIMARY KEY, v TEXT NOT NULL)'); } catch {}
try { db.exec("ALTER TABLE schools ADD COLUMN scc_ref TEXT"); } catch {}
try { db.exec("ALTER TABLE schools ADD COLUMN scc_state_changed_at TEXT DEFAULT ''"); } catch {}
try { db.exec('CREATE UNIQUE INDEX IF NOT EXISTS schools_scc_ref_uq ON schools(scc_ref)'); } catch {}
// notBefore floor: set at first boot (or after any restore that lost the store) so pre-floor signed requests are rejected.
let SCC_NOT_BEFORE = 0;
try {
  const row = q.get("SELECT v FROM scc_meta WHERE k='scc_not_before'");
  if (row) SCC_NOT_BEFORE = Number(row.v) || 0;
  else { SCC_NOT_BEFORE = Math.floor(Date.now() / 1000); q.run("INSERT INTO scc_meta(k,v) VALUES('scc_not_before',?)", String(SCC_NOT_BEFORE)); }
} catch (e) { console.error('[schoolhub] SCC meta store unreadable; connector fail-closed', e.message); SCC_NOT_BEFORE = Number.MAX_SAFE_INTEGER; }

const sccEnc = (s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
function sccCanonicalQuery(search) {
  const p = new URLSearchParams(search || '');
  return [...p.entries()].map(([k, v]) => [sccEnc(k), sccEnc(v)]).sort((a, b) => (a[0] === b[0] ? (a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0) : a[0] < b[0] ? -1 : 1)).map(([k, v]) => k + '=' + v).join('&');
}
const sccIso = (d) => new Date(d).toISOString(); // instant -> ISO Z ms
const sccSqlIso = (s) => s ? new Date(String(s).replace(' ', 'T') + 'Z').toISOString() : null; // sqlite UTC 'YYYY-MM-DD HH:MM:SS' -> ISO Z
function sccSend(res, status, obj, extra) {
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json' }, SEC_HEADERS, extra || {}));
  res.end(JSON.stringify(obj));
}
function sccErr(res, status, code, message) { sccSend(res, status, { error: code, message }); }

function sccVerify(req, rawPath, rawQuery) {
  const h = (n) => req.headers[n];
  const keyId = h('x-scc-key-id'), ts = h('x-scc-timestamp'), nonce = h('x-scc-nonce'), sig = h('x-scc-signature');
  if (!keyId || !ts || !nonce || !sig) return [401, 'missing_auth', 'Missing X-SCC-* headers'];
  if (keyId !== SCC_KEY_ID) return [401, 'unknown_key', 'Unknown key id'];
  if (!rawPath.startsWith('/_scc/v1')) return [401, 'bad_path', 'Path outside /_scc/v1'];
  const now = Math.floor(Date.now() / 1000);
  if (!/^\d{9,12}$/.test(String(ts)) || Math.abs(now - Number(ts)) > SCC_SKEW_SEC) return [401, 'stale_timestamp', 'Timestamp outside 300s window'];
  if (!/^[0-9a-f]{32,64}$/.test(String(nonce))) return [401, 'bad_nonce', 'Nonce must be 32-64 lowercase hex chars'];
  const bodyHash = crypto.createHash('sha256').update(req.rawBody || '').digest('hex');
  const canon = [String(req.method).toUpperCase(), rawPath, sccCanonicalQuery(rawQuery), String(ts), String(nonce), bodyHash].join('\n');
  const want = crypto.createHmac('sha256', SCC_SECRET).update(canon).digest('hex');
  const a = Buffer.from(want), b = Buffer.from(String(sig));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return [401, 'bad_signature', 'Signature mismatch'];
  if (Number(ts) < SCC_NOT_BEFORE) return [401, 'before_store_floor', 'Timestamp before nonce-store floor'];
  try {
    q.run('DELETE FROM scc_nonces WHERE expires_at < ?', now);
    const r = q.run('INSERT OR IGNORE INTO scc_nonces(key_id,nonce,expires_at) VALUES(?,?,?)', keyId, nonce, now + SCC_NONCE_TTL_SEC);
    if (r.changes === 0) return [401, 'nonce_replayed', 'Nonce already used'];
  } catch (e) { return [503, 'nonce_store_unavailable', 'Nonce store failure']; }
  return null;
}

function sccFindByRef(ref) { return q.get('SELECT * FROM schools WHERE scc_ref=?', String(ref)); }
function sccFindLocal(localId) {
  const v = String(localId);
  let s = null;
  if (/^\d+$/.test(v)) s = q.get('SELECT * FROM schools WHERE id=?', Number(v));
  if (!s) s = q.get('SELECT * FROM schools WHERE code=?', v);
  return s;
}
function sccSub(s) { return q.get('SELECT * FROM subscriptions WHERE school_id=? ORDER BY id DESC LIMIT 1', s.id); }
function sccDates(s, sub) {
  const vu = (sub && sub.renewal_date) || s.renewal_date || '';
  const gd = sub ? (sub.grace_days || 0) : 0;
  return { vu, gd };
}
function sccExpired(s, sub) { const { vu, gd } = sccDates(s, sub); return !!(vu && today() > addDays(vu, gd)); } // date-granular: valid through END of UTC day, never early
function sccState(s, sub) { if (s.status === 'suspended') return 'suspended'; return sccExpired(s, sub) ? 'expired' : 'active'; } // trial reads active; suspended > expired > active
function sccView(ref, s) {
  if (!s) return { external_ref: String(ref), state: 'absent', state_changed_at: null, valid_until: null, grace_until: null };
  const sub = sccSub(s);
  const { vu, gd } = sccDates(s, sub);
  return {
    external_ref: String(ref),
    state: sccState(s, sub),
    state_changed_at: sccSqlIso(s.scc_state_changed_at) || sccSqlIso(s.created_at),
    valid_until: vu ? vu + 'T00:00:00.000Z' : null,
    grace_until: vu ? addDays(vu, gd) + 'T00:00:00.000Z' : null,
  };
}
function sccIdem(b, payloadHash) {
  const rid = b.request_id;
  if (typeof rid !== 'string' || !/^[0-9a-fA-F-]{8,64}$/.test(rid)) return { err: [400, 'request_id_required', 'request_id (uuid) required in body'] };
  const row = q.get('SELECT * FROM scc_requests WHERE request_id=?', rid);
  if (!row) return { rid };
  if (row.payload_hash !== payloadHash) return { err: [409, 'request_id_conflict', 'request_id reused with a different payload'] };
  return { replay: row };
}
function sccIdemStore(requestId, payloadHash, status, body) {
  try { q.run('INSERT INTO scc_requests(request_id,payload_hash,status,body) VALUES(?,?,?,?)', requestId, payloadHash, status, body); } catch {}
}
function sccParseInstantMs(v) { // ISO instant or bare date -> ms epoch (UTC), else null
  if (typeof v !== 'string' || !v) return null;
  const t = Date.parse(v);
  return Number.isNaN(t) ? null : t;
}

async function sccHandle(req, res) {
  if (!SCC_KEY_ID || !SCC_SECRET) return bad(res, 'Not found', 404); // disabled -> 404, fail closed
  const qm = req.url.indexOf('?');
  const rawPath = qm === -1 ? req.url : req.url.slice(0, qm);
  const rawQuery = qm === -1 ? '' : req.url.slice(qm + 1);
  req.rawBody = '';
  if (req.method === 'PUT' || req.method === 'POST') {
    const b = await readBody(req);
    if (b && b.__tooBig) return sccErr(res, 413, 'bad_json', 'Body too large');
    if (b === null) return sccErr(res, 400, 'bad_json', 'Invalid JSON body');
    req.body = b;
  } else req.body = {};
  const verr = sccVerify(req, rawPath, rawQuery);
  if (verr) return sccErr(res, verr[0], verr[1], verr[2]);
  const tail = rawPath.split('/').filter(Boolean).slice(2); // after _scc/v1
  const bodyHash = crypto.createHash('sha256').update(req.rawBody || '').digest('hex');

  if (req.method === 'GET' && tail.length === 1 && tail[0] === 'health')
    return sccSend(res, 200, { ok: true, product: 'schoolhub', version: 'r8', contract: 'scc-1.1' });

  if (req.method === 'GET' && tail.length === 1 && tail[0] === 'accounts') {
    const cur = Number((new URLSearchParams(rawQuery)).get('cursor') || 0) || 0;
    const rows = q.all('SELECT * FROM schools WHERE scc_ref IS NOT NULL AND id > ? ORDER BY id LIMIT 101', cur);
    const page = rows.slice(0, 100);
    return sccSend(res, 200, { accounts: page.map((s) => sccView(s.scc_ref, s)), next_cursor: rows.length > 100 ? String(page[page.length - 1].id) : null });
  }

  if (tail.length >= 2 && tail.length <= 3 && tail[0] === 'accounts') {
    let ref;
    try { ref = decodeURIComponent(tail[1]); } catch { return sccErr(res, 400, 'bad_path', 'Malformed account ref'); }
    if (!/^[A-Za-z0-9_.-]{1,64}$/.test(ref)) return sccErr(res, 400, 'bad_path', 'external_ref must match [A-Za-z0-9_.-]{1,64}');
    const action = tail.length === 3 ? tail[2] : null;
    if (!action && req.method === 'GET') return sccSend(res, 200, sccView(ref, sccFindByRef(ref)));

    if (!action && req.method === 'PUT') {
      const b = req.body || {};
      const idem = sccIdem(b, bodyHash);
      if (idem.err) return sccErr(res, idem.err[0], idem.err[1], idem.err[2]);
      if (idem.replay) return sccSend(res, idem.replay.status, JSON.parse(idem.replay.body), { 'Idempotent-Replay': 'true' });
      const name = vStr(b.name, 120);
      const vuMs = sccParseInstantMs(b.valid_until);
      const guMs = sccParseInstantMs(b.grace_until);
      if ((b.valid_until && vuMs === null) || (b.grace_until && guMs === null)) return sccErr(res, 400, 'bad_json', 'valid_until/grace_until must be ISO-8601 instants');
      if (guMs !== null && vuMs === null) return sccErr(res, 400, 'bad_json', 'grace_until requires valid_until');
      const vuD = vuMs === null ? null : new Date(vuMs).toISOString().slice(0, 10); // stored as UTC date; valid through END of that day (never expires early)
      let graceDays = null;
      if (vuMs !== null && guMs !== null) {
        graceDays = Math.ceil((guMs - vuMs) / 86400000); // per contract: ceil on the full instants
        if (graceDays < 0) return sccErr(res, 400, 'bad_json', 'grace_until must be >= valid_until');
      }
      let s = sccFindByRef(ref), status = 200;
      let local = null;
      if (b.local_id !== undefined && b.local_id !== null && String(b.local_id) !== '') {
        local = sccFindLocal(b.local_id);
        if (!local) return sccErr(res, 404, 'unknown_account', 'local_id matches no tenant');
        if (local.scc_ref && local.scc_ref !== ref) return sccErr(res, 409, 'ref_conflict', 'Tenant already bound to a different external_ref');
      }
      if (s && local && s.id !== local.id) return sccErr(res, 409, 'ref_conflict', 'external_ref already bound to a different tenant');
      if (!s) {
        if (local) {
          q.run('UPDATE schools SET scc_ref=? WHERE id=?', ref, local.id);
          s = q.get('SELECT * FROM schools WHERE id=?', local.id);
          audit(s.id, null, 'scc_bind', 'ref=' + ref + ' local_id=' + String(b.local_id));
        } else {
          if (!name) return sccErr(res, 400, 'bad_json', 'name required to create an account shell');
          let code = 'scc-' + String(ref).toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 34);
          if (q.get('SELECT id FROM schools WHERE code=?', code)) code = code.slice(0, 34) + '-' + Date.now().toString(36);
          // Tenant SHELL per contract: no users, no passwords, no logins, no data.
          const r = q.run("INSERT INTO schools(name,code,status,renewal_date,scc_ref,scc_state_changed_at) VALUES(?,?,'trial','',?,datetime('now'))", name, code, ref);
          s = q.get('SELECT * FROM schools WHERE id=?', r.lastInsertRowid);
          audit(s.id, null, 'scc_shell_create', 'ref=' + ref + ' code=' + code);
          status = 201;
        }
      }
      if (name && name !== s.name) { q.run('UPDATE schools SET name=? WHERE id=?', name, s.id); }
      if (vuD) {
        q.run('UPDATE schools SET renewal_date=? WHERE id=?', vuD, s.id);
        const sub = sccSub(s);
        const gd = graceDays !== null ? graceDays : (sub ? (sub.grace_days || 0) : 0);
        if (sub) q.run('UPDATE subscriptions SET renewal_date=?, grace_days=? WHERE id=?', vuD, gd, sub.id);
        else q.run("INSERT INTO subscriptions(school_id,start_date,renewal_date,amount,status,note,grace_days) VALUES(?,date('now'),?,0,'active','SCC entitlement',?)", s.id, vuD, gd);
      }
      s = q.get('SELECT * FROM schools WHERE id=?', s.id);
      const out = sccView(ref, s);
      sccIdemStore(idem.rid, bodyHash, status, JSON.stringify(out));
      return sccSend(res, status, out);
    }

    if (action && req.method === 'POST' && ['suspend', 'restore', 'revoke-sessions'].includes(action)) {
      const b = req.body || {};
      const idem = sccIdem(b, bodyHash);
      if (idem.err) return sccErr(res, idem.err[0], idem.err[1], idem.err[2]);
      if (idem.replay) return sccSend(res, idem.replay.status, JSON.parse(idem.replay.body), { 'Idempotent-Replay': 'true' });
      const s = sccFindByRef(ref);
      if (!s) return sccErr(res, 404, 'unknown_account', 'No account bound to this external_ref');
      const actor = vStr(b.actor, 80), reason = vStr(b.reason, 200);
      let out;
      if (action === 'suspend') {
        q.run("UPDATE schools SET status='suspended', scc_state_changed_at=datetime('now') WHERE id=?", s.id);
        audit(s.id, null, 'scc_suspend', 'actor=' + actor + ' reason=' + reason);
        out = { state: 'suspended' };
      } else if (action === 'restore') {
        if (sccExpired(s, sccSub(s))) return sccErr(res, 409, 'entitlement_expired', 'valid_until (and grace) has passed; renew via PUT before restore');
        q.run("UPDATE schools SET status='active', scc_state_changed_at=datetime('now') WHERE id=?", s.id);
        audit(s.id, null, 'scc_restore', 'actor=' + actor);
        out = { state: 'active' };
      } else {
        const n = q.run('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE school_id=?)', s.id).changes;
        audit(s.id, null, 'scc_revoke_sessions', 'actor=' + actor + ' revoked=' + n);
        out = { revoked: n };
      }
      sccIdemStore(idem.rid, bodyHash, 200, JSON.stringify(out));
      return sccSend(res, 200, out);
    }
  }
  return sccErr(res, 404, 'bad_path', 'Unknown endpoint');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/_scc/v1')) return sccHandle(req, res);
  if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.rx.exec(url.pathname);
    if (!m) continue;
    const match = {};
    try { r.keys.forEach((k, i) => { match[k] = decodeURIComponent(m[i + 1]); }); }
    catch { return bad(res, 'Malformed URL', 400); }
    let body = {};
    if (req.method === 'POST' || req.method === 'PATCH' || req.method === 'PUT') {
      if (!(req.headers['content-type'] || '').startsWith('application/json')) return bad(res, 'Content-Type must be application/json', 415);
      body = await readBody(req);
      if (body && body.__tooBig) return bad(res, 'Payload too large (max ~6MB)', 413);
      if (body === null) return bad(res, 'Invalid JSON body');
    }
    req.body = body;
    try { return await r.handler(req, res, match, body, url); }
    catch (e) { console.error('[schoolhub] route error', url.pathname, e); return bad(res, 'Server error', 500); }
  }
  bad(res, 'Not found', 404);
});
process.on('uncaughtException', (e) => { console.error('[schoolhub] uncaughtException', e); });
process.on('unhandledRejection', (e) => { console.error('[schoolhub] unhandledRejection', e); });
server.listen(PORT, () => console.log(`[schoolhub] listening on :${PORT}, data at ${DATA_DIR}`));
