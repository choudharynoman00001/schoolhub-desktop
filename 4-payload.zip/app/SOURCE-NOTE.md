# app/ snapshot

Sanitized runtime snapshot of the SchoolHub app (server.js, package.json, public/)
synced from the private source repo at installer build time. Tests, docs,
blueprints, customer data and secrets are NEVER included here. Update this
folder when cutting a new installer release.
