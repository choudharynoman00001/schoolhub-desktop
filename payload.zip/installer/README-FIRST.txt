SchoolHub Manager - pehli dafa chalane ka tareeqa
=================================================

1. Desktop ya Start Menu se "SchoolHub Manager" kholein.
   SchoolHub apni alag app window mein khulega - address bar ya tabs nahi
   (Edge/Chrome ka app mode; app phir bhi isi computer par chalti hai,
   127.0.0.1 = aapka apna PC). Agar PC par Edge/Chrome na ho to aam
   browser window mein khulega - kaam dono mein same hai.

2. Pehli dafa login:
   - Username aur password is file mein hain:
     %LOCALAPPDATA%\SchoolHub\data\bootstrap-superadmin.txt
     (File Explorer mein upar wala path paste kar dein)
   - Login karte hi app naya password mangegi. Apna password set kar dein.
   - Naya password set hone ke baad woh bootstrap file khud delete ho jati hai.

3. Band karne ke liye Start Menu > SchoolHub Manager > "Stop SchoolHub".
   Dobara chalane ke liye phir "SchoolHub Manager" shortcut - purana data
   (schools, students, fees) waise ka waisa milta hai.

4. Uninstall karne par data folder delete NAHI hota. Agar sab hatana ho to
   %LOCALAPPDATA%\SchoolHub folder khud delete kar dein.

Note: Installer digitally signed nahi hai (certificate mehnga hota hai), is liye
Windows "Unknown publisher" ya SmartScreen warning dikha sakta hai -
"More info" > "Run anyway" se aage barhein.

Developed by Chaudhry Noman - Powered by Alpha Blue Digital
https://alphablue.digital - All Rights Reserved 2026
