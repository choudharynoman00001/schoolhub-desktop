' SchoolHub Manager launcher - starts the local server if needed and opens the app.
' Opens a dedicated app window via Edge/Chrome --app mode when a Chromium browser is
' installed (browser-engine app window, not a native app); falls back to the default
' browser window otherwise. SCHOOLHUB_NO_BROWSER=1: automation mode, opens nothing.
' SCHOOLHUB_LAUNCH_LOG_ONLY=1: records the chosen launch command to
' data\last-launch.txt and opens nothing (CI proof of the selection logic).
Option Explicit
Dim sh, base, url, ok, i
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\SchoolHub"
url = "http://127.0.0.1:8420/"
ok = False
For i = 1 To 40
  If HealthOk(url) Then ok = True : Exit For
  If i = 1 Then StartServer base
  WScript.Sleep 1000
Next
If ok Then
  If sh.ExpandEnvironmentStrings("%SCHOOLHUB_NO_BROWSER%") = "1" Then
    ' automation mode: never open a window
  Else
    OpenApp url
  End If
Else
  If sh.ExpandEnvironmentStrings("%SCHOOLHUB_NO_BROWSER%") = "1" Then
    WScript.Echo "SchoolHub server failed to start within wait window (automation mode, no dialog)"
    WScript.Quit 1
  Else
    MsgBox "SchoolHub abhi start nahi ho saka. Dobara koshish karein; agar masla rahe to Alpha Blue Digital se rabta karein.", 48, "SchoolHub Manager"
  End If
End If

Function HealthOk(u)
  Dim http
  On Error Resume Next
  Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  http.Open "GET", u & "api/health", False
  http.setTimeouts 2000, 2000, 2000, 2000
  http.Send
  HealthOk = (Err.Number = 0 And http.Status = 200)
  Err.Clear
  On Error GoTo 0
End Function

Sub StartServer(b)
  Dim cmd
  If Not CreateObject("Scripting.FileSystemObject").FolderExists(b & "\data") Then CreateObject("Scripting.FileSystemObject").CreateFolder(b & "\data")
  cmd = "cmd /c cd /d """ & b & "\app"" && set PORT=8420&& set DATA_DIR=" & b & "\data&& """ & b & "\runtime\node.exe"" """ & b & "\app\server.js"" > """ & b & "\data\server.log"" 2>&1"
  sh.Run cmd, 0, False
End Sub

Sub OpenApp(u)
  Dim b, cmdLine, mode
  b = FindChromium()
  If b <> "" Then
    cmdLine = """" & b & """ --app=" & u
    mode = "app-window (Chromium --app; browser engine, no tabs/address bar)"
  Else
    cmdLine = "explorer.exe """ & u & """"
    mode = "fallback default-browser window (no Edge/Chrome found)"
  End If
  LogLaunch mode & " :: " & cmdLine
  If sh.ExpandEnvironmentStrings("%SCHOOLHUB_LAUNCH_LOG_ONLY%") = "1" Then Exit Sub
  sh.Run cmdLine, 1, False
End Sub

Function FindChromium()
  Dim fso, p
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each p In Array( _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe", _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Google\Chrome\Application\chrome.exe")
    If fso.FileExists(p) Then FindChromium = p : Exit Function
  Next
  FindChromium = ""
End Function

Sub LogLaunch(m)
  On Error Resume Next
  Dim fso, f
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set f = fso.OpenTextFile(sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\SchoolHub\data\last-launch.txt", 8, True)
  f.WriteLine Now & " " & m
  f.Close
  On Error GoTo 0
End Sub
