' SchoolHub Manager launcher - starts the local server if needed and opens the app in the browser.
Option Explicit
Dim sh, base, url, ok, i
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\SchoolHub"
url = "http://127.0.0.1:8420/"
ok = False
For i = 1 To 40
  If HealthOk(url) Then ok = True : Exit For
  If i = 1 Then StartServer base
  WScript.Sleep 1000
Next
If ok Then
  If sh.ExpandEnvironmentStrings("%SCHOOLHUB_NO_BROWSER%") <> "1" Then sh.Run "explorer.exe """ & url & """", 1, False
Else
  If sh.ExpandEnvironmentStrings("%SCHOOLHUB_NO_BROWSER%") = "1" Then
    WScript.Echo "SchoolHub server failed to start within wait window (automation mode, no dialog)"
    WScript.Quit 1
  Else
    MsgBox "SchoolHub abhi start nahi ho saka. Dobara koshish karein; agar masla rahe to Alpha Blue Digital se rabta karein.", 48, "SchoolHub Manager"
  End If
End If

Function HealthOk(u)
  Dim http
  On Error Resume Next
  Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  http.Open "GET", u & "api/health", False
  http.setTimeouts 2000, 2000, 2000, 2000
  http.Send
  HealthOk = (Err.Number = 0 And http.Status = 200)
  Err.Clear
  On Error GoTo 0
End Function

Sub StartServer(b)
  Dim cmd
  If Not CreateObject("Scripting.FileSystemObject").FolderExists(b & "\data") Then CreateObject("Scripting.FileSystemObject").CreateFolder(b & "\data")
  cmd = "cmd /c cd /d """ & b & "\app"" && set PORT=8420&& set DATA_DIR=" & b & "\data&& """ & b & "\runtime\node.exe"" """ & b & "\app\server.js"" > """ & b & "\data\server.log"" 2>&1"
  sh.Run cmd, 0, False
End Sub
