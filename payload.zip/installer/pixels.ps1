# Windows installed-app UI pixels: drives a headless browser (Edge/Chrome on the runner)
# against the REAL installed app left running by smoke.ps1, via CDP (no npm dependencies).
# Proves the actual Windows-installed UI renders: login, forced password change, dashboard, core tabs.
$ErrorActionPreference = 'Stop'
$base = "$env:LOCALAPPDATA\SchoolHub"
$env:SCHOOLHUB_NO_BROWSER = '1'
function Health { try { return [bool](Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/health' -TimeoutSec 3).ok } catch { return $false } }
function Login($u, $p, [ref]$s) {
  Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/login' -Method Post -ContentType 'application/json' -Body (@{username=$u;password=$p} | ConvertTo-Json) -SessionVariable sv | Out-Null
  $s.Value = $sv
}
if (!(Health)) { cscript //nologo //T:90 "$base\launcher.vbs"; for ($i=0; $i -lt 10 -and !(Health); $i++) { Start-Sleep -Seconds 2 } }
if (!(Health)) { throw 'app not healthy for pixels' }

Write-Host '== seed realistic content via API (setup admin) =='
$sess = $null; Login 'owner' 'SmokePass-8420x' ([ref]$sess)
$sid = ((Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -WebSession $sess).schools | Where-Object { $_.code -eq 'smoke-test' }).id
if (!$sid) { throw 'smoke-test school missing - smoke.ps1 must run first' }
try { Invoke-RestMethod -Uri "http://127.0.0.1:8420/api/super/schools/$sid/admin" -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{name='Setup Admin';username='setup.admin';password='SetUp-8420x'} | ConvertTo-Json) | Out-Null } catch { Write-Host 'setup.admin exists' }
$asess = $null; Login 'setup.admin' 'SetUp-8420x' ([ref]$asess)
try { Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/change-password' -Method Post -ContentType 'application/json' -WebSession $asess -Body (@{current_password='SetUp-8420x';new_password='SetUp-8420y'} | ConvertTo-Json) | Out-Null } catch { }
$asess = $null; Login 'setup.admin' 'SetUp-8420y' ([ref]$asess)
$cls = $null
try { $cls = Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/classes' -Method Post -ContentType 'application/json' -WebSession $asess -Body (@{name='Class 1';level=1;monthly_fee=150000;sections=@('A')} | ConvertTo-Json) } catch { Write-Host 'class exists' }
if ($cls) {
  Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/students' -Method Post -ContentType 'application/json' -WebSession $asess -Body (@{name='Ahmed Raza';father_name='Muhammad Raza';guardian_phone='03011112222';gender='M';class_id=$cls.id} | ConvertTo-Json) | Out-Null
  Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/students' -Method Post -ContentType 'application/json' -WebSession $asess -Body (@{name='Fatima Noor';father_name='Noor Ahmed';guardian_phone='03033334444';gender='F';class_id=$cls.id} | ConvertTo-Json) | Out-Null
  Write-Host 'seeded class + 2 students'
}
Write-Host '== create untouched pixel admin (must_change=1) =='
try { Invoke-RestMethod -Uri "http://127.0.0.1:8420/api/super/schools/$sid/admin" -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{name='Pixel Admin';username='pixel.admin';password='Pixel-8420x'} | ConvertTo-Json) | Out-Null } catch { Write-Host 'pixel.admin exists' }

Write-Host '== headless browser screenshots =='
New-Item -ItemType Directory -Force pixels | Out-Null
& "$base\runtime\node.exe" p\installer\pixels.js "$PWD\pixels" pixel.admin 'Pixel-8420x' 'Pixel-8420y'
if ($LASTEXITCODE -ne 0) { throw "pixels.js exit $LASTEXITCODE" }
$shots = Get-ChildItem pixels\*.png
if ($shots.Count -lt 5) { throw "only $($shots.Count) screenshots captured" }
$shots | ForEach-Object { Write-Host "$($_.Name) $($_.Length) bytes" }
Compress-Archive -Path pixels\*.png -DestinationPath schoolhub-windows-pixels.zip -Force
Write-Host 'PIXELS PASS (Windows installed app)'
