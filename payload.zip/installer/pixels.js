// Windows installed-app UI pixel capture. Drives Edge/Chrome headless via CDP.
// Node 22 built-ins only (fetch + WebSocket) - no npm install needed on the runner.
// Usage: node pixels.js <outdir> <username> <password> <new_password>
const { spawn } = require('child_process');
const fs = require('fs'), path = require('path');
const OUT = process.argv[2] || 'pixels';
const [USER, PASS, NEWPASS] = process.argv.slice(3);
const BASE = 'http://127.0.0.1:8420';
const PORT = 9333;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const candidates = [
  process.env.BROWSER_PATH,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
].filter(Boolean);
const exe = candidates.find((p) => { try { fs.accessSync(p); return true; } catch { return false; } });
if (!exe) { console.error('no Edge/Chrome found'); process.exit(1); }
console.log('browser:', exe);
const udd = fs.mkdtempSync(path.join(process.env.TEMP || '.', 'px-'));
const cp = spawn(exe, ['--headless=new', '--disable-gpu', '--no-first-run', `--remote-debugging-port=${PORT}`, `--user-data-dir=${udd}`, '--window-size=1366,900', 'about:blank'], { stdio: 'ignore' });

let ws, seq = 0;
const pend = new Map();
function send(method, params = {}) {
  return new Promise((res, rej) => {
    const id = ++seq; pend.set(id, { res, rej });
    ws.send(JSON.stringify({ id, method, params }));
  });
}
async function evaluate(expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true });
  if (r.exceptionDetails) throw new Error('page eval failed: ' + (r.exceptionDetails.exception?.description || r.exceptionDetails.text));
  return r.result.value;
}
async function shot(name) {
  const r = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(OUT, name + '.png'), Buffer.from(r.data, 'base64'));
  console.log('shot', name);
}
const fill = (sel, val) => `(()=>{const el=document.querySelector(${JSON.stringify(sel)});if(!el)return false;el.value=${JSON.stringify(val)};el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return true})()`;
const click = (sel) => `(()=>{const el=document.querySelector(${JSON.stringify(sel)});if(!el)return false;el.click();return true})()`;

(async () => {
  let list = null;
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(`http://127.0.0.1:${PORT}/json/list`); list = await r.json(); if (list.find((t) => t.type === 'page')) break; } catch { }
    await sleep(500);
  }
  const target = list && list.find((t) => t.type === 'page');
  if (!target) throw new Error('CDP endpoint never came up');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.rej(new Error(m.error.message)) : p.res(m.result); }
  };
  await send('Page.enable'); await send('Runtime.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1366, height: 900, deviceScaleFactor: 1, mobile: false });

  // 1. login screen
  await send('Page.navigate', { url: BASE }); await sleep(3000);
  if (!(await evaluate(fill('[name=username]', '')))) throw new Error('login form not rendered');
  await shot('01-login');
  // 2. login -> forced password change
  await evaluate(fill('[name=username]', USER)); await evaluate(fill('[name=password]', PASS));
  if (!(await evaluate(click('form button.btn, form [type=submit]')))) throw new Error('login submit not found');
  await sleep(2500); await shot('02-pwchange');
  // 3. set new password -> dashboard
  if (!(await evaluate(fill('#pw-form [name=current_password]', PASS)))) throw new Error('pw change form not shown');
  await evaluate(fill('#pw-form [name=new_password]', NEWPASS));
  await evaluate(click('#pw-form button'));
  let tabs = false;
  for (let i = 0; i < 20 && !tabs; i++) { await sleep(1000); tabs = await evaluate(`!!document.querySelector('.tabs')`); }
  if (!tabs) { await shot('99-stuck'); throw new Error('dashboard tabs never appeared after password change'); }
  await sleep(1200); await shot('03-dashboard');
  // 4. core school tabs
  for (const [page, name] of [['students', '04-students'], ['fees', '05-fees'], ['attendance', '06-attendance'], ['exams', '07-exams'], ['settings', '08-settings']]) {
    const ok = await evaluate(`(()=>{const el=document.querySelector('.tabs button[data-page="${page}"]')||[...document.querySelectorAll('.tabs button')].find(b=>(b.textContent||'').toLowerCase().includes('${page}'));if(el){el.click();return true}return false})()`);
    await sleep(2000);
    if (ok) await shot(name); else console.log('tab not found:', page);
  }
  try { await send('Browser.close'); } catch { }
  cp.kill();
  console.log('PIXELS DONE');
  process.exit(0);
})().catch((e) => { console.error('PIXEL FAIL', e.message); try { cp.kill(); } catch { } process.exit(1); });
