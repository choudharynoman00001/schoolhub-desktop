# Upgrade preservation test: install the RELEASED v1.0.0 (r7c payload), write real data,
# then install THIS build over it and prove data + accounts survive and r8 features are live.
# Ends with a full uninstall + data wipe so later steps start from a clean machine.
$ErrorActionPreference = 'Stop'
$base = "$env:LOCALAPPDATA\SchoolHub"
$env:SCHOOLHUB_NO_BROWSER = '1'
function Health { try { return [bool](Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/health' -TimeoutSec 3).ok } catch { return $false } }
function Login($u, $p, [ref]$s) {
  Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/login' -Method Post -ContentType 'application/json' -Body (@{username=$u;password=$p} | ConvertTo-Json) -SessionVariable sv | Out-Null
  $s.Value = $sv
}
function Stop-Server {
  Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*\SchoolHub\runtime\node.exe*' } | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName Terminate | Out-Null }
  $down = $false; for ($i=0; $i -lt 10 -and !$down; $i++) { Start-Sleep -Seconds 1; $down = !(Health) }
  if (!$down) { throw 'server still up after stop' }
}
function Dump-Log { $log = "$base\data\server.log"; if (Test-Path $log) { Write-Host '--- server.log tail ---'; Get-Content $log -Tail 60 } else { Write-Host 'server.log missing' } }
function Wait-Health($tries) { for ($i=0; $i -lt $tries; $i++) { if (Health) { return $true }; Start-Sleep -Seconds 2 }; return $false }

Write-Host '== install released v1.0.0 (r7c) =='
Invoke-WebRequest 'https://github.com/choudharynoman00001/schoolhub-desktop/releases/download/v1.0.0/SchoolHub-Manager-Setup.exe' -OutFile old-setup.exe
Start-Process -FilePath '.\old-setup.exe' -ArgumentList '/S' -Wait
if (!(Test-Path "$base\app\server.js")) { throw 'v1.0.0 install failed' }
cscript //nologo //T:90 "$base\launcher.vbs"
if (!(Wait-Health 5)) { Dump-Log; throw 'v1.0.0 health failed' }
$cred = Get-Content "$base\data\bootstrap-superadmin.txt"
$u = (($cred | Select-String 'username: (.+)').Matches.Groups[1].Value).Trim()
$p = (($cred | Select-String 'password: (.+)').Matches.Groups[1].Value).Trim()
$sess = $null; Login $u $p ([ref]$sess)
Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/change-password' -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{current_password=$p;new_password='WinUp-8420x'} | ConvertTo-Json) | Out-Null
Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{name='Upgrade Base School';code='upgrade-base'} | ConvertTo-Json) | Out-Null
Write-Host 'v1.0.0 data written (owner pw changed, marker school created)'
Stop-Server

Write-Host '== install THIS build over v1.0.0 (upgrade path) =='
Start-Process -FilePath '.\SchoolHub-Manager-Setup.exe' -ArgumentList '/S' -Wait
if (!(Select-String -Path "$base\app\server.js" -Pattern 'exportPreservation' -Quiet)) { throw 'installed server.js is not the r8 build - upgrade did not replace app code' }
cscript //nologo //T:90 "$base\launcher.vbs"
if (!(Wait-Health 5)) { Dump-Log; throw 'upgraded health failed' }
$sess = $null; Login 'owner' 'WinUp-8420x' ([ref]$sess)
$after = (Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -WebSession $sess).schools
if (!($after | Where-Object { $_.code -eq 'upgrade-base' })) { throw 'marker school LOST after upgrade - data NOT preserved' }
Write-Host 'upgrade preserved owner account + school data'
$sid = ($after | Where-Object { $_.code -eq 'upgrade-base' }).id

Write-Host '== r8 feature live on upgraded DB: school admin + export =='
Invoke-RestMethod -Uri "http://127.0.0.1:8420/api/super/schools/$sid/admin" -Method Post -ContentType 'application/json' -WebSession $sess -Body (@{name='Upgrade Tester';username='upgradetester';password='UpTest-8420x'} | ConvertTo-Json) | Out-Null
$asess = $null; Login 'upgradetester' 'UpTest-8420x' ([ref]$asess)
Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/change-password' -Method Post -ContentType 'application/json' -WebSession $asess -Body (@{current_password='UpTest-8420x';new_password='UpTest-8420y'} | ConvertTo-Json) | Out-Null
Invoke-WebRequest -Uri 'http://127.0.0.1:8420/api/export' -WebSession $asess -OutFile upgrade-export.json
if ((Get-Item upgrade-export.json).Length -lt 100) { throw 'export too small - r8 export route not working on upgraded DB' }
Write-Host "export ok ($((Get-Item upgrade-export.json).Length) bytes)"

Write-Host '== restart after upgrade, data must persist =='
Stop-Server
cscript //nologo //T:90 "$base\launcher.vbs"
if (!(Wait-Health 5)) { Dump-Log; throw 'post-upgrade relaunch failed' }
$sess = $null; Login 'owner' 'WinUp-8420x' ([ref]$sess)
$after = (Invoke-RestMethod -Uri 'http://127.0.0.1:8420/api/super/schools' -WebSession $sess).schools
if (!($after | Where-Object { $_.code -eq 'upgrade-base' })) { throw 'marker LOST after post-upgrade restart' }
Write-Host 'UPGRADE PASS: v1.0.0 -> this build, data + accounts preserved, r8 export live, restart safe'

Write-Host '== cleanup for next phase (uninstall + wipe CI data) =='
Write-Host '[cleanup-1] stopping owned server processes (SchoolHub\runtime\node.exe path only)'
Stop-Server
Write-Host '[cleanup-1] server stopped. scoped pre-uninstall snapshot (SchoolHub-path processes only):'
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*\SchoolHub\*' } | ForEach-Object { Write-Host ("  pid={0} ppid={1} {2}: {3}" -f $_.ProcessId, $_.ParentProcessId, $_.Name, $_.CommandLine) }

Write-Host '[cleanup-2] launching silent uninstall (bounded 120s wait on the exact process we start)'
$unp = Start-Process -FilePath "$base\Uninstall.exe" -ArgumentList '/S' -PassThru
Write-Host "[cleanup-2] Uninstall.exe started, pid=$($unp.Id)"
$ok = $unp.WaitForExit(120000)
if (!$ok) {
  Write-Host 'CLEANUP DEGRADED: silent uninstall timed out after 120s - preserving evidence before scoped kill'
  $all = @(Get-CimInstance Win32_Process | Select-Object ProcessId, ParentProcessId, Name, CommandLine)
  $treeIds = @($unp.Id); $frontier = @($unp.Id)
  while ($frontier.Count -gt 0) {
    $kids = @($all | Where-Object { $frontier -contains $_.ParentProcessId })
    if ($kids.Count -eq 0) { break }
    $treeIds += @($kids | ForEach-Object { $_.ProcessId })
    $frontier = @($kids | ForEach-Object { $_.ProcessId })
  }
  Write-Host "[cleanup-2] uninstaller process tree PIDs: $($treeIds -join ',')"
  foreach ($proc in $all) { if ($treeIds -contains $proc.ProcessId) { Write-Host ("  TREE pid={0} ppid={1} {2}: {3}" -f $proc.ProcessId, $proc.ParentProcessId, $proc.Name, $proc.CommandLine) } }
  Write-Host '[cleanup-2] other uninstaller-lookalike processes (evidence, not killed):'
  $all | Where-Object { ($_.Name -like '*ninstall*' -or $_.Name -like '~un*') -and !($treeIds -contains $_.ProcessId) } | ForEach-Object { Write-Host ("  OTHER pid={0} ppid={1} {2}: {3}" -f $_.ProcessId, $_.ParentProcessId, $_.Name, $_.CommandLine) }
  for ($k = $treeIds.Count - 1; $k -ge 0; $k--) { Stop-Process -Id $treeIds[$k] -Force -ErrorAction SilentlyContinue }
  throw 'CLEANUP FAIL: silent uninstall timed out (120s) - uninstall NOT verified, later phases not isolated; run stops here by design'
}
Write-Host "[cleanup-2] parent exited (code $($unp.ExitCode)); NSIS runs the real work in a temp-copy child - waiting on the child tree (bounded 180s)"
$gone = $false
for ($i=0; $i -lt 36 -and !$gone; $i++) {
  Start-Sleep -Seconds 5
  $kids = @(Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq $unp.Id })
  $gone = !(Test-Path "$base\app\server.js")
  if ($i % 3 -eq 0 -or $gone) { Write-Host ("[cleanup-2] t+{0}s: children={1} appGone={2}" -f (($i+1)*5), $kids.Count, $gone) }
  if (!$gone -and $kids.Count -gt 0 -and $i -eq 35) { foreach ($k in $kids) { Write-Host ("  CHILD-STUCK pid={0} {1}: {2}" -f $k.ProcessId, $k.Name, $k.CommandLine) } }
}
if (!$gone) {
  Write-Host 'CLEANUP DEGRADED: uninstaller child tree still busy after 180s - preserving evidence'
  Get-CimInstance Win32_Process | Where-Object { $_.Name -in 'wscript.exe','cscript.exe' -or $_.CommandLine -like '*\SchoolHub\*' -or $_.ParentProcessId -eq $unp.Id } | ForEach-Object { Write-Host ("  EVIDENCE pid={0} ppid={1} {2}: {3}" -f $_.ProcessId, $_.ParentProcessId, $_.Name, $_.CommandLine) }
  Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq $unp.Id } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  throw 'CLEANUP FAIL: silent uninstall child did not finish (180s) - uninstall NOT verified, later phases not isolated; run stops here by design'
}

Write-Host '[cleanup-3] verifying Uninstall.exe itself removed the app (no manual wipe counted as uninstall)'
if (!$gone) { throw 'CLEANUP FAIL: uninstaller exited but app files remain - uninstall NOT verified' }
if (Test-Path "$base\runtime") { throw 'CLEANUP FAIL: uninstaller exited but runtime remains - uninstall NOT verified' }
Write-Host '[cleanup-3] uninstall verified: Uninstall.exe removed app + runtime'

Write-Host '[cleanup-4] wiping synthetic CI data folder only (owned test data from this run)'
Remove-Item "$base\data" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $base -Recurse -Force -ErrorAction SilentlyContinue
if (Test-Path "$base\app\server.js") { throw 'cleanup failed - app still present' }
Write-Host 'clean'
