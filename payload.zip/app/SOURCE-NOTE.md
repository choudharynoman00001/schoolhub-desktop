# app/ snapshot

Sanitized runtime snapshot of the SchoolHub app (server.js, package.json, public/)
synced from the private source repo at installer build time. Tests, docs,
blueprints, customer data and secrets are NEVER included here. Update this
folder when cutting a new installer release.

This snapshot: r8c line (private repo school-manager, archive schoolhub-source-r8c.zip,
SHA-256 466b0a445d6e4ddbd42dd444543b1f6b04615360c1908294dfbcda8e2fd61dcf).
Adds over r7c: suspended-school read-only data export preservation, SCC canonical
readback (date-granular), absence-notice idempotency, closed-ticket guards.
