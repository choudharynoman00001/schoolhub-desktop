This app snapshot is sanitized for the public installer payload: no tests,
no private docs, no customer data, no secrets. Full source is in the private
repo (school-manager). Demo data only with SEED_DEMO=1 (never set by the
installer).

This snapshot: v1.1.1 (private repo school-manager commit 28f0db2 line, archive
schoolhub-source-r8e.zip, SHA-256 bd8d8539b86a415a3abf57084615e074464432f16e40bd4f9bc146703763363a).
Adds over r8c: logout session-invalidation fix, drawer backdrop/Escape close,
admin demo-records trigger (bounded, idempotent), app-mode launcher,
NSIS uninstall silent-mode fix.
