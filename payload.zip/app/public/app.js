'use strict';
/* SchoolHub PWA frontend */
const I18N = {
  en: {
    app: 'SchoolHub', login: 'Login', logout: 'Logout', username: 'Username', password: 'Password',
    dashboard: 'Dashboard', students: 'Students', attendance: 'Attendance', fees: 'Fees', exams: 'Exams',
    classes: 'Classes', staff: 'Staff', finance: 'Finance', timetable: 'Timetable', homework: 'Homework',
    library: 'Library', transport: 'Transport', inventory: 'Inventory', notices: 'Notices', documents: 'Documents',
    meetings: 'Meetings', settings: 'Settings', holidays: 'Holidays', complaints: 'Complaints', renewals: 'Renewals', respond: 'Respond', response: 'Response', delete: 'Delete', in_progress: 'In Progress', resolved: 'Resolved', closed: 'Closed', open: 'Open', my_children: 'My Children', overview: 'Overview', schools: 'Schools',
    plans: 'Plans', subscriptions: 'Subscriptions', audit: 'Audit Log', save: 'Save', add: 'Add', cancel: 'Cancel',
    close: 'Close', name: 'Name', phone: 'Phone', actions: 'Actions', total: 'Total', date: 'Date', month: 'Month',
    amount: 'Amount', status: 'Status', class_: 'Class', section: 'Section', roll: 'Roll No', adm_no: 'Adm No',
    father: 'Father Name', mother: 'Mother Name', guardian_phone: 'Guardian Mobile', address: 'Address',
    total_students: 'Students', total_staff: 'Staff', today_att: "Today's Attendance", fees_month: 'Fees This Month',
    pending_fees: 'Pending Fees', expenses_month: 'Expenses This Month', salary_due: 'Monthly Salaries',
    present: 'Present', absent: 'Absent', late: 'Late', leave: 'Leave', mark_all_present: 'All Present',
    admission: 'New Admission', search: 'Search', dues: 'Dues', defaulters: 'Defaulters', collect: 'Collect',
    receipt: 'Receipt', generate_vouchers: 'Generate Monthly Vouchers', vouchers: 'Vouchers', paid: 'Paid',
    unpaid: 'Unpaid', partial: 'Partial', outstanding: 'Outstanding', pay: 'Receive Payment', method: 'Method',
    cash: 'Cash', bank: 'Bank', other: 'Other', reference: 'Reference No', reverse: 'Reverse', reason: 'Reason',
    class_history: 'Class History', my_record: 'My Record', view: 'View', filename: 'File Name', owner: 'Owner', size: 'Size',
    upload_file: 'Upload File', attach_bill: 'Attach Bill', set_photo: 'Set as Photo', files: 'Files', choose_file: 'Choose file (JPG/PNG/WEBP/PDF, max 5MB)',     banks: 'Bank Accounts', budget: 'Budget', balance: 'Balance', iban: 'IBAN', opening_balance: 'Opening Balance', actual: 'Actual', variance: 'Variance',
    approve: 'Approve', reopen: 'Reopen', marks_status: 'Marks Status', promote: 'Promote', rollover: 'Session Rollover', preview: 'Preview', confirm: 'Confirm',
    would_promote: 'students will be promoted', would_graduate: 'students will graduate', select_students: 'Select students', target_class: 'Target class', irreversible_note: 'Runs once per session - review the preview first.',
    rollover_once_note: 'Runs ONCE per academic session. After it runs, the next rollover needs a new current session (Academic Sessions above). A repeat click is refused.',
    monthly_fee: 'Monthly Fee', discount: 'Discount', fee_structure: 'Fee Structure', add_fee_type: 'Add Fee Type',
    collection: 'Collection Report', daily: 'Daily', by_class: 'Class-wise', income: 'Fee Income',
    expense: 'Expenses', surplus: 'Surplus', add_expense: 'Add Expense', category: 'Category', vendor: 'Vendor',
    salaries: 'Salaries', pay_salary: 'Pay Salary', results: 'Results', report_card: 'Report Card',
    marks_entry: 'Marks Entry', subject: 'Subject', max_marks: 'Max Marks', obtained: 'Obtained', percentage: 'Percentage',
    grade: 'Grade', position: 'Position', new_exam: 'New Exam', designation: 'Designation', salary: 'Salary',
    joining: 'Joining Date', new_employee: 'New Staff', leave_requests: 'Leave Requests', approve: 'Approve',
    reject: 'Reject', parent_portal: 'Parent Portal', attendance_summary: 'Attendance Summary',
    fee_vouchers: 'Fee Vouchers', results_: 'Results', notices_: 'Notices', create_school: 'New School',
    code: 'Code', plan: 'Plan', renewal: 'Renewal Date', active: 'Active', suspended: 'Suspended',
    trial: 'Trial', expired: 'Expired', suspend: 'Suspend', reactivate: 'Reactivate', mrr: 'Monthly Revenue (MRR)',
    schools_total: 'Total Schools', student_limit: 'Student Limit', create_admin: 'Create School Admin',
    confirm_payment: 'Record Subscription Payment', language: 'اردو', issue_book: 'Issue Book', return_book: 'Return',
    new_book: 'New Book', route_: 'Route', driver: 'Driver', assign: 'Assign', item: 'Item', quantity: 'Quantity',
    title: 'Title', body: 'Details', due_date: 'Due Date', audience: 'Audience', all: 'All', parents: 'Parents',
    teachers: 'Teachers', send: 'Publish', wa_reminder: 'WhatsApp Reminder', export: 'Export Data (JSON)', assign: 'Assign', remove: 'Remove', import_csv: 'Import CSV', vendors: 'Vendors',
    edit: 'Edit', add_section: 'Add Section', request_leave: 'Request Leave', from_d: 'From', to_d: 'To',
    reset_password: 'Reset Password', disable: 'Disable', enable: 'Enable', subjects: 'Subjects',
    fee_override: 'Fee Override (Rs)', book: 'Book', employee: 'Employee', guardian_add: 'Link Guardian',
    edit_student: 'Edit Student', relation: 'Relation', unassign: 'Unassign', import_done: 'Import complete',
    school_profile: 'School Profile', users_logins: 'Users & Logins', new_user: 'New User', role: 'Role',
    sessions: 'Academic Sessions', subjects_: 'Subjects', period: 'Period', day: 'Day', room: 'Room',
    loading: 'Loading...', no_data: 'No records yet', gender: 'Gender', dob: 'Date of Birth',
    admission_date: 'Admission Date', previous_school: 'Previous School', emergency: 'Emergency Contact',
    guardian: 'Guardian', link_guardian: 'Link Guardian', issue: 'Issue', overdue: 'OVERDUE',
    low_attendance: 'Low Attendance (last 30 days)', late_fee: 'Late Fee', late_fee_type: 'Late fee type', late_fee_value: 'Late fee value',
    flat: 'Flat (Rs)', percent: 'Percent (%)', absent_notice: 'Send absence notice to guardian', fee_rules: 'Fee Rules',
    support: 'Support Tickets', new_ticket: 'New Ticket', subject: 'Subject', reply: 'Reply', send_reply: 'Send Reply',
    close_ticket: 'Close Ticket', grace_days: 'Grace days', restrict_after_grace: 'Restrict after grace', payslip: 'Payslip',
    progress: 'Progress', term_average: 'Term Averages', export_xlsx: 'Excel (.xlsx)', create_ticket: 'Create Ticket', yes: 'Yes', no: 'No',
    upcoming_exams: 'Upcoming Exams', announcements: 'Announcements', homework_: 'Homework',
    subscription: 'Subscription', renewals_due: 'Renewals Due (14 days)', backup_note: 'Data is backed up daily on the server. Use Export for your own copy.',
    demo_warn: 'Demo school - data is sample only',
  },
  ur: {
    app: 'اسکول حب', login: 'لاگ ان', logout: 'لاگ آؤٹ', username: 'صارف نام', password: 'پاس ورڈ',
    dashboard: 'ڈیش بورڈ', students: 'طلبہ', attendance: 'حاضری', fees: 'فیسیں', exams: 'امتحانات',
    classes: 'کلاسز', staff: 'عملہ', finance: 'مالی حساب', timetable: 'ٹائم ٹیبل', homework: 'ہوم ورک',
    library: 'لائبریری', transport: 'نقل و حمل', inventory: 'اسٹاک', notices: 'اطلاعات', documents: 'دستاویزات',
    meetings: 'ملاقاتیں', settings: 'ترتیبات', holidays: 'تعطیلات', complaints: 'شکایات', renewals: 'تجدید', respond: 'جواب دیں', response: 'جواب', delete: 'حذف کریں', in_progress: 'جاری', resolved: 'حل شدہ', closed: 'بند', open: 'کھلا', my_children: 'میرے بچے', overview: 'جائزہ', schools: 'اسکول',
    plans: 'پلانز', subscriptions: 'سبسکرپشنز', audit: 'آڈٹ لاگ', save: 'محفوظ کریں', add: 'شامل کریں', cancel: 'منسوخ',
    close: 'بند کریں', name: 'نام', phone: 'فون', actions: 'کارروائی', total: 'کل', date: 'تاریخ', month: 'مہینہ',
    amount: 'رقم', status: 'حیثیت', class_: 'کلاس', section: 'سیکشن', roll: 'رول نمبر', adm_no: 'داخلہ نمبر',
    father: 'والد کا نام', mother: 'والدہ کا نام', guardian_phone: 'سرپرست موبائل', address: 'پتہ',
    total_students: 'طلبہ', total_staff: 'عملہ', today_att: 'آج کی حاضری', fees_month: 'اس مہینے کی فیس',
    pending_fees: 'باقی فیسیں', expenses_month: 'اس مہینے کے اخراجات', salary_due: 'ماہانہ تنخواہیں',
    present: 'حاضر', absent: 'غیر حاضر', late: 'دیر', leave: 'رخصت', mark_all_present: 'سب حاضر',
    admission: 'نیا داخلہ', search: 'تلاش', dues: 'باقیات', defaulters: 'ناادہندگان', collect: 'وصولی',
    receipt: 'رسید', generate_vouchers: 'ماہانہ واؤچر بنائیں', vouchers: 'واؤچر', paid: 'ادا شدہ',
    unpaid: 'غیر ادا شدہ', partial: 'جزوی', outstanding: 'باقی', pay: 'ادائیگی وصول کریں', method: 'طریقہ',
    cash: 'نقد', bank: 'بینک', other: 'دیگر', reference: 'حوالہ نمبر', reverse: 'منسوخ', reason: 'وجہ',
    class_history: 'کلاس ہسٹری', my_record: 'میرا ریکارڈ', view: 'دیکھیں', filename: 'فائل کا نام', owner: 'مالک', size: 'سائز',
    upload_file: 'فائل اپلوڈ', attach_bill: 'بل منسلک کریں', set_photo: 'تصویر مقرر کریں', files: 'فائلیں', choose_file: 'فائل منتخب کریں (JPG/PNG/WEBP/PDF, زیادہ سے زیادہ 5MB)',     banks: 'بینک اکاؤنٹس', budget: 'بجٹ', balance: 'بیلنس', iban: 'آئی بی اے این', opening_balance: 'ابتدائی بیلنس', actual: 'حقیقی', variance: 'فرق',
    approve: 'منظور', reopen: 'دوبارہ کھولیں', marks_status: 'نمبر اسٹیٹس', promote: 'ترقی', rollover: 'سیشن رول اوور', preview: 'پیش منظر', confirm: 'تصدیق',
    would_promote: 'طلباء کی ترقی ہوگی', would_graduate: 'طلباء گریجویٹ ہوں گے', select_students: 'طلباء منتخب کریں', target_class: 'ہدف کلاس', irreversible_note: 'فی سیشن ایک بار - پہلے پیش منظر دیکھیں۔',
    rollover_once_note: 'رول اوور فی سیشن ایک بار۔ اگلے کے لیے اوپر Academic Sessions میں نیا سیشن بنائیں۔ دوبارہ کلک مسترد۔',
    monthly_fee: 'ماہانہ فیس', discount: 'رعایت', fee_structure: 'فیس کی ساخت', add_fee_type: 'فیس کی قسم شامل کریں',
    collection: 'وصولی رپورٹ', daily: 'روزانہ', by_class: 'کلاس وار', income: 'فیس آمدن',
    expense: 'اخراجات', surplus: 'بچت', add_expense: 'خرچہ شامل کریں', category: 'قسم', vendor: 'سپلائر',
    salaries: 'تنخواہیں', pay_salary: 'تنخواہ ادا کریں', results: 'نتائج', report_card: 'رپورٹ کارڈ',
    marks_entry: 'نمبر درج کریں', subject: 'مضمون', max_marks: 'کل نمبر', obtained: 'حاصل', percentage: 'فیصد',
    grade: 'گریڈ', position: 'پوزیشن', new_exam: 'نیا امتحان', designation: 'عہدہ', salary: 'تنخواہ',
    joining: 'شمولیت کی تاریخ', new_employee: 'نیا ملازم', leave_requests: 'رخصت کی درخواستیں', approve: 'منظور',
    reject: 'مسترد', parent_portal: 'والدین پورٹل', attendance_summary: 'حاضری کا خلاصہ',
    fee_vouchers: 'فیس واؤچر', results_: 'نتائج', notices_: 'اطلاعات', create_school: 'نیا اسکول',
    code: 'کوڈ', plan: 'پلان', renewal: 'تجدید کی تاریخ', active: 'فعال', suspended: 'معطل',
    trial: 'آزمائشی', expired: 'ختم شدہ', suspend: 'معطل کریں', reactivate: 'بحال کریں', mrr: 'ماہانہ آمدن',
    schools_total: 'کل اسکول', student_limit: 'طلبہ کی حد', create_admin: 'اسکول ایڈمن بنائیں',
    confirm_payment: 'سبسکرپشن ادائیگی درج کریں', language: 'English', issue_book: 'کتاب جاری کریں', return_book: 'واپسی',
    new_book: 'نئی کتاب', route_: 'روٹ', driver: 'ڈرائیور', assign: 'تفویض', item: 'شے', quantity: 'تعداد',
    title: 'عنوان', body: 'تفصیل', due_date: 'واپسی کی تاریخ', audience: 'سامعین', all: 'سب', parents: 'والدین',
    teachers: 'اساتذہ', send: 'شائع کریں', wa_reminder: 'واٹس ایپ یاد دہانی', export: 'ڈیٹا ایکسپورٹ (JSON)', assign: 'تفویض', remove: 'ہٹائیں', import_csv: 'CSV درآمد', vendors: 'وینڈر',
    edit: 'ترمیم', add_section: 'سیکشن شامل کریں', request_leave: 'رخصت کی درخواست', from_d: 'از', to_d: 'تا',
    reset_password: 'پاس ورڈ ری سیٹ', disable: 'غیر فعال', enable: 'فعال', subjects: 'مضامین',
    fee_override: 'فیس اووررائیڈ (Rs)', book: 'کتاب', employee: 'ملازم', guardian_add: 'سرپرست منسلک کریں',
    edit_student: 'طالب علم میں ترمیم', relation: 'رشتہ', unassign: 'تفویض ختم', import_done: 'درآمد مکمل',
    school_profile: 'اسکول پروفائل', users_logins: 'صارفین اور لاگ اِن', new_user: 'نیا صارف', role: 'کردار',
    sessions: 'تعلیمی سیشن', subjects_: 'مضامین', period: 'پیریڈ', day: 'دن', room: 'کمرہ',
    loading: 'لوڈ ہو رہا ہے...', no_data: 'ابھی کوئی ریکارڈ نہیں', gender: 'جنس', dob: 'تاریخ پیدائش',
    admission_date: 'داخلے کی تاریخ', previous_school: 'سابقہ اسکول', emergency: 'ایمرجنسی رابطہ',
    guardian: 'سرپرست', link_guardian: 'سرپرست جوڑیں', issue: 'جاری', overdue: 'مدت گزر گئی',
    low_attendance: 'کم حاضری (آخری 30 دن)', late_fee: 'لیٹ فیس', late_fee_type: 'لیٹ فیس کی قسم', late_fee_value: 'لیٹ فیس رقم',
    flat: 'فکسڈ (Rs)', percent: 'فیصد (%)', absent_notice: 'غیر حاضری کی اطلاع سرپرست کو بھیجیں', fee_rules: 'فیس قوانین',
    support: 'سپورٹ ٹکٹس', new_ticket: 'نیا ٹکٹ', subject: 'عنوان', reply: 'جواب', send_reply: 'جواب بھیجیں',
    close_ticket: 'ٹکٹ بند کریں', grace_days: 'گریس دن', restrict_after_grace: 'گریس کے بعد پابندی', payslip: 'تنخواہ سلپ',
    progress: 'پیش رفت', term_average: 'ٹرم اوسط', export_xlsx: 'ایکسل (.xlsx)', create_ticket: 'ٹکٹ بنائیں', yes: 'ہاں', no: 'نہیں',
    upcoming_exams: 'آنے والے امتحانات', announcements: 'اطلاعات', homework_: 'ہوم ورک',
    subscription: 'سبسکرپشن', renewals_due: 'تجدید واجب (14 دن)', backup_note: 'ڈیٹا سرور پر روزانہ بیک اپ ہوتا ہے۔ اپنی کاپی کے لیے ایکسپورٹ استعمال کریں۔',
    demo_warn: 'ڈیمو اسکول - ڈیٹا صرف نمونہ ہے',
  },
};
let LANG = localStorage.getItem('sh_lang') || 'en';
function t(k) { return (I18N[LANG] && I18N[LANG][k]) || I18N.en[k] || k; }
function fmt(n) { const v = Number(n || 0) / 100; return 'Rs ' + v.toLocaleString('en-PK', { maximumFractionDigits: 2 }); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function todayISO() { return new Date().toISOString().slice(0, 10); }
function monthISO() { return new Date().toISOString().slice(0, 7); }

let USER = null;
let MSG = null;
async function api(path, method, body) {
  const r = await fetch(path, {
    method: method || 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await r.json(); } catch { data = {}; }
  if (!r.ok) { const e = new Error(data.error || ('HTTP ' + r.status)); e.status = r.status; throw e; }
  return data;
}
function toast(text, isErr) { MSG = { text, isErr }; setTimeout(() => { MSG = null; render(); }, 4000); render(); }
function msgHtml() { return MSG ? `<div class="msg ${MSG.isErr ? 'err' : 'ok'}">${esc(MSG.text)}</div>` : ''; }
function formValues(id) {
  const out = {};
  document.querySelectorAll(`#${id} [name]`).forEach((el) => {
    let v = el.value;
    if (el.type === 'number') v = v === '' ? null : Number(v);
    out[el.name] = v === '' ? (el.dataset.keep === undefined ? (el.type === 'number' ? null : '') : undefined) : v;
  });
  Object.keys(out).forEach((k) => out[k] === undefined && delete out[k]);
  return out;
}
function field(name, label, type, value, extra) {
  return `<div><label>${esc(label)}</label><input name="${name}" type="${type || 'text'}" value="${value == null ? '' : esc(value)}" ${extra || ''}></div>`;
}
function selField(name, label, options, value) {
  return `<div><label>${esc(label)}</label><select name="${name}">${options.map((o) => `<option value="${esc(o.v)}" ${String(o.v) === String(value) ? 'selected' : ''}>${esc(o.l)}</option>`).join('')}</select></div>`;
}
function pill(status) {
  const map = { paid: 'green', active: 'green', present: 'green', approved: 'green', unpaid: 'red', absent: 'red', overdue: 'red', suspended: 'red', rejected: 'red', expired: 'red', partial: 'amber', late: 'amber', pending: 'amber', trial: 'amber', leave: 'blue', withdrawn: 'gray', transferred: 'gray', graduated: 'blue', disabled: 'gray' };
  return `<span class="pill ${map[status] || 'gray'}">${esc(status)}</span>`;
}
function empty(txt) { return `<p class="muted">${esc(txt || t('no_data'))}</p>`; }

// ---------- login ----------
function renderLogin() {
  document.documentElement.dir = LANG === 'ur' ? 'rtl' : 'ltr';
  document.getElementById('app').innerHTML = `
  <div class="login-wrap">
    <h1>${t('app')}</h1>
    <div class="sub">Multi-School Management System - Pakistan</div>
    ${msgHtml()}
    <form id="login-form">
      <input name="username" placeholder="${t('username')}" autocomplete="username" required>
      <input name="password" type="password" placeholder="${t('password')}" autocomplete="current-password" required>
      <button class="btn" style="width:100%">${t('login')}</button>
    </form>
    <div style="text-align:center;margin-top:12px"><button class="btn sm gray" id="lang-btn">${t('language')}</button></div>
    <footer class="ab-brand"><img alt="Alpha Blue" src="/ab-logo.svg"> Developed by Chaudhry Noman &middot; Powered by <a href="https://alphablue.digital" target="_blank" rel="noopener">Alpha Blue Digital</a></footer>
  </div>`;
  document.getElementById('lang-btn').onclick = () => { LANG = LANG === 'en' ? 'ur' : 'en'; localStorage.setItem('sh_lang', LANG); renderLogin(); };
  document.getElementById('login-form').onsubmit = async (e) => {
    e.preventDefault();
    const v = formValues('login-form');
    try { const r = await api('/api/login', 'POST', v); USER = r.user; location.hash = ''; await render(); }
    catch (err) { toast(err.message, true); }
  };
}

// ---------- forced password change (bootstrap credentials) ----------
function renderForceChange() {
  document.documentElement.dir = LANG === 'ur' ? 'rtl' : 'ltr';
  document.getElementById('app').innerHTML = `
  <div class="login-wrap">
    <h1>${t('app')}</h1>
    <div class="sub">First login - set your own password to continue</div>
    ${msgHtml()}
    <form id="pw-form">
      <label class="muted">Current (temporary) password</label>
      <input name="current_password" type="password" required style="margin-bottom:10px">
      <label class="muted">New password (8+ characters)</label>
      <input name="new_password" type="password" minlength="8" required style="margin-bottom:10px">
      <button class="btn" style="width:100%">${t('save')}</button>
    </form>
    <footer class="ab-brand"><img alt="Alpha Blue" src="/ab-logo.svg"> Developed by Chaudhry Noman &middot; Powered by <a href="https://alphablue.digital" target="_blank" rel="noopener">Alpha Blue Digital</a></footer>
  </div>`;
  document.getElementById('pw-form').onsubmit = async (e) => {
    e.preventDefault();
    try {
      await api('/api/change-password', 'POST', formValues('pw-form'));
      USER.must_change = false;
      toast('Password updated'); await render();
    } catch (err) { toast(err.message, true); }
  };
}

// ---------- shell ----------
const NAV_SCHOOL = ['dashboard', 'students', 'attendance', 'fees', 'exams', 'classes', 'staff', 'finance', 'timetable', 'homework', 'library', 'transport', 'inventory', 'notices', 'documents', 'meetings', 'holidays', 'complaints', 'settings'];
const NAV_SUPER = ['overview', 'schools', 'plans', 'subscriptions', 'renewals', 'notices', 'audit'];
const NAV_PARENT = ['my_children', 'complaints'];
let PAGE = 'dashboard';
async function render() {
  if (!USER) { try { const r = await api('/api/me'); USER = r.user; } catch { return renderLogin(); } }
  if (USER.must_change) return renderForceChange();
  document.documentElement.dir = LANG === 'ur' ? 'rtl' : 'ltr';
  const nav = USER.role === 'super_admin' ? NAV_SUPER : (USER.role === 'parent' || USER.role === 'student') ? NAV_PARENT : NAV_SCHOOL;
  if (!nav.includes(PAGE)) PAGE = nav[0];
  const brand = USER.school_name || 'SchoolHub';
  document.getElementById('app').innerHTML = `
  <header class="top">
    <div class="brand"><img src="/icon.svg" alt="">${esc(brand)}</div>
    ${USER.school_name === 'Demo Public School' ? `<span class="pill amber">${t('demo_warn')}</span>` : ''}
    <div class="spacer"></div>
    <span class="muted" style="color:#dbeafe;font-size:13px">${esc(USER.name)} (${esc(USER.role)})</span>
    <button id="lang-btn">${t('language')}</button>
    <button id="logout-btn">${t('logout')}</button>
  </header>
  <nav class="tabs">${nav.map((p) => `<button data-page="${p}" class="${p === PAGE ? 'active' : ''}">${t(p === 'my_children' && USER.role === 'student' ? 'my_record' : p)}</button>`).join('')}</nav>
  <main id="main">${msgHtml()}<p class="muted">${t('loading')}</p></main>
  <footer class="ab-brand no-print"><img alt="Alpha Blue" src="/ab-logo.svg"> Developed by Chaudhry Noman &middot; Powered by <a href="https://alphablue.digital" target="_blank" rel="noopener">Alpha Blue Digital</a> &middot; All Rights Reserved 2026</footer>`;
  document.querySelectorAll('nav.tabs button').forEach((b) => { b.onclick = () => { PAGE = b.dataset.page; render(); }; });
  document.getElementById('lang-btn').onclick = () => { LANG = LANG === 'en' ? 'ur' : 'en'; localStorage.setItem('sh_lang', LANG); render(); };
  document.getElementById('logout-btn').onclick = async () => { await api('/api/logout', 'POST'); USER = null; renderLogin(); };
  const main = document.getElementById('main');
  const pages = { dashboard: pageDashboard, students: pageStudents, attendance: pageAttendance, fees: pageFees, exams: pageExams, classes: pageClasses, staff: pageStaff, finance: pageFinance, timetable: pageTimetable, homework: pageHomework, library: pageLibrary, transport: pageTransport, inventory: pageInventory, notices: pageNotices, documents: pageDocuments, meetings: pageMeetings, settings: pageSettings, my_children: pageParent, holidays: pageHolidays, complaints: pageComplaints, renewals: pageSuperRenewals, overview: pageSuperOverview, schools: pageSuperSchools, plans: pageSuperPlans, subscriptions: pageSuperSubs, audit: pageSuperAudit };
  const fn = pages[PAGE] || pageDashboard;
  try { await fn(main); } catch (e) { main.innerHTML = msgHtml() + `<div class="msg err">${esc(e.message)}</div>`; }
}
window.addEventListener('hashchange', () => { const h = location.hash.slice(1); if (h) { PAGE = h; render(); } });
render();

// ---------- dashboard ----------
async function pageDashboard(main) {
  const d = await api('/api/dashboard');
  const a = d.attendance_today || {};
  const attTxt = `${a.present || 0}P ${a.absent || 0}A ${a.late || 0}L ${a.leave || 0}V`;
  main.innerHTML = msgHtml() + `
  <div class="cards">
    <div class="card"><div class="num">${d.students}</div><div class="lbl">${t('total_students')}</div></div>
    <div class="card"><div class="num">${d.staff}</div><div class="lbl">${t('total_staff')}</div></div>
    <div class="card"><div class="num" style="font-size:16px">${attTxt}</div><div class="lbl">${t('today_att')}</div></div>
    <div class="card"><div class="num" style="font-size:18px">${fmt(d.fees_collected_month)}</div><div class="lbl">${t('fees_month')}</div></div>
    <div class="card"><div class="num" style="font-size:18px;color:#dc2626">${fmt(d.fees_pending)}</div><div class="lbl">${t('pending_fees')}</div></div>
    <div class="card"><div class="num" style="font-size:18px">${fmt(d.expenses_month)}</div><div class="lbl">${t('expenses_month')}</div></div>
    <div class="card"><div class="num" style="font-size:18px">${fmt(d.salary_monthly)}</div><div class="lbl">${t('salary_due')}</div></div>
  </div>
  <div class="panel"><h2>${t('upcoming_exams')}</h2>${d.upcoming_exams.length ? `<table><tr><th>${t('name')}</th><th>${t('date')}</th></tr>${d.upcoming_exams.map((e) => `<tr><td>${esc(e.name)}</td><td>${esc(e.start_date)}</td></tr>`).join('')}</table>` : empty()}</div>
  ${(d.low_attendance || []).length ? `<div class="panel"><h2>${t('low_attendance')}</h2>
    <table><tr><th>${t('name')}</th><th>${t('class_')}</th><th>${t('present')}</th><th>${t('absent')}</th><th>%</th></tr>
    ${d.low_attendance.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.class_name || '-')}</td><td>${x.present}</td><td>${x.absent}</td><td><span class="pill red">${x.pct}%</span></td></tr>`).join('')}</table></div>` : ''}`;
}

// ---------- students ----------
let stuFilter = { class_id: '', q: '' };
async function pageStudentSelf(main) {
  const d = await api('/api/students/' + USER.student_id);
  const st = d.student;
  main.innerHTML = msgHtml() + `
  <div class="panel">
    <div class="row" style="justify-content:space-between;align-items:center"><h2>${esc(st.name)}</h2>
      <img alt="" src="/api/students/${st.id}/photo" style="width:64px;height:64px;border-radius:8px;object-fit:cover" onerror="this.style.display='none'"></div>
    <p class="muted">${esc(st.admission_no)} | ${esc(st.class_name || '-')} ${esc(st.section_name || '')} | ${st.status}</p>
    <h3>${t('attendance_summary')}</h3>
    <div class="cards">${(d.attendance_summary || []).map((x) => `<div class="card"><div class="num">${x.c}</div><div class="lbl">${t(x.status)}</div></div>`).join('') || empty()}</div>
    <h3>${t('vouchers')}</h3>
    ${d.vouchers.length ? `<table><tr><th>${t('month')}</th><th>${t('total')}</th><th>${t('status')}</th></tr>${d.vouchers.map((v) => `<tr><td>${esc(v.month)}</td><td>${fmt(v.total)}</td><td>${pill(v.status)}</td></tr>`).join('')}</table>` : empty()}
    <h3>${t('class_history')}</h3>
    ${(d.history || []).length ? `<table><tr><th>${t('date')}</th><th>From</th><th>To</th><th>${t('actions')}</th></tr>${d.history.map((h) => `<tr><td>${esc((h.at || h.created_at || '').slice(0, 10))}</td><td>${esc(h.from_class || '-')}</td><td>${esc(h.to_class || '-')}</td><td>${esc(h.action)}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
}
async function pageStudents(main) {
  if (USER.role === 'student') {
    if (!USER.student_id) { main.innerHTML = msgHtml() + `<div class="panel">${empty()}</div>`; return; }
    return pageStudentSelf(main);
  }
  const cls = await api('/api/classes');
  const params = new URLSearchParams();
  if (stuFilter.class_id) params.set('class_id', stuFilter.class_id);
  if (stuFilter.q) params.set('q', stuFilter.q);
  const data = await api('/api/students?' + params);
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    <div class="row" style="margin-bottom:12px">
      <select id="f-class" style="width:auto"><option value="">${t('class_')}: ${t('all')}</option>${cls.classes.map((c) => `<option value="${c.id}" ${String(c.id) === String(stuFilter.class_id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      <input id="f-q" placeholder="${t('search')}..." style="width:200px" value="${esc(stuFilter.q)}">
      ${canWrite ? `<button class="btn" id="add-stu-btn">${t('admission')}</button> <button class="btn gray" id="imp-stu-btn">${t('import_csv')}</button> <a class="btn gray" href="/api/students.csv" style="text-decoration:none">${t('export')} CSV</a> <a class="btn gray" href="/api/students.xlsx" style="text-decoration:none">${t('export_xlsx')}</a>` : ''}
    </div>
    <div id="imp-stu" style="display:none;margin-bottom:12px;border:1px solid #e2e8f0;border-radius:8px;padding:10px">
      <h3>${t('import_csv')}</h3>
      <p class="muted">CSV columns: name, father_name, guardian_phone, class, section, roll_no, monthly_fee, dob, gender, address</p>
      <textarea id="imp-text" rows="5" style="width:100%" placeholder="name,father_name,guardian_phone,class,section&#10;Ali Raza,Muhammad Raza,03001234567,Class 1,A"></textarea>
      <p style="margin:6px 0"><input type="file" id="imp-file" accept=".csv,text/csv"></p>
      <button class="btn green" id="imp-run">${t('import_csv')}</button>
      <div id="imp-out" style="margin-top:8px"></div>
    </div>
    <div id="add-stu" style="display:none">
      <h3>${t('admission')}</h3>
      <div class="form-grid" id="stu-form">
        ${field('name', t('name'), 'text', '', 'required')}
        ${field('father_name', t('father'))}
        ${field('mother_name', t('mother'))}
        ${field('guardian_phone', t('guardian_phone'))}
        ${selField('gender', t('gender'), [{ v: '', l: '-' }, { v: 'M', l: 'Male / لڑکا' }, { v: 'F', l: 'Female / لڑکی' }])}
        ${field('dob', t('dob'), 'date')}
        ${selField('class_id', t('class_'), [{ v: '', l: '-' }].concat(cls.classes.map((c) => ({ v: c.id, l: c.name }))))}
        ${selField('section_id', t('section'), [{ v: '', l: '-' }].concat(cls.classes.flatMap((c) => (c.sections || []).map((s) => ({ v: s.id, l: c.name + ' ' + s.name })))))}
        ${field('roll_no', t('roll'))}
        ${field('admission_date', t('admission_date'), 'date', todayISO())}
        ${field('monthly_fee_override', t('monthly_fee') + ' (' + t('other') + ')', 'number')}
        ${field('discount', t('discount') + ' (Rs)', 'number')}
        ${field('previous_school', t('previous_school'))}
        ${field('emergency_contact', t('emergency'))}
        <div style="grid-column:1/-1"><label>${t('address')}</label><input name="address"></div>
      </div>
      <button class="btn green" id="stu-save">${t('save')}</button>
    </div>
    <h3 style="margin-top:14px">${t('students')} (${data.students.length})</h3>
    ${data.students.length ? `<table>
      <tr><th>${t('adm_no')}</th><th>${t('name')}</th><th>${t('father')}</th><th class="hide-m">${t('class_')}</th><th class="hide-m">${t('guardian_phone')}</th><th>${t('dues')}</th><th>${t('actions')}</th></tr>
      ${data.students.map((s) => `<tr>
        <td>${esc(s.admission_no)}</td><td>${esc(s.name)}</td><td>${esc(s.father_name)}</td>
        <td class="hide-m">${esc(s.class_name)} ${esc(s.section_name)}</td><td class="hide-m">${esc(s.guardian_phone)}</td>
        <td>${s.dues > 0 ? `<span class="pill red">${fmt(s.dues)}</span>` : '<span class="pill green">0</span>'}</td>
        <td><button class="btn sm outline" onclick="openStudent(${s.id})">${t('view')}</button></td>
      </tr>`).join('')}</table>` : empty()}
  </div>`;
  document.getElementById('f-class').onchange = (e) => { stuFilter.class_id = e.target.value; render(); };
  document.getElementById('f-q').onchange = (e) => { stuFilter.q = e.target.value; render(); };
  if (canWrite) {
    document.getElementById('add-stu-btn').onclick = () => { const el = document.getElementById('add-stu'); el.style.display = el.style.display === 'none' ? 'block' : 'none'; };
    document.getElementById('imp-stu-btn').onclick = () => { const el = document.getElementById('imp-stu'); el.style.display = el.style.display === 'none' ? 'block' : 'none'; };
    document.getElementById('imp-run').onclick = async () => {
      let csv = document.getElementById('imp-text').value;
      const f = document.getElementById('imp-file').files[0];
      if (f) csv = await f.text();
      if (!csv.trim()) return toast('CSV required', true);
      try {
        const r = await api('/api/students/import', 'POST', { csv });
        document.getElementById('imp-out').innerHTML = `<p><b>${r.created}</b> created, <b>${r.skipped}</b> skipped.</p>${(r.errors || []).slice(0, 20).map((x) => `<p class="muted">${esc(x)}</p>`).join('')}`;
      } catch (e) { toast(e.message, true); }
    };
    document.getElementById('stu-save').onclick = async () => {
      const v = formValues('stu-form');
      try {
        const r = await api('/api/students', 'POST', v);
        toast(`${t('admission')} OK: ${r.admission_no}` + (r.duplicate_warning ? ' | ' + r.duplicate_warning : ''));
      } catch (e) { toast(e.message, true); }
    };
  }
}
window.openStudent = async (id) => {
  const d = await api('/api/students/' + id);
  const s = d.student;
  const att = {}; d.attendance_summary.forEach((r) => { att[r.status] = r.c; });
  const prog = await api('/api/students/' + id + '/progress');
  const canEdit = ['admin', 'staff'].includes(USER.role);
  const canFin = ['admin', 'accountant'].includes(USER.role);
  const clsE = canEdit ? (await api('/api/classes')).classes : [];
  const el = document.createElement('div');
  el.className = 'drawer';
  el.innerHTML = `<div>
    <div class="row" style="justify-content:space-between"><h2>${esc(s.name)} <span class="muted">(${esc(s.admission_no)})</span></h2><button class="btn sm gray" id="dr-close">${t('close')}</button></div>
    ${s.photo_file_id ? `<img alt="" src="/api/students/${s.id}/photo" style="width:72px;height:72px;border-radius:8px;object-fit:cover" onerror="this.style.display='none'">` : ''}
    <p class="muted">${esc(s.class_name)} ${esc(s.section_name)} | ${t('roll')}: ${esc(s.roll_no)} | ${pill(s.status)}</p>
    <p>${t('father')}: ${esc(s.father_name)} | ${t('guardian_phone')}: ${esc(s.guardian_phone)}${s.guardian_phone ? ` <a class="wa-link" target="_blank" href="https://wa.me/${encodeURIComponent(s.guardian_phone.replace(/[^0-9]/g, '').replace(/^0/, '92'))}?text=${encodeURIComponent('Fee reminder: Rs ' + s.dues + ' outstanding for ' + s.name)}">WhatsApp</a>` : ''}</p>
    <p class="muted">${t('dob')}: ${esc(s.dob)} | ${t('address')}: ${esc(s.address)}</p>
    <h3>${t('attendance_summary')}</h3><p>${t('present')}: ${att.present || 0} | ${t('absent')}: ${att.absent || 0} | ${t('late')}: ${att.late || 0} | ${t('leave')}: ${att.leave || 0}</p>
    <h3>${t('progress')}</h3>
    ${prog.terms.length ? `<table><tr><th>${t('term_average')}</th><th>%</th></tr>${prog.terms.map((x) => `<tr><td>${esc(x.term)}</td><td>${x.average_pct}%</td></tr>`).join('')}</table>
    ${Object.keys(prog.subjects).map((sub) => `<p style="margin-top:6px"><b>${esc(sub)}</b>: ${prog.subjects[sub].map((m) => `${esc(m.exam)} ${m.pct}%`).join(' → ')}</p>`).join('')}` : empty()}
    <h3>${t('fee_vouchers')}</h3>
    ${d.vouchers.length ? `<table><tr><th>${t('month')}</th><th>${t('total')}</th><th>${t('status')}</th></tr>${d.vouchers.map((v) => `<tr><td>${esc(v.month)}</td><td>${fmt(v.total)}</td><td>${pill(v.status)}</td></tr>`).join('')}</table>` : empty()}
    <h3>${t('documents')}</h3>
    ${d.documents.length ? d.documents.map((x) => `<p>• ${esc(x.title)} <span class="muted">${esc(x.created_at.slice(0, 10))}</span></p>`).join('') : empty()}
    <h3>${t('guardian')}</h3>
    ${d.guardians.map((g) => `<p>• ${esc(g.name)} (${esc(g.relation)}) - ${esc(g.phone)}</p>`).join('') || empty()}
    ${canEdit ? `<h3>${t('edit_student')}</h3>
    <div class="form-grid" id="st-edit">
      ${field('name', t('name'), 'text', s.name)}
      ${selField('class_id', t('class_'), clsE.map((c) => ({ v: c.id, l: c.name })), s.class_id)}
      ${selField('status', t('status'), ['active', 'withdrawn', 'transferred', 'graduated'].map((x) => ({ v: x, l: x })), s.status)}
      ${field('roll_no', t('roll'), 'number', s.roll_no)}
      ${field('guardian_phone', t('guardian_phone'), 'text', s.guardian_phone)}
      ${field('emergency_contact', 'Emergency Contact', 'text', s.emergency_contact)}
      ${canFin ? field('monthly_fee_override', t('fee_override'), 'number', s.monthly_fee_override == null ? '' : s.monthly_fee_override / 100) : ''}
      ${canFin ? field('discount', t('discount') + ' (Rs)', 'number', (s.discount || 0) / 100) : ''}
    </div><button class="btn green" id="st-edit-save">${t('save')}</button>
    <h3 style="margin-top:12px">${t('guardian_add')}</h3>
    <div class="form-grid" id="g-add">
      ${field('name', t('name'))}${field('phone', t('phone'))}${field('relation', t('relation'), 'text', 'father')}
    </div><button class="btn green" id="g-add-save">${t('save')}</button>` : ''}
    <h3>${t('class_history')}</h3>
    ${(d.history || []).length ? `<table><tr><th>${t('date')}</th><th>From</th><th>To</th><th>${t('actions')}</th></tr>${d.history.map((h) => `<tr><td>${esc((h.at || '').slice(0, 10))}</td><td>${esc(h.from_class || '-')}</td><td>${esc(h.to_class || '-')}</td><td>${esc(h.action)}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
  el.querySelector('#dr-close').onclick = () => el.remove();
  if (canEdit) {
    el.querySelector('#st-edit-save').onclick = async () => {
      const v = formValues('st-edit');
      v.class_id = Number(v.class_id) || undefined; v.roll_no = Number(v.roll_no) || undefined;
      if (v.monthly_fee_override === '') v.monthly_fee_override = null;
      if (v.discount === '') v.discount = 0;
      try { await api('/api/students/' + id, 'PATCH', v); toast(t('save') + ' OK'); el.remove(); render(); } catch (e) { toast(e.message, true); }
    };
    el.querySelector('#g-add-save').onclick = async () => {
      try { await api(`/api/students/${id}/guardians`, 'POST', formValues('g-add')); toast(t('save') + ' OK'); el.remove(); render(); window.openStudent(id); } catch (e) { toast(e.message, true); }
    };
  }
  el.onclick = (e) => { if (e.target === el) el.remove(); };
  document.body.appendChild(el);
};

// ---------- attendance ----------
let attSel = { class_id: '', section_id: '', date: todayISO(), month: monthISO() };
async function pageAttendance(main) {
  const cls = await api('/api/classes');
  const canMark = ['admin', 'teacher', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    <div class="row" style="margin-bottom:12px">
      <select id="a-class" style="width:auto"><option value="">${t('class_')}...</option>${cls.classes.map((c) => `<option value="${c.id}" ${String(c.id) === String(attSel.class_id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      <input id="a-date" type="date" value="${attSel.date}" style="width:auto">
      ${canMark ? `<button class="btn sm green" id="a-all">${t('mark_all_present')}</button><button class="btn sm" id="a-save">${t('save')}</button>` : ''}
    </div>
    <div id="att-list" class="att-grid"><p class="muted">${t('loading')}</p></div>
  </div>
  <div class="panel">
    <h2>${t('attendance_summary')} - ${t('month')}</h2>
    <div class="row" style="margin-bottom:10px">
      <input id="a-month" type="month" value="${attSel.month}" style="width:auto">
      <select id="a-rclass" style="width:auto"><option value="">${t('class_')}: ${t('all')}</option>${cls.classes.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select>
    </div>
    <div id="att-report"></div>
  </div>`;
  const list = document.getElementById('att-list');
  const state = {};
  async function loadRegister() {
    if (!attSel.class_id) { list.innerHTML = empty(t('class_') + '...'); return; }
    const d = await api(`/api/attendance/register?class_id=${attSel.class_id}&date=${attSel.date}`);
    d.students.forEach((s) => { state[s.id] = s.status || 'present'; });
    list.innerHTML = d.students.length ? d.students.map((s) => `
      <div class="att-row" data-id="${s.id}">
        <span class="nm">${esc(s.roll_no)}. ${esc(s.name)} <span class="muted">(${esc(s.admission_no)})</span></span>
        ${['present', 'absent', 'late', 'leave'].map((st) => `<button data-st="${st}" class="${state[s.id] === st ? 'on-' + st[0] : ''}" title="${t(st)}">${t(st).slice(0, 3)}</button>`).join('')}
      </div>`).join('') : empty();
    list.querySelectorAll('.att-row button').forEach((b) => {
      b.onclick = () => {
        const id = b.closest('.att-row').dataset.id;
        state[id] = b.dataset.st;
        b.closest('.att-row').querySelectorAll('button').forEach((x) => x.className = state[id] === x.dataset.st ? 'on-' + x.dataset.st[0] : '');
      };
    });
  }
  async function loadReport() {
    const month = document.getElementById('a-month').value;
    const rclass = document.getElementById('a-rclass').value;
    const d = await api(`/api/attendance/report?month=${month}${rclass ? '&class_id=' + rclass : ''}`);
    document.getElementById('att-report').innerHTML = d.report.length ? `<table>
      <tr><th>${t('name')}</th><th>${t('class_')}</th><th>${t('present')}</th><th>${t('absent')}</th><th>${t('late')}</th><th>${t('leave')}</th><th>%</th></tr>
      ${d.report.map((r) => `<tr class="${r.percentage != null && r.percentage < 75 ? 'style=background:#fef2f2' : ''}">
        <td>${esc(r.name)}</td><td>${esc(r.class_name)}</td><td>${r.present}</td><td>${r.absent}</td><td>${r.late}</td><td>${r.leave}</td>
        <td>${r.percentage == null ? '-' : r.percentage + '%'}</td></tr>`).join('')}</table>` : empty();
  }
  document.getElementById('a-class').onchange = (e) => { attSel.class_id = e.target.value; loadRegister(); };
  document.getElementById('a-date').onchange = (e) => { attSel.date = e.target.value; loadRegister(); };
  if (canMark) {
    document.getElementById('a-all').onclick = () => { Object.keys(state).forEach((k) => { state[k] = 'present'; }); loadRegister(); };
    document.getElementById('a-save').onclick = async () => {
      const records = Object.entries(state).map(([student_id, status]) => ({ student_id: Number(student_id), status }));
      if (!records.length) return toast(t('no_data'), true);
      try { const r = await api('/api/attendance/mark', 'POST', { date: attSel.date, records }); toast(`${t('save')} OK (${r.marked})`); loadReport(); }
      catch (e) { toast(e.message, true); }
    };
  }
  document.getElementById('a-month').onchange = loadReport;
  document.getElementById('a-rclass').onchange = loadReport;
  await loadRegister(); await loadReport();
}

// ---------- fees ----------
let feeTab = 'vouchers';
let feeMonth = monthISO();
async function pageFees(main) {
  const canFee = ['admin', 'accountant'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    <div class="row" style="margin-bottom:12px">
      ${['vouchers', 'dues', 'collection', 'structure'].map((x) => `<button class="btn sm ${feeTab === x ? '' : 'gray'}" data-ft="${x}">${t(x === 'structure' ? 'fee_structure' : x)}</button>`).join('')}
      <input id="fee-month" type="month" value="${feeMonth}" style="width:auto">
    </div>
    <div id="fee-body"><p class="muted">${t('loading')}</p></div>
  </div>`;
  main.querySelectorAll('[data-ft]').forEach((b) => { b.onclick = () => { feeTab = b.dataset.ft; render(); }; });
  document.getElementById('fee-month').onchange = (e) => { feeMonth = e.target.value; render(); };
  const body = document.getElementById('fee-body');
  if (feeTab === 'vouchers') {
    const d = await api('/api/fees/vouchers?month=' + feeMonth);
    body.innerHTML = `
      ${canFee ? `<div class="row" style="margin-bottom:10px"><input id="due-date" type="date" value="${feeMonth}-10" style="width:auto"><button class="btn sm green" id="gen-btn">${t('generate_vouchers')}</button></div>` : ''}
      ${d.vouchers.length ? `<table><tr><th>#</th><th>${t('name')}</th><th>${t('class_')}</th><th>${t('total')}</th><th>${t('paid')}</th><th>${t('outstanding')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
      ${d.vouchers.map((v) => `<tr>
        <td>${v.id}</td><td>${esc(v.student.name)}</td><td class="hide-m">${esc(v.student.class_name || '')} ${esc(v.student.section_name || '')}</td>
        <td>${fmt(v.total)}</td><td>${fmt(v.paid)}</td><td>${v.outstanding > 0 ? `<b style="color:#dc2626">${fmt(v.outstanding)}</b>` : '0'}</td><td>${pill(v.status)}</td>
        <td>${canFee && v.outstanding > 0 ? `<button class="btn sm green" onclick="payVoucher(${v.id},${v.outstanding},'${esc(v.student.name)}')">${t('pay')}</button>` : ''}
        ${canFee && v.outstanding > 0 && v.due_date < todayISO() ? ` <button class="btn sm outline" onclick="lateFee(${v.id})">+ ${t('late_fee')}</button>` : ''}</td>
      </tr>`).join('')}</table>` : empty()}`;
    if (canFee) document.getElementById('gen-btn').onclick = async () => {
      try { const r = await api('/api/fees/generate', 'POST', { month: feeMonth, due_date: document.getElementById('due-date').value }); toast(`${t('generate_vouchers')}: ${r.created} OK, ${r.skipped} skip`); render(); }
      catch (e) { toast(e.message, true); }
    };
  } else if (feeTab === 'dues') {
    const d = await api('/api/fees/dues');
    body.innerHTML = `<h3>${t('dues')} - ${fmt(d.total_outstanding)}</h3>
      ${d.dues.length ? `<table><tr><th>${t('name')}</th><th>${t('class_')}</th><th>${t('month')}</th><th>${t('outstanding')}</th><th>${t('due_date')}</th><th>${t('actions')}</th></tr>
      ${d.dues.map((x) => `<tr>
        <td>${esc(x.student)} <span class="muted">${esc(x.admission_no)}</span></td><td>${esc(x.class_name || '')} ${esc(x.section_name || '')}</td>
        <td>${esc(x.month)}</td><td><b style="color:#dc2626">${fmt(x.outstanding)}</b></td>
        <td>${esc(x.due_date)} ${x.overdue ? `<span class="pill red">${t('overdue')}</span>` : ''}</td>
        <td class="row">${x.guardian_phone ? `<a class="wa-link" target="_blank" href="https://wa.me/${encodeURIComponent(x.guardian_phone.replace(/[^0-9]/g, '').replace(/^0/, '92'))}?text=${encodeURIComponent('Assalam o Alaikum, ' + x.student + ' ki ' + x.month + ' fee Rs ' + x.outstanding + ' pending hai. Baraye meherbani ada karein. Shukriya.')}">${t('wa_reminder')}</a>` : ''}
        ${canFee ? `<button class="btn sm green" onclick="payVoucher(${x.voucher_id},${x.outstanding},'${esc(x.student)}')">${t('pay')}</button>` : ''}</td>
      </tr>`).join('')}</table>` : empty()}`;
  } else if (feeTab === 'collection') {
    const d = await api('/api/fees/collection?month=' + feeMonth);
    body.innerHTML = `<h3>${t('collection')} - ${feeMonth}: ${fmt(d.total)}</h3>
      <h3>${t('daily')}</h3>${d.daily.length ? `<table><tr><th>${t('date')}</th><th>${t('method')}</th><th>#</th><th>${t('total')}</th></tr>
      ${d.daily.map((x) => `<tr><td>${esc(x.date)}</td><td>${esc(x.method)}</td><td>${x.count}</td><td>${fmt(x.total)}</td></tr>`).join('')}</table>` : empty()}
      <h3>${t('by_class')}</h3>${d.by_class.length ? `<table><tr><th>${t('class_')}</th><th>${t('total')}</th></tr>
      ${d.by_class.map((x) => `<tr><td>${esc(x.class_name || '-')}</td><td>${fmt(x.total)}</td></tr>`).join('')}</table>` : empty()}
      <p style="margin-top:8px"><a class="btn sm gray" href="/api/fees/collection.xlsx?month=${feeMonth}" style="text-decoration:none">${t('export_xlsx')}</a></p>`;
  } else {
    const d = await api('/api/fees/structures');
    const cls = await api('/api/classes');
    body.innerHTML = `
      ${canFee ? `<h3>${t('add_fee_type')}</h3><div class="form-grid" id="fs-form">
        ${field('name', t('name'), 'text', '', 'placeholder="Exam Fee, Lab Fee..."')}
        ${field('amount', t('amount') + ' (Rs)', 'number')}
        ${selField('class_id', t('class_'), [{ v: '', l: t('all') }].concat(cls.classes.map((c) => ({ v: c.id, l: c.name }))))}
        ${selField('frequency', t('month') + '/' + t('other'), [{ v: 'monthly', l: 'Monthly' }, { v: 'one_time', l: 'One-time' }, { v: 'annual', l: 'Annual' }])}
      </div><button class="btn green" id="fs-add">${t('add')}</button>
      <p class="muted" style="margin:8px 0">${t('monthly_fee')}: ${t('classes')} page</p>` : ''}
      ${d.structures.length ? `<table><tr><th>${t('name')}</th><th>${t('class_')}</th><th>${t('amount')}</th><th>${t('month')}</th>${canFee ? '<th></th>' : ''}</tr>
      ${d.structures.map((f) => `<tr><td>${esc(f.name)}</td><td>${esc(f.class_name || t('all'))}</td><td>${fmt(f.amount)}</td><td>${esc(f.frequency)}</td>
      ${canFee ? `<td><button class="btn sm red" onclick="delStructure(${f.id})">X</button></td>` : ''}</tr>`).join('')}</table>` : empty()}`;
    if (canFee) document.getElementById('fs-add').onclick = async () => {
      try { await api('/api/fees/structures', 'POST', formValues('fs-form')); toast(t('save') + ' OK'); render(); }
      catch (e) { toast(e.message, true); }
    };
  }
}
window.delStructure = async (id) => { try { await api('/api/fees/structures/' + id, 'DELETE'); toast('OK'); render(); } catch (e) { toast(e.message, true); } };
window.lateFee = async (id) => {
  if (!confirm(t('late_fee') + '?')) return;
  try { const r = await api(`/api/fees/vouchers/${id}/late-fee`, 'POST', {}); toast(`${t('late_fee')}: ${fmt(r.amount)}`); render(); }
  catch (e) { toast(e.message, true); }
};
window.payVoucher = async (id, outstanding, name) => {
  const el = document.createElement('div');
  el.className = 'drawer';
  el.innerHTML = `<div style="width:min(420px,96vw)">
    <h2>${t('pay')} - ${esc(name)}</h2>
    <p class="muted">${t('outstanding')}: <b style="color:#dc2626">${fmt(outstanding)}</b></p>
    <div class="form-grid" id="pay-form" style="margin-top:12px">
      ${field('amount', t('amount') + ' (Rs)', 'number', outstanding)}
      ${selField('method', t('method'), [{ v: 'cash', l: t('cash') }, { v: 'bank', l: t('bank') }, { v: 'other', l: t('other') }])}
      ${field('date', t('date'), 'date', todayISO())}
      ${field('reference', t('reference'))}
      ${field('payer', t('guardian'))}
    </div>
    <div class="row"><button class="btn green" id="pay-save">${t('save')}</button><button class="btn gray" id="pay-cancel">${t('cancel')}</button></div>
    <div id="pay-result"></div>
  </div>`;
  el.querySelector('#pay-cancel').onclick = () => el.remove();
  el.querySelector('#pay-save').onclick = async () => {
    const v = formValues('pay-form');
    try {
      const r = await api('/api/fees/payments', 'POST', Object.assign({ voucher_id: id }, v));
      el.querySelector('#pay-result').innerHTML = `<div class="msg ok">${t('save')} OK - <a class="wa-link" target="_blank" href="${r.receipt_url}">${t('receipt')} (PDF)</a></div>`;
      setTimeout(() => { el.remove(); render(); }, 1500);
    } catch (e) { toast(e.message, true); }
  };
  document.body.appendChild(el);
};

// ---------- exams ----------
let examSel = { id: null };
async function pageExams(main) {
  const d = await api('/api/exams');
  const cls = await api('/api/classes');
  const canWrite = ['admin', 'staff'].includes(USER.role);
  const canMarks = ['admin', 'teacher', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('new_exam')}</h3>
    <div class="form-grid" id="exam-form">
      ${field('name', t('name'), 'text', '', 'placeholder="First Term 2026"')}
      ${selField('class_id', t('class_'), [{ v: '', l: t('all') }].concat(cls.classes.map((c) => ({ v: c.id, l: c.name }))))}
      ${field('start_date', t('date'), 'date')}
      ${field('subjects', t('subjects_'), 'text', '', 'placeholder="English:100, Math:100, Urdu:100"')}
    </div><button class="btn green" id="exam-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('exams')}</h3>
    ${d.exams.length ? `<table><tr><th>${t('name')}</th><th>${t('class_')}</th><th>${t('date')}</th><th>${t('subjects_')}</th><th>${t('actions')}</th></tr>
    ${d.exams.map((e) => `<tr><td>${esc(e.name)}</td><td>${esc(e.class_name || t('all'))}</td><td>${esc(e.start_date)}</td>
      <td>${e.subjects.map((s) => esc(s.subject)).join(', ') || '-'}</td>
      <td class="row"><button class="btn sm outline" onclick="examResults(${e.id})">${t('results')}</button>
      ${canMarks ? `<button class="btn sm" onclick="examMarks(${e.id}, '${esc(e.name)}')">${t('marks_entry')}</button>` : ''}</td></tr>`).join('')}</table>` : empty()}
  </div>
  <div id="exam-detail"></div>`;
  if (canWrite) document.getElementById('exam-add').onclick = async () => {
    const v = formValues('exam-form');
    v.subjects = String(v.subjects || '').split(',').map((x) => { const [subject, mm] = x.split(':'); return { subject: subject.trim(), max_marks: Number(mm) || 100 }; }).filter((s) => s.subject);
    try { await api('/api/exams', 'POST', v); toast(t('save') + ' OK'); render(); }
    catch (e) { toast(e.message, true); }
  };
}
window.examResults = async (id) => {
  const d = await api(`/api/exams/${id}/results`);
  const el = document.getElementById('exam-detail');
  el.innerHTML = `<div class="panel"><h2>${esc(d.exam.name)} - ${t('results')}</h2>
    ${d.results.length ? `<table><tr><th>${t('position')}</th><th>${t('name')}</th>${d.results[0].subjects.map((s) => `<th class="hide-m">${esc(s.subject)}</th>`).join('')}<th>${t('total')}</th><th>%</th><th>${t('grade')}</th><th></th></tr>
    ${d.results.map((r) => `<tr><td>${r.position || '-'}</td><td>${esc(r.name)}</td>
      ${r.subjects.map((s) => `<td class="hide-m">${s.absent ? 'A' : (s.obtained == null ? '-' : s.obtained)}</td>`).join('')}
      <td>${r.total_obtained}/${r.total_max}</td><td>${r.percentage == null ? '-' : r.percentage + '%'}</td><td><b>${esc(r.grade)}</b></td>
      <td><a class="btn sm outline" target="_blank" href="/api/report-cards/${id}/${r.student_id}.pdf">${t('report_card')}</a></td></tr>`).join('')}</table>` : empty()}</div>`;
  el.scrollIntoView({ behavior: 'smooth' });
};
window.examMarks = async (examId, name) => {
  const d = await api('/api/exams');
  const exam = d.exams.find((e) => e.id === examId);
  if (!exam || !exam.subjects.length) return toast(t('no_data'), true);
  const stuParams = exam.class_id ? '?class_id=' + exam.class_id : '';
  const students = (await api('/api/students' + stuParams)).students;
  const el = document.getElementById('exam-detail');
  el.innerHTML = `<div class="panel"><h2>${t('marks_entry')} - ${esc(name)}</h2>
    ${exam.subjects.map((s) => `<h3>${esc(s.subject)} (${t('max_marks')}: ${s.max_marks}) ${pill(s.marks_status || 'draft')}
      ${USER.role === 'admin' ? (s.marks_status === 'approved'
        ? ` <button class="btn sm gray" onclick="marksReopen(${s.id})">${t('reopen')}</button>`
        : ` <button class="btn sm green" onclick="marksApprove(${s.id})">${t('approve')}</button>`) : ''}</h3>
    <div class="att-grid" data-sub="${s.id}">
      ${students.map((st) => `<div class="att-row"><span class="nm">${esc(st.roll_no)}. ${esc(st.name)}</span>
        <input type="number" min="0" max="${s.max_marks}" data-stu="${st.id}" style="width:80px" placeholder="/${s.max_marks}">
        <label class="muted" style="font-size:12px"><input type="checkbox" data-abs="${st.id}" style="width:auto"> ${t('absent')}</label>
      </div>`).join('')}
    </div>`).join('')}
    <div class="row" style="margin-top:12px"><button class="btn green" id="marks-save">${t('save')}</button></div>
  </div>`;
  el.scrollIntoView({ behavior: 'smooth' });
  document.getElementById('marks-save').onclick = async () => {
    try {
      for (const block of el.querySelectorAll('[data-sub]')) {
        const subId = block.dataset.sub;
        const records = [];
        block.querySelectorAll('input[data-stu]').forEach((inp) => {
          const abs = block.querySelector(`input[data-abs="${inp.dataset.stu}"]`).checked;
          if (abs) records.push({ student_id: Number(inp.dataset.stu), absent: true });
          else if (inp.value !== '') records.push({ student_id: Number(inp.dataset.stu), obtained: Number(inp.value) });
        });
        if (records.length) await api(`/api/exams/subjects/${subId}/marks`, 'POST', { records });
      }
      toast(t('save') + ' OK');
    } catch (e) { toast(e.message, true); }
  };
};

window.marksApprove = async (subId) => {
  try { await api('/api/exams/subjects/' + subId + '/approve-marks', 'POST', {}); toast(t('approve') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.marksReopen = async (subId) => {
  try { await api('/api/exams/subjects/' + subId + '/reopen-marks', 'POST', {}); toast(t('reopen') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};

// ---------- classes ----------
async function pageClasses(main) {
  const d = await api('/api/classes');
  const sd = await api('/api/sessions');
  const subs = await api('/api/subjects');
  const canWrite = ['admin', 'staff'].includes(USER.role);
  const emps = canWrite ? (await api('/api/employees')).employees : [];
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('classes')}</h3>
    <div class="form-grid" id="cls-form">
      ${field('name', t('name'), 'text', '', 'placeholder="Class 1 / Playgroup"')}
      ${field('level', 'Level (1-10)', 'number')}
      ${field('monthly_fee', t('monthly_fee') + ' (Rs)', 'number')}
      ${field('sections', t('section'), 'text', 'A', 'placeholder="A,B"')}
    </div><button class="btn green" id="cls-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('classes')}</h3>
    ${d.classes.length ? `<table><tr><th>${t('name')}</th><th>Level</th><th>${t('monthly_fee')}</th><th>${t('section')}</th>${canWrite ? `<th>${t('actions')}</th>` : ''}</tr>
    ${d.classes.map((c) => `<tr><td>${esc(c.name)}</td><td>${c.level}</td><td>${fmt(c.monthly_fee)}</td><td>${(c.sections || []).map((s) => esc(s.name)).join(', ')}</td>
      ${canWrite ? `<td><button class="btn sm outline" onclick="editClass(${c.id},'${esc(c.name).replace(/'/g, '')}',${c.level},${c.monthly_fee / 100})">${t('edit')}</button> <button class="btn sm gray" onclick="addSection(${c.id})">${t('add_section')}</button></td>` : ''}</tr>`).join('')}</table>` : empty()}
  </div>
  <div class="panel"><h2>${t('sessions')}</h2>
    ${USER.role === 'admin' ? `<div class="form-grid" id="ses-form">${field('name', t('name'), 'text', '', 'placeholder="2026-27"')}${field('start_date', t('date'), 'date')}</div>
    <button class="btn green" id="ses-add">${t('add')}</button>` : ''}
    ${sd.sessions.length ? `<table><tr><th>${t('name')}</th><th>${t('date')}</th><th>${t('status')}</th></tr>
    ${sd.sessions.map((s) => `<tr><td>${esc(s.name)}</td><td>${esc(s.start_date)}</td><td>${s.is_current ? pill('active') : ''}</td></tr>`).join('')}</table>` : empty()}
  </div>
  <div class="panel"><h2>${t('subjects')}</h2>
    ${canWrite ? `<div class="form-grid" id="sub-form">
      ${field('name', t('name'), 'text', '', 'placeholder="Mathematics"')}
      ${selField('class_id', t('class_'), [{ v: '', l: '-' }].concat(d.classes.map((c) => ({ v: c.id, l: c.name }))))}
      ${selField('teacher_id', t('teachers'), [{ v: '', l: '-' }].concat(emps.map((e) => ({ v: e.id, l: e.name }))))}
    </div><button class="btn green" id="sub-add">${t('add')}</button>` : ''}
    ${subs.subjects.length ? `<table style="margin-top:10px"><tr><th>${t('name')}</th><th>${t('class_')}</th><th>${t('teachers')}</th></tr>
    ${subs.subjects.map((s) => `<tr><td>${esc(s.name)}</td><td>${esc(s.class_name || '-')}</td><td>${esc(s.teacher_name || '-')}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('cls-add').onclick = async () => {
    const v = formValues('cls-form');
    v.sections = String(v.sections || 'A').split(',').map((x) => x.trim()).filter(Boolean);
    try { await api('/api/classes', 'POST', v); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  if (USER.role === 'admin') document.getElementById('ses-add').onclick = async () => {
    try { await api('/api/sessions', 'POST', Object.assign(formValues('ses-form'), { is_current: true })); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  if (canWrite) document.getElementById('sub-add').onclick = async () => {
    const v = formValues('sub-form'); if (!v.class_id) delete v.class_id; if (!v.teacher_id) delete v.teacher_id;
    try { await api('/api/subjects', 'POST', v); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  if (canWrite) {
    const stu = await api('/api/students');
    const promo = document.createElement('div');
    promo.className = 'panel';
    promo.innerHTML = `<h2>${t('promote')}</h2>
      <div class="form-grid" id="promo-form">
        ${selField('to_class_id', t('target_class'), [{ v: '', l: '-' }].concat(d.classes.map((c) => ({ v: c.id, l: c.name }))))}
      </div>
      <p class="muted">${t('select_students')}</p>
      <div style="max-height:200px;overflow:auto">${stu.students.filter((x) => x.status === 'active').map((x) =>
        `<label style="display:block;font-size:13px"><input type="checkbox" class="promo-chk" value="${x.id}" style="width:auto"> ${esc(x.roll_no)}. ${esc(x.name)} <span class="muted">(${esc(x.class_name || '')})</span></label>`).join('')}</div>
      <button class="btn" id="promo-run" style="margin-top:8px">${t('promote')}</button>
      <h2 style="margin-top:20px">${t('rollover')}</h2>
      <p class="muted">${t('rollover_once_note')}</p>
      <button class="btn" id="ro-preview-btn">${t('preview')}</button>
      <div id="ro-preview" style="margin-top:10px"></div>`;
    main.appendChild(promo);
    document.getElementById('promo-run').onclick = async () => {
      const ids = [...promo.querySelectorAll('.promo-chk:checked')].map((c) => Number(c.value));
      const to = promo.querySelector('[name=to_class_id]').value;
      if (!ids.length || !to) return toast(t('select_students') + ' + ' + t('target_class'), true);
      try { const r = await api('/api/students/promote', 'POST', { student_ids: ids, to_class_id: Number(to) }); toast(t('promote') + ' OK (' + r.moved + ')'); render(); } catch (e) { toast(e.message, true); }
    };
    document.getElementById('ro-preview-btn').onclick = async () => {
      try {
        const p = await api('/api/sessions/rollover', 'POST', {});
        const pv = document.getElementById('ro-preview');
        pv.innerHTML = `<p><b>${p.would_promote}</b> ${t('would_promote')}, <b>${p.would_graduate}</b> ${t('would_graduate')}.</p>
          <button class="btn green" id="ro-confirm">${t('confirm')}</button>`;
        document.getElementById('ro-confirm').onclick = async (ev) => {
          ev.target.disabled = true;
          try { const r = await api('/api/sessions/rollover', 'POST', { confirm: true }); toast(t('rollover') + ' OK (' + r.promoted + ' / ' + r.graduated + ')'); render(); }
          catch (e) { toast(e.message, true); ev.target.disabled = false; }
        };
      } catch (e) { toast(e.message, true); }
    };
  }
}

// ---------- staff ----------
async function pageStaff(main) {
  const d = await api('/api/employees');
  const lv = USER.role === 'admin' ? await api('/api/leaves') : null;
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('new_employee')}</h3>
    <div class="form-grid" id="emp-form">
      ${field('name', t('name'))}
      ${field('designation', t('designation'), 'text', '', 'placeholder="Teacher / Clerk / Guard"')}
      ${field('phone', t('phone'))}
      ${field('qualification', 'Qualification')}
      ${field('salary', t('salary') + ' (Rs)', 'number')}
      ${field('joining_date', t('joining'), 'date', todayISO())}
    </div><button class="btn green" id="emp-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('staff')} (${d.employees.length})</h3>
    ${d.employees.length ? `<table><tr><th>${t('name')}</th><th>${t('designation')}</th><th class="hide-m">${t('phone')}</th><th>${t('salary')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
    ${d.employees.map((e) => `<tr><td>${esc(e.name)}</td><td>${esc(e.designation)}</td><td class="hide-m">${esc(e.phone)}</td>
      <td>${fmt(e.salary)}</td><td>${pill(e.status)}</td>
      <td><button class="btn sm outline" onclick="empRecord(${e.id})">${t('view')}</button></td></tr>`).join('')}</table>` : empty()}
  </div>
  <div class="panel">
    ${canWrite && d.employees.length ? `<h3>${t('request_leave')}</h3><div class="form-grid" id="lv-form">
      ${selField('employee_id', t('employee'), d.employees.map((e) => ({ v: e.id, l: e.name })))}
      ${field('from_date', t('from_d'), 'date', todayISO())}
      ${field('to_date', t('to_d'), 'date', todayISO())}
      ${field('reason', t('reason'))}
    </div><button class="btn green" id="lv-add">${t('save')}</button>` : ''}
    ${lv ? `<h3 style="margin-top:14px">${t('leave_requests')} (${lv.leaves.length})</h3>
    ${lv.leaves.length ? `<table><tr><th>${t('employee')}</th><th>${t('from_d')}</th><th>${t('to_d')}</th><th class="hide-m">${t('reason')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
    ${lv.leaves.map((l) => `<tr><td>${esc(l.employee_name)}</td><td>${esc(l.from_date)}</td><td>${esc(l.to_date)}</td><td class="hide-m">${esc(l.reason || '')}</td><td>${pill(l.status)}</td>
      <td>${l.status === 'pending' ? `<button class="btn sm green" onclick="leaveAction(${l.id},'approved')">${t('approve')}</button> <button class="btn sm red" onclick="leaveAction(${l.id},'rejected')">${t('reject')}</button>` : ''}</td></tr>`).join('')}</table>` : empty()}` : ''}
  </div>
  <div class="panel"><h2>${t('today_att')} - ${t('staff')}</h2><div id="emp-att"><p class="muted">${t('loading')}</p></div></div>`;
  if (canWrite) document.getElementById('emp-add').onclick = async () => {
    try { await api('/api/employees', 'POST', formValues('emp-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  if (canWrite && d.employees.length) document.getElementById('lv-add').onclick = async () => {
    const v = formValues('lv-form'); const eid = v.employee_id; delete v.employee_id;
    try { await api(`/api/employees/${eid}/leave`, 'POST', v); toast(t('request_leave') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  const ea = await api('/api/attendance/employees?date=' + todayISO());
  const state = {}; ea.employees.forEach((e) => { state[e.id] = e.status || 'present'; });
  const eaEl = document.getElementById('emp-att');
  eaEl.innerHTML = ea.employees.length ? `<div class="att-grid">${ea.employees.map((e) => `
    <div class="att-row" data-id="${e.id}"><span class="nm">${esc(e.name)} <span class="muted">(${esc(e.designation)})</span></span>
    ${['present', 'absent', 'late', 'leave'].map((st) => `<button data-st="${st}" class="${state[e.id] === st ? 'on-' + st[0] : ''}">${t(st).slice(0, 3)}</button>`).join('')}
    </div>`).join('')}</div>
    <div class="row" style="margin-top:10px"><button class="btn sm green" id="emp-att-save">${t('save')}</button></div>` : empty();
  eaEl.querySelectorAll('.att-row button').forEach((b) => {
    b.onclick = () => {
      const id = b.closest('.att-row').dataset.id; state[id] = b.dataset.st;
      b.closest('.att-row').querySelectorAll('button').forEach((x) => x.className = state[id] === x.dataset.st ? 'on-' + x.dataset.st[0] : '');
    };
  });
  const saveBtn = document.getElementById('emp-att-save');
  if (saveBtn) saveBtn.onclick = async () => {
    const records = Object.entries(state).map(([employee_id, status]) => ({ employee_id: Number(employee_id), status }));
    try { const r = await api('/api/attendance/employees', 'POST', { date: todayISO(), records }); toast(`${t('save')} OK (${r.marked})`); }
    catch (e) { toast(e.message, true); }
  };
}
window.empRecord = async (id) => {
  const d = await api(`/api/employees/${id}/record`);
  const el = document.createElement('div');
  el.className = 'drawer';
  el.innerHTML = `<div>
    <div class="row" style="justify-content:space-between"><h2>${esc(d.employee.name)}</h2><button class="btn sm gray" id="dr-close">${t('close')}</button></div>
    <p class="muted">${esc(d.employee.designation)} | ${esc(d.employee.phone)} | ${fmt(d.employee.salary)}/month</p>
    <h3>${t('attendance_summary')}</h3><p>${d.attendance_summary.map((a) => `${t(a.status)}: ${a.c}`).join(' | ') || '-'}</p>
    <h3>${t('salaries')}</h3>
    ${d.salary_payments.length ? `<table><tr><th>${t('month')}</th><th>${t('amount')}</th><th>${t('date')}</th>${['admin', 'accountant'].includes(USER.role) ? `<th>${t('payslip')}</th>` : ''}</tr>${d.salary_payments.map((p) => `<tr><td>${esc(p.month)}</td><td>${fmt(p.amount)}</td><td>${esc(p.date)}</td>${['admin', 'accountant'].includes(USER.role) ? `<td><a target="_blank" href="/api/salaries/${p.id}/payslip.pdf">${t('payslip')} PDF</a>` : ''}</td></tr>`).join('')}</table>` : empty()}
    <h3>${t('leave_requests')}</h3>
    ${d.leave_requests.length ? d.leave_requests.map((l) => `<p>• ${esc(l.from_date)} → ${esc(l.to_date)} ${pill(l.status)} <span class="muted">${esc(l.reason)}</span></p>`).join('') : empty()}
  </div>`;
  el.querySelector('#dr-close').onclick = () => el.remove();
  el.onclick = (e) => { if (e.target === el) el.remove(); };
  document.body.appendChild(el);
};

// ---------- finance (expenses, salaries, report) ----------
let finTab = 'expenses';
async function pageFinance(main) {
  const canFee = ['admin', 'accountant'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    <div class="row" style="margin-bottom:12px">
      ${['expenses', 'salaries', 'report'].concat(canFee ? ['banks', 'budget', 'vendors'] : []).map((x) => `<button class="btn sm ${finTab === x ? '' : 'gray'}" data-x="${x}">${t(x === 'report' ? 'collection' : x === 'expenses' ? 'expense' : x === 'salaries' ? 'salaries' : x)}</button>`).join('')}
    </div>
    <div id="fin-body"><p class="muted">${t('loading')}</p></div>
  </div>`;
  main.querySelectorAll('[data-x]').forEach((b) => { b.onclick = () => { finTab = b.dataset.x; render(); }; });
  const body = document.getElementById('fin-body');
  if (finTab === 'expenses') {
    const d = await api('/api/expenses?month=' + monthISO());
    body.innerHTML = `
      ${canFee ? `<h3>${t('add_expense')}</h3><div class="form-grid" id="exp-form">
        ${selField('category_id', t('category'), [{ v: '', l: '-' }].concat(d.categories.map((c) => ({ v: c.id, l: c.name }))))}
        ${field('new_category', t('category') + ' (' + t('other') + ')', 'text', '', 'placeholder="Rent, Electricity..."')}
        ${field('amount', t('amount') + ' (Rs)', 'number')}
        ${field('date', t('date'), 'date', todayISO())}
        ${selField('method', t('method'), [{ v: 'cash', l: t('cash') }, { v: 'bank', l: t('bank') }, { v: 'other', l: t('other') }])}
        ${field('note', t('body'))}
      </div><button class="btn green" id="exp-add">${t('add')}</button>` : ''}
      <h3 style="margin-top:12px">${t('expense')} - ${monthISO()}</h3>
      ${d.expenses.length ? `<table><tr><th>${t('date')}</th><th>${t('category')}</th><th>${t('amount')}</th><th class="hide-m">${t('method')}</th><th class="hide-m">${t('body')}</th></tr>
      ${d.expenses.map((e) => `<tr><td>${esc(e.date)}</td><td>${esc(e.category_name || '-')}</td><td>${fmt(e.amount)}</td><td class="hide-m">${esc(e.method)}</td><td class="hide-m">${esc(e.note)}
        ${canFee ? `<label class="btn sm outline" style="cursor:pointer">${t('attach_bill')}<input type="file" style="display:none" accept=".jpg,.jpeg,.png,.webp,.pdf" onchange="attachBill(this,${e.id})"></label>` : ''}</td></tr>`).join('')}</table>` : empty()}`;
    if (canFee) document.getElementById('exp-add').onclick = async () => {
      try { await api('/api/expenses', 'POST', formValues('exp-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
  } else if (finTab === 'salaries') {
    const d = await api('/api/salaries?month=' + monthISO());
    body.innerHTML = `<h3>${t('salaries')} - ${d.month}</h3>
      ${d.employees.length ? `<table><tr><th>${t('name')}</th><th>${t('designation')}</th><th>${t('salary')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
      ${d.employees.map((e) => `<tr><td>${esc(e.name)}</td><td>${esc(e.designation)}</td><td>${fmt(e.salary)}</td>
        <td>${e.payment ? `<span class="pill green">${t('paid')} ${fmt(e.payment.amount)}</span>` : pill('unpaid')}</td>
        <td>${canFee && !e.payment ? `<button class="btn sm green" onclick="paySalary(${e.id},${e.salary},'${esc(e.name)}')">${t('pay_salary')}</button>` : ''}</td></tr>`).join('')}</table>` : empty()}`;
  } else if (finTab === 'banks') {
    const d = await api('/api/bank-accounts');
    body.innerHTML = `
      <h3>${t('add')} - ${t('banks')}</h3><div class="form-grid" id="bank-form">
        ${field('name', t('name'))}
        ${field('iban', t('iban'))}
        ${field('opening_balance', t('opening_balance') + ' (Rs)', 'number', 0)}
      </div><button class="btn green" id="bank-add">${t('add')}</button>
      <h3 style="margin-top:12px">${t('banks')}</h3>
      ${d.accounts.length ? `<table><tr><th>${t('name')}</th><th class="hide-m">${t('iban')}</th><th>${t('opening_balance')}</th><th>${t('balance')}</th></tr>
      ${d.accounts.map((a) => `<tr><td>${esc(a.name)}</td><td class="hide-m">${esc(a.iban || '-')}</td><td>${fmt(a.opening_balance)}</td><td><b>${fmt(a.balance)}</b></td></tr>`).join('')}</table>` : empty()}
      <p class="muted" style="margin-top:8px">${t('balance')} = ${t('opening_balance')} + bank ${t('income')} - bank ${t('expense')}</p>`;
    document.getElementById('bank-add').onclick = async () => {
      try { await api('/api/bank-accounts', 'POST', formValues('bank-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
  } else if (finTab === 'vendors') {
    const d = await api('/api/expenses?month=' + monthISO());
    body.innerHTML = `
      <h3>${t('add')} - ${t('vendors')}</h3><div class="form-grid" id="ven-form">
        ${field('name', t('name'))}${field('phone', t('phone'))}${field('note', t('body'))}
      </div><button class="btn green" id="ven-add">${t('add')}</button>
      <h3 style="margin-top:12px">${t('vendors')}</h3>
      ${d.vendors.length ? `<table><tr><th>${t('name')}</th><th>${t('phone')}</th><th class="hide-m">${t('body')}</th></tr>
      ${d.vendors.map((v) => `<tr><td>${esc(v.name)}</td><td>${esc(v.phone || '-')}</td><td class="hide-m">${esc(v.note || '')}</td></tr>`).join('')}</table>` : empty()}`;
    document.getElementById('ven-add').onclick = async () => {
      try { await api('/api/vendors', 'POST', formValues('ven-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
  } else if (finTab === 'budget') {
    const ed = await api('/api/expenses?month=' + monthISO());
    const bd = await api('/api/reports/budget?month=' + monthISO());
    body.innerHTML = `
      <h3>${t('budget')} - ${monthISO()}</h3><div class="form-grid" id="bud-form">
        ${selField('category_id', t('category'), [{ v: '', l: '-' }].concat(ed.categories.map((c) => ({ v: c.id, l: c.name }))))}
        ${field('amount', t('amount') + ' (Rs)', 'number')}
      </div><button class="btn green" id="bud-add">${t('save')}</button>
      ${bd.rows.length ? `<table style="margin-top:12px"><tr><th>${t('category')}</th><th>${t('budget')}</th><th>${t('actual')}</th><th>${t('variance')}</th></tr>
      ${bd.rows.map((r) => `<tr><td>${esc(r.category)}</td><td>${fmt(r.amount)}</td><td>${fmt(r.actual)}</td><td style="color:${r.variance >= 0 ? '#16a34a' : '#dc2626'}">${fmt(r.variance)}</td></tr>`).join('')}</table>` : empty()}`;
    document.getElementById('bud-add').onclick = async () => {
      const v = formValues('bud-form'); v.month = monthISO();
      try { await api('/api/budgets', 'POST', v); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
  } else {
    const d = await api('/api/reports/finance?month=' + monthISO());
    body.innerHTML = `<div class="cards">
      <div class="card"><div class="num" style="font-size:18px;color:#16a34a">${fmt(d.fee_income)}</div><div class="lbl">${t('income')}</div></div>
      <div class="card"><div class="num" style="font-size:18px;color:#dc2626">${fmt(d.expenses)}</div><div class="lbl">${t('expense')}</div></div>
      <div class="card"><div class="num" style="font-size:18px;color:#dc2626">${fmt(d.salaries_paid)}</div><div class="lbl">${t('salaries')}</div></div>
      <div class="card"><div class="num" style="font-size:18px;color:${d.surplus >= 0 ? '#16a34a' : '#dc2626'}">${fmt(d.surplus)}</div><div class="lbl">${t('surplus')}</div></div>
    </div>
    <h3>${t('expense')} ${t('by_class').replace(t('class_'), t('category'))}</h3>
    ${d.expense_by_category.length ? `<table><tr><th>${t('category')}</th><th>${t('total')}</th></tr>${d.expense_by_category.map((c) => `<tr><td>${esc(c.category || '-')}</td><td>${fmt(c.total)}</td></tr>`).join('')}</table>` : empty()}
    <p class="muted" style="margin-top:8px">Fee collection is not profit - salaries, rent, utilities and other expenses must be deducted.</p>`;
  }
}
window.editClass = async (id, name, level, fee) => {
  const nn = prompt(t('name'), name); if (nn === null) return;
  const nl = prompt('Level (unique)', level); if (nl === null) return;
  const nf = prompt(t('monthly_fee') + ' (Rs)', fee); if (nf === null) return;
  try { await api('/api/classes/' + id, 'PATCH', { name: nn, level: Number(nl), monthly_fee: nf }); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.addSection = async (id) => {
  const sn = prompt(t('section') + ' ' + t('name'), 'B'); if (!sn) return;
  try { await api(`/api/classes/${id}/sections`, 'POST', { name: sn }); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.leaveAction = async (id, status) => {
  try { await api('/api/leaves/' + id, 'PATCH', { status }); toast(t(status === 'approved' ? 'approve' : 'reject') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.attachBill = async (inp, expId) => {
  try { await uploadOwnerFile('expense', expId, inp); toast(t('save') + ' OK'); } catch (e) { toast(e.message, true); }
};
window.paySalary = async (id, salary, name) => {
  try { await api(`/api/employees/${id}/salary`, 'POST', { amount: salary, month: monthISO(), date: todayISO() }); toast(`${name}: ${t('paid')} OK`); render(); }
  catch (e) { toast(e.message, true); }
};

// ---------- timetable ----------
async function pageTimetable(main) {
  const cls = await api('/api/classes');
  const emps = await api('/api/employees');
  const canWrite = ['admin', 'staff'].includes(USER.role);
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')}</h3><div class="form-grid" id="tt-form">
      ${selField('class_id', t('class_'), cls.classes.map((c) => ({ v: c.id, l: c.name })))}
      ${selField('day', t('day'), days.map((d) => ({ v: d, l: d })))}
      ${field('period', t('period'), 'number', 1)}
      ${field('subject', t('subject'))}
      ${selField('teacher_id', t('teachers'), [{ v: '', l: '-' }].concat(emps.employees.map((e) => ({ v: e.id, l: e.name }))))}
      ${field('room', t('room'))}
    </div><button class="btn green" id="tt-add">${t('add')}</button>` : ''}
    <div class="row" style="margin:12px 0"><select id="tt-filter" style="width:auto"><option value="">${t('class_')}: ${t('all')}</option>${cls.classes.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></div>
    <div id="tt-grid"></div>
  </div>`;
  async function loadGrid() {
    const f = document.getElementById('tt-filter').value;
    const d = await api('/api/timetable' + (f ? '?class_id=' + f : ''));
    const periods = [...new Set(d.entries.map((e) => e.period))].sort((a, b) => a - b);
    document.getElementById('tt-grid').innerHTML = d.entries.length ? `<table>
      <tr><th>${t('period')}</th>${days.map((dy) => `<th>${dy}</th>`).join('')}</tr>
      ${periods.map((p) => `<tr><td><b>${p}</b></td>${days.map((dy) => {
        const e = d.entries.find((x) => x.day === dy && x.period === p);
        return `<td>${e ? `${esc(e.subject)}<br><span class="muted" style="font-size:11px">${esc(e.class_name)}${e.teacher_name ? ' - ' + esc(e.teacher_name) : ''}</span>` : ''}</td>`;
      }).join('')}</tr>`).join('')}</table>` : empty();
  }
  document.getElementById('tt-filter').onchange = loadGrid;
  if (canWrite) document.getElementById('tt-add').onclick = async () => {
    try { await api('/api/timetable', 'POST', formValues('tt-form')); toast(t('save') + ' OK'); loadGrid(); } catch (e) { toast(e.message, true); }
  };
  await loadGrid();
}

// ---------- homework ----------
async function pageHomework(main) {
  const cls = await api('/api/classes');
  const d = await api('/api/homework');
  const canWrite = ['admin', 'teacher', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('homework')}</h3><div class="form-grid" id="hw-form">
      ${selField('class_id', t('class_'), cls.classes.map((c) => ({ v: c.id, l: c.name })))}
      ${field('subject', t('subject'))}
      ${field('title', t('title'))}
      ${field('due_date', t('due_date'), 'date')}
      <div style="grid-column:1/-1"><label>${t('body')}</label><textarea name="detail" rows="2"></textarea></div>
    </div><button class="btn green" id="hw-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('homework')}</h3>
    ${d.homework.length ? `<table><tr><th>${t('class_')}</th><th>${t('subject')}</th><th>${t('title')}</th><th>${t('due_date')}</th><th class="hide-m">${t('body')}</th></tr>
    ${d.homework.map((h) => `<tr><td>${esc(h.class_name)}</td><td>${esc(h.subject)}</td><td>${esc(h.title)}</td><td>${esc(h.due_date)}</td><td class="hide-m">${esc(h.detail)}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('hw-add').onclick = async () => {
    try { await api('/api/homework', 'POST', formValues('hw-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}

// ---------- library ----------
async function pageLibrary(main) {
  const d = await api('/api/library/books');
  const stuL = ['admin', 'staff'].includes(USER.role) ? (await api('/api/students')).students : [];
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('new_book')}</h3><div class="form-grid" id="bk-form">
      ${field('title', t('title'))}${field('author', 'Author')}${field('copies', 'Copies', 'number', 1)}
    </div><button class="btn green" id="bk-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('library')}</h3>
    ${d.books.length ? `<table><tr><th>${t('title')}</th><th>Author</th><th>Copies</th></tr>
    ${d.books.map((b) => `<tr><td>${esc(b.title)}</td><td>${esc(b.author)}</td><td>${b.copies}</td></tr>`).join('')}</table>` : empty()}
    ${canWrite ? `<h3 style="margin-top:14px">${t('issue_book')}</h3><div class="form-grid" id="bi-form">
      ${selField('book_id', t('book'), d.books.map((b) => ({ v: b.id, l: b.title + ' (' + b.copies + ')' })))}
      ${selField('student_id', t('students'), stuL.filter((x) => x.status === 'active').map((s) => ({ v: s.id, l: s.name + ' (' + s.admission_no + ')' })))}
      ${field('due_date', t('due_date'), 'date', todayISO())}
    </div><button class="btn green" id="bi-add">${t('issue_book')}</button>` : ''}
    <h3>${t('issue_book')} (${d.issued.length})</h3>
    ${d.issued.length ? `<table><tr><th>${t('title')}</th><th>${t('name')}</th><th>${t('due_date')}</th><th></th></tr>
    ${d.issued.map((i) => `<tr><td>${esc(i.book_title)}</td><td>${esc(i.student_name || i.employee_name || '-')}</td>
      <td>${esc(i.due_date)} ${i.due_date < todayISO() ? `<span class="pill red">${t('overdue')}</span>` : ''}</td>
      <td>${canWrite ? `<button class="btn sm green" onclick="returnBook(${i.id})">${t('return_book')}</button>` : ''}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('bk-add').onclick = async () => {
    try { await api('/api/library/books', 'POST', formValues('bk-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  if (canWrite) document.getElementById('bi-add').onclick = async () => {
    try { await api('/api/library/issue', 'POST', formValues('bi-form')); toast(t('issue_book') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}
window.returnBook = async (id) => { try { await api(`/api/library/return/${id}`, 'POST', {}); toast('OK'); render(); } catch (e) { toast(e.message, true); } };

// ---------- transport ----------
async function pageTransport(main) {
  const d = await api('/api/transport');
  const stuT = ['admin', 'staff'].includes(USER.role) ? (await api('/api/students')).students : [];
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('route_')}</h3><div class="form-grid" id="tr-form">
      ${field('name', t('route_'), 'text', '', 'placeholder="Route 1 - City Center"')}
      ${field('driver_name', t('driver'))}${field('driver_phone', t('phone'))}
      ${field('vehicle', 'Vehicle')}${field('monthly_fee', t('monthly_fee') + ' (Rs)', 'number')}
    </div><button class="btn green" id="tr-add">${t('add')}</button>` : ''}
    ${canWrite ? `<h3 style="margin-top:14px">${t('assign')} ${t('students')}</h3><div class="form-grid" id="ta-form">
      ${selField('route_id', t('route_'), d.routes.map((r) => ({ v: r.id, l: r.name })))}
      ${selField('student_id', t('students'), stuT.filter((x) => x.status === 'active').map((s) => ({ v: s.id, l: s.name + ' (' + s.admission_no + ')' })))}
      ${field('stop', t('stop_'), 'text', '', 'placeholder="Stop name"')}
    </div><button class="btn green" id="ta-add">${t('assign')}</button>` : ''}
    <h3 style="margin-top:14px">${t('transport')}</h3>
    ${d.routes.length ? d.routes.map((r) => `<div class="panel" style="background:#f8fafc">
      <b>${esc(r.name)}</b> <span class="muted">- ${esc(r.driver_name)} ${esc(r.driver_phone)} ${esc(r.vehicle)} | ${fmt(r.monthly_fee)}/month</span>
      <p style="margin-top:6px">${r.students.map((s) => `<span class="pill blue" style="margin:2px">${esc(s.student_name)}${s.stop ? ' (' + esc(s.stop) + ')' : ''}${canWrite ? ` <a href="javascript:void(0)" onclick="unassignTransport(${s.id})" title="${t('unassign')}" style="color:#dc2626;font-weight:700;text-decoration:none">×</a>` : ''}</span>`).join('') || `<span class="muted">${t('no_data')}</span>`}</p>
    </div>`).join('') : empty()}
  </div>`;
  if (canWrite) document.getElementById('tr-add').onclick = async () => {
    try { await api('/api/transport/routes', 'POST', formValues('tr-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  if (canWrite) document.getElementById('ta-add').onclick = async () => {
    try { await api('/api/transport/assign', 'POST', formValues('ta-form')); toast(t('assign') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}
window.unassignTransport = async (assignId) => {
  try { await api('/api/transport/assign/' + assignId, 'DELETE'); toast(t('unassign') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};

// ---------- inventory ----------
async function pageInventory(main) {
  const d = await api('/api/inventory');
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('item')}</h3><div class="form-grid" id="inv-form">
      ${field('name', t('item'), 'text', '', 'placeholder="Chairs, Computers..."')}
      ${field('category', t('category'))}${field('quantity', t('quantity'), 'number')}
      ${field('unit', 'Unit', 'text', '', 'placeholder="pcs, boxes"')}
    </div><button class="btn green" id="inv-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('inventory')}</h3>
    ${d.items.length ? `<table><tr><th>${t('item')}</th><th>${t('category')}</th><th>${t('quantity')}</th><th class="hide-m">${t('body')}</th></tr>
    ${d.items.map((i) => `<tr><td>${esc(i.name)}</td><td>${esc(i.category)}</td><td>${i.quantity} ${esc(i.unit)}</td><td class="hide-m">${esc(i.note)}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('inv-add').onclick = async () => {
    try { await api('/api/inventory', 'POST', formValues('inv-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}

// ---------- notices ----------
async function pageNotices(main) {
  const d = await api('/api/announcements');
  const canWrite = !['parent', 'student'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('notices')}</h3><div class="form-grid" id="an-form">
      ${field('title', t('title'))}
      ${selField('audience', t('audience'), [{ v: 'all', l: t('all') }, { v: 'parents', l: t('parents') }, { v: 'teachers', l: t('teachers') }])}
      <div style="grid-column:1/-1"><label>${t('body')}</label><textarea name="body" rows="2"></textarea></div>
    </div><button class="btn green" id="an-add">${t('send')}</button>` : ''}
    <h3 style="margin-top:14px">${t('notices')}</h3>
    ${d.announcements.length ? d.announcements.map((a) => `<div class="panel" style="background:#f8fafc">
      <b>${esc(a.title)}</b> ${pill(a.audience)} <span class="muted" style="font-size:12px">${esc(a.created_at.slice(0, 10))} - ${esc(a.author || '')}</span>
      <p style="margin-top:4px">${esc(a.body)}</p></div>`).join('') : empty()}
  </div>`;
  if (canWrite) document.getElementById('an-add').onclick = async () => {
    try { await api('/api/announcements', 'POST', formValues('an-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}


// ---------- holidays ----------
async function pageHolidays(main) {
  const d = await api('/api/holidays');
  const canWrite = !['parent', 'student'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('holidays')}</h3><div class="form-grid" id="hol-form">
      ${field('name', t('name'))}${field('date', t('date'), 'date')}
    </div><button class="btn green" id="hol-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('holidays')}</h3>
    ${d.holidays.length ? `<table><tr><th>${t('date')}</th><th>${t('name')}</th>${canWrite ? '<th></th>' : ''}</tr>
    ${d.holidays.map((h) => `<tr><td>${esc(h.date)}</td><td>${esc(h.name)}</td>
      ${canWrite ? `<td><button class="btn sm red" onclick="delHoliday(${h.id})">${t('delete')}</button></td>` : ''}</tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('hol-add').onclick = async () => {
    try { await api('/api/holidays', 'POST', formValues('hol-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}
window.delHoliday = async (id) => {
  if (!confirm(t('delete') + '?')) return;
  try { await api('/api/holidays/' + id, 'DELETE'); render(); } catch (e) { toast(e.message, true); }
};

// ---------- complaints ----------
async function pageComplaints(main) {
  const d = await api('/api/complaints');
  const staffSide = ['admin', 'staff'].includes(USER.role);
  const canFile = !['super_admin'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canFile && !staffSide ? `<h3>${t('add')} ${t('complaints')}</h3><div class="form-grid" id="cmp-form">
      ${field('category', t('category'))}
      <div style="grid-column:1/-1"><label>${t('body')}</label><textarea name="body" rows="3"></textarea></div>
    </div><button class="btn green" id="cmp-add">${t('send')}</button>` : ''}
    <h3 style="margin-top:14px">${t('complaints')}</h3>
    ${d.complaints.length ? d.complaints.map((c) => `<div class="panel" style="background:#f8fafc">
      <b>${esc(c.category)}</b> ${pill(c.status)} <span class="muted" style="font-size:12px">${esc((c.created_at || '').slice(0, 10))} - ${esc(c.from_name || '')}</span>
      <p style="margin-top:4px">${esc(c.body)}</p>
      ${c.response ? `<p style="margin-top:4px"><b>${t('response')}:</b> ${esc(c.response)}</p>` : ''}
      ${staffSide ? `<div class="form-grid" id="cmp-r${c.id}" style="margin-top:6px">
        ${selField('status', t('status'), ['open', 'in_progress', 'resolved', 'closed'].map((s) => ({ v: s, l: t(s) })), c.status)}
        ${field('response', t('response'), 'text', c.response || '')}
      </div><button class="btn sm green" onclick="respondComplaint(${c.id})">${t('respond')}</button>` : ''}
    </div>`).join('') : empty()}
  </div>`;
  const addBtn = document.getElementById('cmp-add');
  if (addBtn) addBtn.onclick = async () => {
    try { await api('/api/complaints', 'POST', formValues('cmp-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}
window.respondComplaint = async (id) => {
  try { await api('/api/complaints/' + id, 'PATCH', formValues('cmp-r' + id)); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};

// ---------- super: renewals ----------
async function pageSuperRenewals(main) {
  const d = await api('/api/super/renewals');
  main.innerHTML = msgHtml() + `
  <div class="panel"><h2>${t('renewals')}</h2>
    <p class="muted" style="margin:6px 0">Unpaid auto-generated renewal invoices. Reminders use free wa.me links - open the chat, review the prefilled text, send manually. No paid SMS/WhatsApp API is used.</p>
    ${d.renewals.length ? `<table><tr><th>${t('schools')}</th><th>${t('plan')}</th><th>${t('month')}</th><th>${t('amount')}</th><th>${t('due_date')}</th><th>${t('actions')}</th></tr>
    ${d.renewals.map((r) => `<tr><td>${esc(r.school_name)}</td><td>${esc(r.plan_name || '-')}</td><td>${esc(r.period_month)}</td><td>${fmt(r.amount)}</td><td>${esc(r.due_date)}</td>
      <td>${r.reminder_url ? `<a class="btn sm green" href="${esc(r.reminder_url)}" target="_blank" rel="noopener">WhatsApp ${t('reminder')}</a>` : '<span class="muted">no phone</span>'}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
}

// ---------- documents ----------
window.uploadOwnerFile = async (ownerType, ownerId, inputEl, extra) => {
  const f = inputEl.files && inputEl.files[0];
  if (!f) return toast(t('choose_file'), true);
  if (f.size > 5 * 1024 * 1024) return toast(t('choose_file'), true);
  const data_base64 = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(f); });
  const up = await api('/api/files', 'POST', { owner_type: ownerType, owner_id: ownerId, filename: f.name, data_base64 });
  if (extra === 'photo' && up.mime && up.mime.startsWith('image/')) await api('/api/students/' + ownerId + '/photo', 'POST', { file_id: up.id });
  return up;
};

async function pageDocuments(main) {
  const d = await api('/api/documents');
  const students = (await api('/api/students')).students;
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('issue')} ${t('documents')}</h3><div class="form-grid" id="doc-form">
      ${selField('student_id', t('students'), students.map((s) => ({ v: s.id, l: `${s.name} (${s.admission_no})` })))}
      ${selField('doc_type', t('documents'), [{ v: 'bonafide', l: 'Bonafide Certificate' }, { v: 'character_certificate', l: 'Character Certificate' }, { v: 'leaving_certificate', l: 'Leaving Certificate' }, { v: 'admission_form', l: 'Admission Form' }, { v: 'other', l: t('other') }])}
    </div><button class="btn green" id="doc-add">${t('issue')}</button>` : ''}
    ${canWrite ? `<h3 style="margin-top:14px">${t('upload_file')}</h3><div class="form-grid" id="upl-form">
      ${selField('student_id', t('students'), students.map((s) => ({ v: s.id, l: `${s.name} (${s.admission_no})` })))}
      <div><label>${t('choose_file')}</label><input type="file" id="upl-file" accept=".jpg,.jpeg,.png,.webp,.pdf"></div>
    </div>
    <div class="row"><button class="btn green" id="upl-add">${t('upload_file')}</button>
    <button class="btn" id="upl-photo">${t('upload_file')} + ${t('set_photo')}</button></div>` : ''}
    <h3 style="margin-top:14px">${t('files')}</h3><div id="file-list"><p class="muted">${t('loading')}</p></div>
    <h3 style="margin-top:14px">${t('documents')}</h3>
    ${d.documents.length ? `<table><tr><th>${t('title')}</th><th>${t('students')}</th><th>${t('date')}</th><th></th></tr>
    ${d.documents.map((x) => `<tr><td>${esc(x.title)}</td><td>${esc(x.student_name)}</td><td>${esc(x.created_at.slice(0, 10))}</td>
      <td><button class="btn sm outline" onclick="viewDoc(${x.id})">${t('view')}</button></td></tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('doc-add').onclick = async () => {
    try { await api('/api/documents', 'POST', formValues('doc-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
  const fl = await api('/api/files').catch(() => ({ files: [] }));
  document.getElementById('file-list').innerHTML = fl.files.length ? `<table><tr><th>${t('filename')}</th><th>${t('owner')}</th><th class="hide-m">${t('size')}</th><th>${t('date')}</th><th></th></tr>
    ${fl.files.map((f) => `<tr><td>${esc(f.filename)}</td><td>${esc(f.owner_type)} #${f.owner_id}</td><td class="hide-m">${Math.round(f.size / 1024)} KB</td><td>${esc((f.created_at || '').slice(0, 10))}</td>
    <td class="row"><a class="btn sm outline" target="_blank" href="/api/files/${f.id}">${t('view')}</a>
    ${f.mime.startsWith('image/') && f.owner_type === 'student' && canWrite ? `<button class="btn sm" onclick="setPhoto(${f.owner_id},${f.id})">${t('set_photo')}</button>` : ''}
    ${USER.role === 'admin' ? `<button class="btn sm gray" onclick="delFile(${f.id})">${t('delete')}</button>` : ''}</td></tr>`).join('')}</table>` : empty();
  if (canWrite) {
    document.getElementById('upl-add').onclick = async () => {
      try { const sid = formValues('upl-form').student_id; await uploadOwnerFile('student', Number(sid), document.getElementById('upl-file')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
    document.getElementById('upl-photo').onclick = async () => {
      try { const sid = formValues('upl-form').student_id; await uploadOwnerFile('student', Number(sid), document.getElementById('upl-file'), 'photo'); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
  }
}
window.setPhoto = async (stuId, fileId) => {
  try { await api('/api/students/' + stuId + '/photo', 'POST', { file_id: fileId }); toast(t('save') + ' OK'); } catch (e) { toast(e.message, true); }
};
window.delFile = async (id) => {
  try { await api('/api/files/' + id, 'DELETE'); toast(t('delete') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.viewDoc = async (id) => {
  const d = await api('/api/documents/' + id);
  const el = document.createElement('div');
  el.className = 'drawer';
  el.innerHTML = `<div><div class="row" style="justify-content:space-between"><h2>${esc(d.document.title)}</h2>
    <span class="row"><button class="btn sm" onclick="window.print()">Print</button><button class="btn sm gray" id="dr-close">${t('close')}</button></span></div>
    <div class="panel" style="white-space:pre-wrap;font-family:serif">${esc(d.document.body)}</div></div>`;
  el.querySelector('#dr-close').onclick = () => el.remove();
  document.body.appendChild(el);
};

// ---------- meetings ----------
async function pageMeetings(main) {
  const d = await api('/api/meetings');
  const canWrite = ['admin', 'staff'].includes(USER.role);
  main.innerHTML = msgHtml() + `
  <div class="panel">
    ${canWrite ? `<h3>${t('add')} ${t('meetings')}</h3><div class="form-grid" id="mt-form">
      ${field('title', t('title'))}${field('with_whom', t('guardian') + '/' + t('other'))}${field('date', t('date'), 'date', todayISO())}
      <div style="grid-column:1/-1"><label>${t('body')}</label><input name="notes"></div>
    </div><button class="btn green" id="mt-add">${t('add')}</button>` : ''}
    <h3 style="margin-top:14px">${t('meetings')}</h3>
    ${d.meetings.length ? `<table><tr><th>${t('title')}</th><th>${t('guardian')}</th><th>${t('date')}</th><th class="hide-m">${t('body')}</th></tr>
    ${d.meetings.map((m) => `<tr><td>${esc(m.title)}</td><td>${esc(m.with_whom)}</td><td>${esc(m.date)}</td><td class="hide-m">${esc(m.notes)}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
  if (canWrite) document.getElementById('mt-add').onclick = async () => {
    try { await api('/api/meetings', 'POST', formValues('mt-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}

// ---------- settings ----------
async function pageSettings(main) {
  const d = await api('/api/school');
  const s = d.school;
  main.innerHTML = msgHtml() + `
  <div class="panel"><h2>${t('school_profile')}</h2>
    ${USER.role === 'admin' ? `<div class="form-grid" id="sch-form">
      ${field('name', t('name'), 'text', s.name)}
      ${field('phone', t('phone'), 'text', s.phone)}
      <div style="grid-column:1/-1"><label>${t('address')}</label><input name="address" value="${esc(s.address)}"></div>
    </div><button class="btn green" id="sch-save">${t('save')}</button>` : `<p><b>${esc(s.name)}</b><br>${esc(s.address)}<br>${esc(s.phone)}</p>`}
    ${d.subscription ? `<h3 style="margin-top:12px">${t('subscription')}</h3><p>${esc(d.subscription.plan_name || '-')} - ${fmt(d.subscription.amount)}/month | ${t('renewal')}: ${esc(d.subscription.renewal_date)} ${pill(d.subscription.status)} | ${t('student_limit')}: ${d.subscription.student_limit}</p><p class="muted" style="font-size:12px">Plan price is the platform's proposed rate, set by the platform owner.</p>` : ''}
    <p class="muted" style="margin-top:10px">${t('backup_note')}</p>
    ${USER.role === 'admin' ? `<a class="btn sm outline" href="/api/export">${t('export')}</a>` : ''}
  </div>
  <div class="panel"><h2>${t('password')}</h2>
    <div class="form-grid" id="cp-form">
      <div><label>Current</label><input name="current_password" type="password"></div>
      <div><label>New (8+)</label><input name="new_password" type="password"></div>
    </div><button class="btn green" id="cp-save">${t('save')}</button>
  </div>
  ${USER.role === 'admin' ? `<div class="panel"><h2>${t('users_logins')}</h2><div id="users-list"></div></div>` : ''}
  ${USER.role === 'admin' ? `<div class="panel"><h2>${t('fee_rules')}</h2>
    <div class="form-grid">
      ${selField('late_fee_type', t('late_fee_type'), [{ v: 'flat', l: t('flat') }, { v: 'percent', l: t('percent') }], s.late_fee_type || 'flat')}
      ${field('late_fee_value', t('late_fee_value') + ' (Rs / %)', 'number', (s.late_fee_type === 'percent' ? s.late_fee_value : (s.late_fee_value || 0) / 100) || '')}
    </div>
    <label style="display:block;margin:8px 0"><input type="checkbox" id="absent-notice" style="width:auto" ${s.absent_notice ? 'checked' : ''}> ${t('absent_notice')}</label>
    <button class="btn green" id="fee-rules-save">${t('save')}</button>
  </div>` : ''}
  ${['admin', 'accountant', 'teacher', 'staff'].includes(USER.role) ? `<div class="panel"><h2>${t('support')}</h2>
    <div class="form-grid" id="tk-form">${field('subject', t('subject'))}<div><label>${t('body')}</label><input name="body"></div></div>
    <button class="btn green" id="tk-add">${t('create_ticket')}</button>
    <div id="tk-list" style="margin-top:12px"><p class="muted">${t('loading')}</p></div>
  </div>` : ''}`;
  document.getElementById('cp-save').onclick = async () => {
    try { await api('/api/change-password', 'POST', formValues('cp-form')); toast('Password updated'); render(); }
    catch (e) { toast(e.message, true); }
  };
  const tkAdd = document.getElementById('tk-add');
  if (tkAdd) {
    tkAdd.onclick = async () => {
      try { await api('/api/tickets', 'POST', formValues('tk-form')); toast(t('save') + ' OK'); loadTickets(); } catch (e) { toast(e.message, true); }
    };
    loadTickets();
  }
  if (USER.role === 'admin') {
    document.getElementById('sch-save').onclick = async () => {
      try { await api('/api/school', 'PATCH', formValues('sch-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
    const frSave = document.getElementById('fee-rules-save');
    if (frSave) frSave.onclick = async () => {
      const ty = document.querySelector('[name=late_fee_type]').value;
      const val = document.querySelector('[name=late_fee_value]').value;
      try {
        await api('/api/school', 'PATCH', { late_fee_type: ty, late_fee_value: val === '' ? 0 : Number(val), absent_notice: document.getElementById('absent-notice').checked });
        toast(t('save') + ' OK'); render();
      } catch (e) { toast(e.message, true); }
    };
    const ud = await api('/api/users');
    document.getElementById('users-list').innerHTML = `
      <h3>${t('new_user')}</h3><div class="form-grid" id="usr-form">
        ${field('name', t('name'))}${field('username', t('username'))}
        ${field('password', t('password') + ' (8+)', 'password')}
        ${selField('role', t('role'), [{ v: 'teacher', l: 'Teacher' }, { v: 'accountant', l: 'Accountant' }, { v: 'staff', l: 'Office Staff' }, { v: 'admin', l: 'Admin' }])}
        ${field('phone', t('phone'))}
      </div><button class="btn green" id="usr-add">${t('add')}</button>
      <h3 style="margin-top:12px">${t('users_logins')}</h3>
      <table><tr><th>${t('name')}</th><th>${t('username')}</th><th>${t('role')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
      ${ud.users.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.username)}</td><td>${esc(x.role)}</td><td>${pill(x.status)}</td>
        <td>${x.id !== USER.id ? `<button class="btn sm ${x.status === 'disabled' ? 'green' : 'red'}" onclick="userToggle(${x.id},'${x.status}')">${x.status === 'disabled' ? t('enable') : t('disable')}</button> <button class="btn sm outline" onclick="userResetPw(${x.id},'${esc(x.username)}')">${t('reset_password')}</button>` : `<span class="muted">(${t('profile')})</span>`}</td></tr>`).join('')}</table>`;
    document.getElementById('usr-add').onclick = async () => {
      try { await api('/api/users', 'POST', formValues('usr-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
    };
  }
}

window.userToggle = async (id, status) => {
  const next = status === 'disabled' ? 'active' : 'disabled';
  try { await api('/api/users/' + id, 'PATCH', { status: next }); toast(t(next === 'disabled' ? 'disable' : 'enable') + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.userResetPw = async (id, username) => {
  const pw = prompt(t('reset_password') + ' - ' + username + ' (8+)'); if (!pw) return;
  if (pw.length < 8) return toast(t('password') + ' 8+', true);
  try { await api('/api/users/' + id, 'PATCH', { password: pw }); toast(t('reset_password') + ' OK'); } catch (e) { toast(e.message, true); }
};

// support tickets loader shared by settings page
async function loadTickets() {
  const list = document.getElementById('tk-list');
  if (!list) return;
  const d = await api('/api/tickets');
  list.innerHTML = d.tickets.length ? d.tickets.map((x) => `<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px;margin-top:8px">
    <div class="row" style="justify-content:space-between"><b>#${x.id} ${esc(x.subject)}</b>${pill(x.status)}</div>
    <p class="muted">${esc(x.body)}</p>
    ${(x.replies || []).map((r) => `<p style="margin-left:12px">↳ <b>${esc(r.author_role)}</b>: ${esc(r.body)} <span class="muted">${esc(r.created_at.slice(0, 10))}</span></p>`).join('')}
    ${x.status !== 'closed' ? `<div class="row"><button class="btn sm outline" onclick="ticketReply(${x.id})">${t('reply')}</button> <button class="btn sm red" onclick="ticketClose(${x.id})">${t('close_ticket')}</button></div>` : ''}
  </div>`).join('') : empty();
}
window.ticketReply = async (id) => {
  const body = prompt(t('reply') + ':');
  if (!body) return;
  try { await api(`/api/tickets/${id}/replies`, 'POST', { body }); loadTickets(); } catch (e) { toast(e.message, true); }
};
window.ticketClose = async (id) => {
  try { await api(`/api/tickets/${id}`, 'PATCH', { status: 'closed' }); loadTickets(); } catch (e) { toast(e.message, true); }
};

// ---------- parent portal ----------
async function pageParent(main) {
  if (USER.role === 'student') return pageStudentSelf(main);
  const d = await api('/api/parent/children');
  main.innerHTML = msgHtml() + `
  <div class="panel"><h2>${t('my_children')}</h2>
    ${d.children.length ? d.children.map((c) => `<div class="panel" style="background:#f8fafc">
      <div class="row" style="justify-content:space-between">
        <b>${esc(c.name)} <span class="muted">(${esc(c.admission_no)}) - ${esc(c.class_name)} ${esc(c.section_name)}</span></b>
        <button class="btn sm outline" onclick="parentChild(${c.id})">${t('view')}</button>
      </div>
      <p style="margin-top:4px">${t('dues')}: ${c.dues > 0 ? `<span class="pill red">${fmt(c.dues)}</span>` : '<span class="pill green">0</span>'}</p>
    </div>`).join('') : empty()}
  </div>
  <div id="parent-detail"></div>`;
}
window.parentChild = async (id) => {
  const d = await api('/api/parent/children/' + id);
  const res = await api(`/api/parent/children/${id}/results`);
  const el = document.getElementById('parent-detail');
  el.innerHTML = `<div class="panel"><div class="row" style="justify-content:space-between;align-items:center"><h2>${esc(d.child.name)}</h2>
    ${d.photo_url ? `<img alt="" src="${d.photo_url}" style="width:64px;height:64px;border-radius:8px;object-fit:cover" onerror="this.style.display='none'">` : ''}</div>
    ${(d.files || []).length ? `<h3>${t('files')}</h3>${d.files.map((f) => `<p>• <a target="_blank" href="/api/parent/files/${f.id}">${esc(f.filename)}</a> <span class="muted">${Math.round(f.size / 1024)} KB</span></p>`).join('')}` : ''}
    <h3>${t('fee_vouchers')}</h3>
    ${d.vouchers.length ? `<table><tr><th>${t('month')}</th><th>${t('total')}</th><th>${t('outstanding')}</th><th>${t('status')}</th></tr>
    ${d.vouchers.map((v) => `<tr><td>${esc(v.month)}</td><td>${fmt(v.total)}</td><td>${fmt(v.outstanding)}</td><td>${pill(v.status)}</td></tr>`).join('')}</table>` : empty()}
    <h3>${t('attendance_summary')} (${t('daily')})</h3>
    ${d.attendance.length ? `<div style="max-height:180px;overflow-y:auto"><table><tr><th>${t('date')}</th><th>${t('status')}</th></tr>
    ${d.attendance.map((a) => `<tr><td>${esc(a.date)}</td><td>${pill(a.status)}</td></tr>`).join('')}</table></div>` : empty()}
    <h3>${t('results_')}</h3>
    ${res.results.length ? res.results.map((r) => `<p><b>${esc(r.exam)}</b>: ${r.total_obtained}/${r.total_max} (${r.percentage == null ? '-' : r.percentage + '%'}) - ${esc(r.grade)}</p>`).join('') : empty()}
    <h3>${t('progress')}</h3>
    ${(d.progress && d.progress.terms.length) ? `<table><tr><th>${t('term_average')}</th><th>%</th></tr>${d.progress.terms.map((x) => `<tr><td>${esc(x.term)}</td><td>${x.average_pct}%</td></tr>`).join('')}</table>
    ${Object.keys(d.progress.subjects).map((sub) => `<p style="margin-top:6px"><b>${esc(sub)}</b>: ${d.progress.subjects[sub].map((m) => `${esc(m.exam)} ${m.pct}%`).join(' → ')}</p>`).join('')}` : empty()}
    <h3>${t('homework_')}</h3>
    ${d.homework.length ? d.homework.map((h) => `<p>• [${esc(h.subject)}] ${esc(h.title)} - ${esc(h.due_date)}</p>`).join('') : empty()}
    <h3>${t('notices_')}</h3>
    ${d.announcements.length ? d.announcements.map((a) => `<p>• <b>${esc(a.title)}</b> <span class="muted">${esc(a.created_at.slice(0, 10))}</span><br>${esc(a.body)}</p>`).join('') : empty()}
  </div>`;
  el.scrollIntoView({ behavior: 'smooth' });
};

// ---------- super admin ----------
async function pageSuperOverview(main) {
  const d = await api('/api/super/overview');
  const c = d.schools || {};
  main.innerHTML = msgHtml() + `
  <div class="cards">
    <div class="card"><div class="num">${(c.trial || 0) + (c.active || 0) + (c.suspended || 0) + (c.expired || 0)}</div><div class="lbl">${t('schools_total')}</div></div>
    <div class="card"><div class="num" style="color:#16a34a">${c.active || 0}</div><div class="lbl">${t('active')}</div></div>
    <div class="card"><div class="num" style="color:#d97706">${c.trial || 0}</div><div class="lbl">${t('trial')}</div></div>
    <div class="card"><div class="num" style="color:#dc2626">${(c.suspended || 0) + (c.expired || 0)}</div><div class="lbl">${t('suspended')} / ${t('expired')}</div></div>
    <div class="card"><div class="num" style="font-size:18px">${fmt(d.mrr)}</div><div class="lbl">${t('mrr')}</div></div>
    <div class="card"><div class="num">${d.students_total}</div><div class="lbl">${t('total_students')}</div></div>
  </div>
  <div class="panel"><h2>${t('renewals_due')}</h2>
    ${d.renewals_due.length ? `<table><tr><th>${t('schools')}</th><th>${t('plan')}</th><th>${t('renewal')}</th></tr>
    ${d.renewals_due.map((r) => `<tr><td>${esc(r.name)}</td><td>${esc(r.plan || '-')}</td><td>${esc(r.renewal_date)}</td></tr>`).join('')}</table>` : empty()}
  </div>
  <div class="panel"><h2>${t('support')}</h2><div id="sup-tk"><p class="muted">${t('loading')}</p></div></div>`;
  const tk = await api('/api/super/tickets');
  document.getElementById('sup-tk').innerHTML = tk.tickets.length ? tk.tickets.map((x) => `<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px;margin-top:8px">
    <div class="row" style="justify-content:space-between"><b>#${x.id} ${esc(x.subject)}</b><span>${pill(x.status)} <span class="muted">${esc(x.school_name)}</span></span></div>
    <p class="muted">${esc(x.body)}</p>
    ${(x.replies || []).map((r) => `<p style="margin-left:12px">↳ <b>${esc(r.author_role)}</b>: ${esc(r.body)} <span class="muted">${esc(r.created_at.slice(0, 10))}</span></p>`).join('')}
    <div class="row">
      <button class="btn sm outline" onclick="supTicketReply(${x.id})">${t('reply')}</button>
      ${['open', 'in_progress', 'resolved', 'closed'].filter((st) => st !== x.status).map((st) => `<button class="btn sm gray" onclick="supTicketStatus(${x.id},'${st}')">${t(st)}</button>`).join('')}
    </div>
  </div>`).join('') : empty();
}
window.supTicketReply = async (id) => {
  const body = prompt(t('reply') + ':');
  if (!body) return;
  try { await api(`/api/super/tickets/${id}/replies`, 'POST', { body }); render(); } catch (e) { toast(e.message, true); }
};
window.supTicketStatus = async (id, status) => {
  try { await api(`/api/super/tickets/${id}`, 'PATCH', { status }); render(); } catch (e) { toast(e.message, true); }
};
async function pageSuperSchools(main) {
  const d = await api('/api/super/schools');
  const plans = await api('/api/super/plans');
  main.innerHTML = msgHtml() + `
  <div class="panel">
    <h3>${t('create_school')}</h3>
    <div class="form-grid" id="sch-new">
      ${field('name', t('name'), 'text', '', 'placeholder="City Grammar School"')}
      ${field('code', t('code'), 'text', '', 'placeholder="city-grammar"')}
      ${selField('plan_id', t('plan'), plans.plans.map((p) => ({ v: p.id, l: `${p.name} - ${fmt(p.price_pkr)} (${p.student_limit})` })))}
      ${field('renewal_date', t('renewal'), 'date')}
      ${field('phone', t('phone'))}
      ${field('address', t('address'))}
    </div><button class="btn green" id="sch-create">${t('add')}</button>
    <h3 style="margin-top:14px">${t('schools')} (${d.schools.length})</h3>
    ${d.schools.length ? `<table><tr><th>${t('name')}</th><th>${t('code')}</th><th>${t('plan')}</th><th>${t('students')}</th><th>${t('renewal')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
    ${d.schools.map((s) => `<tr><td>${esc(s.name)}</td><td>${esc(s.code)}</td><td>${esc(s.plan_name || '-')}</td>
      <td>${s.students}${s.student_limit ? '/' + s.student_limit : ''}</td><td>${esc(s.renewal_date)}</td><td>${pill(s.status)}</td>
      <td class="row"><button class="btn sm outline" onclick="schoolAdmin(${s.id},'${esc(s.name)}')">${t('create_admin')}</button>
      <button class="btn sm ${s.status === 'suspended' ? 'green' : 'red'}" onclick="schoolToggle(${s.id},'${s.status === 'suspended' ? 'active' : 'suspended'}')">${s.status === 'suspended' ? t('reactivate') : t('suspend')}</button></td></tr>`).join('')}</table>` : empty()}
  </div>`;
  document.getElementById('sch-create').onclick = async () => {
    try { await api('/api/super/schools', 'POST', formValues('sch-new')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}
window.schoolToggle = async (id, status) => {
  try { await api('/api/super/schools/' + id, 'PATCH', { status }); toast(status + ' OK'); render(); } catch (e) { toast(e.message, true); }
};
window.schoolAdmin = async (id, name) => {
  const el = document.createElement('div');
  el.className = 'drawer';
  el.innerHTML = `<div style="width:min(400px,96vw)"><h2>${t('create_admin')} - ${esc(name)}</h2>
    <div class="form-grid" id="adm-form" style="margin-top:12px">
      ${field('name', t('name'))}${field('username', t('username'))}
      ${field('password', t('password') + ' (8+)', 'password')}${field('phone', t('phone'))}
    </div>
    <div class="row"><button class="btn green" id="adm-save">${t('save')}</button><button class="btn gray" id="adm-cancel">${t('cancel')}</button></div>
    <div id="adm-res"></div></div>`;
  el.querySelector('#adm-cancel').onclick = () => el.remove();
  el.querySelector('#adm-save').onclick = async () => {
    try {
      const v = formValues('adm-form');
      await api(`/api/super/schools/${id}/admin`, 'POST', v);
      el.querySelector('#adm-res').innerHTML = `<div class="msg ok">${t('save')} OK - ${t('username')}: <b>${esc(v.username)}</b></div>`;
    } catch (e) { toast(e.message, true); }
  };
  document.body.appendChild(el);
};
async function pageSuperPlans(main) {
  const d = await api('/api/super/plans');
  main.innerHTML = msgHtml() + `
  <div class="panel"><h2>${t('plans')}</h2>
    <table><tr><th>${t('name')}</th><th>${t('amount')}/${t('month')}</th><th>${t('student_limit')}</th><th>${t('body')}</th></tr>
    ${d.plans.map((p) => `<tr><td>${esc(p.name)}</td><td>${fmt(p.price_pkr)}</td><td>${p.student_limit}</td><td class="muted">${esc(p.inclusions)}</td></tr>`).join('')}</table>
    <h3>${t('add')} ${t('plans')}</h3>
    <div class="form-grid" id="plan-form">
      ${field('name', t('name'))}${field('price_pkr', t('amount') + ' (Rs)', 'number')}${field('student_limit', t('student_limit'), 'number', 150)}
    </div><button class="btn green" id="plan-add">${t('add')}</button>
    <p class="muted" style="margin-top:8px"><b>Illustrative proposed rates</b> - editable, not approved customer terms. No school is charged, invoiced or suspended automatically from these prices. Validate with pilot schools first. SMS/WhatsApp API, payment gateway, migration and training can be priced separately later.</p>
  </div>`;
  document.getElementById('plan-add').onclick = async () => {
    try { await api('/api/super/plans', 'POST', formValues('plan-form')); toast(t('save') + ' OK'); render(); } catch (e) { toast(e.message, true); }
  };
}
async function pageSuperSubs(main) {
  const d = await api('/api/super/subscriptions');
  main.innerHTML = msgHtml() + `
  <div class="panel"><h2>${t('subscriptions')}</h2>
    ${d.subscriptions.length ? `<table><tr><th>${t('schools')}</th><th>${t('plan')}</th><th>${t('amount')}</th><th>${t('renewal')}</th><th>${t('status')}</th><th>${t('actions')}</th></tr>
    ${d.subscriptions.map((s) => `<tr><td>${esc(s.school_name)}</td><td>${esc(s.plan_name || '-')}</td><td>${fmt(s.amount)}</td>
      <td>${esc(s.renewal_date)}</td><td>${pill(s.status)}</td>
      <td><button class="btn sm green" onclick="subPay(${s.id},${s.amount},'${esc(s.school_name)}')">${t('confirm_payment')}</button>
      <button class="btn sm outline" onclick="subGrace(${s.id},${s.grace_days},${s.restrict_after_grace})">${t('grace_days')}: ${s.grace_days}${s.restrict_after_grace ? ' + ' + t('restrict_after_grace') : ''}</button></td></tr>`).join('')}</table>` : empty()}
    <h3>${t('collection')}</h3>
    ${d.payments.length ? `<table><tr><th>${t('date')}</th><th>${t('schools')}</th><th>${t('amount')}</th><th>${t('method')}</th><th>${t('reference')}</th></tr>
    ${d.payments.map((p) => `<tr><td>${esc(p.date)}</td><td>${esc(p.school_name)}</td><td>${fmt(p.amount)}</td><td>${esc(p.method)}</td><td>${esc(p.reference)}</td></tr>`).join('')}</table>` : empty()}
    <p class="muted" style="margin-top:8px">Payments are recorded after manual verification (bank transfer reference). Screenshots alone are not accepted. No auto-charging.</p>
  </div>`;
}
window.subGrace = async (id, grace, restrict) => {
  const g = prompt(`${t('grace_days')} (0-90):`, grace);
  if (g === null) return;
  const r = confirm(t('restrict_after_grace') + '?');
  try { await api(`/api/super/subscriptions/${id}`, 'PATCH', { grace_days: Number(g), restrict_after_grace: r }); toast(t('save') + ' OK'); render(); }
  catch (e) { toast(e.message, true); }
};
window.subPay = async (id, amount, name) => {
  const ref = prompt(`${t('confirm_payment')} - ${name}\n${fmt(amount)}\n${t('reference')}:`);
  if (ref === null) return;
  try { await api(`/api/super/subscriptions/${id}/payment`, 'POST', { amount: amount / 100, reference: ref, date: todayISO() }); toast(t('save') + ' OK'); render(); }
  catch (e) { toast(e.message, true); }
};
async function pageSuperAudit(main) {
  const d = await api('/api/super/audit');
  main.innerHTML = msgHtml() + `
  <div class="panel"><h2>${t('audit')}</h2>
    ${d.logs.length ? `<table><tr><th>${t('date')}</th><th>${t('username')}</th><th>${t('actions')}</th><th>${t('body')}</th></tr>
    ${d.logs.map((l) => `<tr><td>${esc(l.ts)}</td><td>${esc(l.username || '-')}</td><td>${esc(l.action)}</td><td class="muted">${esc(l.detail)}</td></tr>`).join('')}</table>` : empty()}
  </div>`;
}
